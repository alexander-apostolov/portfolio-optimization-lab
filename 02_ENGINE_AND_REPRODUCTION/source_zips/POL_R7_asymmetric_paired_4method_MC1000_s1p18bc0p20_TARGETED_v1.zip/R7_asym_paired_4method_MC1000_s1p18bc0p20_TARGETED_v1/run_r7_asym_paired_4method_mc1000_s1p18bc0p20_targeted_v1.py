#!/usr/bin/env python3
from __future__ import annotations
import csv,json,statistics,time,zipfile,sys,importlib.util
from pathlib import Path
ENGINE_ROOT=Path('/mnt/data/engine28/POL_step1_engine_v28_POL3_six_regime_MC500_validated_package')
sys.path.insert(0,str(ENGINE_ROOT/'scripts'))
import pol_step1_reference_generators as gens
import pol_step1_reference_common as common
eng=common.eng
spec=importlib.util.spec_from_file_location('runner','/mnt/data/pol_scpa_lite_runner.py')
runner=importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
SEEDS=list(range(1,11)); SEARCH_MC=100; FINAL_MC=1000; DENOM_EPS=1e-9
OUTDIR=Path('/mnt/data/R7_asym_paired_4method_MC1000_s1p18bc0p20_TARGETED_v1'); OUTDIR.mkdir(exist_ok=True)

def det(v): return float(v.deterministic() if hasattr(v,'deterministic') else v)
def as3(value,down,up,profit=False):
    ml=float(value)
    return eng.ThreePoint(round(ml*(1+up),6),round(ml,6),round(ml*(1-down),6)) if profit else eng.ThreePoint(round(ml*(1-down),6),round(ml,6),round(ml*(1+up),6))
def stress(ps):
    for p in ps:
        p.base_profit=as3(p.deterministic_base_profit(),.30,.05,True)
        d=p.deterministic_duration(); p.duration=eng.ThreePoint(max(1,round(float(d)*.95,6)),round(float(d),6),max(1,round(float(d)*1.15,6)))
        if p.budget_usage_profile: p.budget_usage_profile=[as3(det(v),.05,.10) for v in p.budget_usage_profile]
        if p.constraint_usage_profile: p.constraint_usage_profile=[as3(det(v),.05,.10) for v in p.constraint_usage_profile]
    return ps
def world(seed,mc):
    p,ps=gens.GENS['R7_AOCTANE_SWAP_TRIUMPH'](seed,mc); stress(ps); p.portfolio_id += '_asym_paired_targeted'; p.monte_carlo_iterations=mc; return p,ps
def pref(pid): return ''.join(c for c in pid if c.isalpha())
def subset_scenarios(ids, scs):
    ids=set(ids)
    return [eng.MonteCarloScenario(project_vectors={pid:sc.project_vectors[pid] for pid in ids},linear_cot_deltas={pid:sc.linear_cot_deltas[pid] for pid in ids if pid in sc.linear_cot_deltas},piecewise_cot_values={pid:sc.piecewise_cot_values[pid] for pid in ids if pid in sc.piecewise_cot_values},synergy_values={(pid,i):v for (pid,i),v in sc.synergy_values.items() if pid in ids}) for sc in scs]
def eval_ids(p,ps,ids,seq_ids,scs):
    pmap={x.project_id:x for x in ps}; ids=list(ids); seq=[pmap[i] for i in seq_ids if i in pmap and i in set(ids)]
    # append missing ids deterministically
    seq += [pmap[i] for i in ids if i not in {x.project_id for x in seq}]
    seq=eng._dependency_aware_stable_order(seq)
    selected=[pmap[i] for i in ids]
    stage=eng.stage_sequence(seq,p)
    if not stage.feasible:
        return {'selected_count':len(ids),'selected_ids':ids,'sequence_ids':[x.project_id for x in seq],'stage_feasible':False,'stage_failure_reason':stage.failure_reason,'budget_feasibility_rate':0.0,'constraint_feasibility_rate':0.0,'admissible':False,'p85_profit':0.0,'profits_n':0}
    br,cr,adm,p85,profits=eng.evaluate_stochastic_from_scenarios(p,selected,seq,subset_scenarios(ids,scs),optimistic_prefilter=False)
    return {'selected_count':len(ids),'selected_ids':ids,'sequence_ids':[x.project_id for x in seq],'stage_feasible':True,'stage_failure_reason':None,'budget_feasibility_rate':br,'constraint_feasibility_rate':cr,'admissible':bool(adm),'p85_profit':p85,'profits_n':len(profits)}
def eval_candidate(p,ps,ids,order,scs):
    pmap={x.project_id:x for x in ps}; ids=runner.dependency_closure_ids(eng,ids,pmap); seq=runner.sequence_by_order(eng,ids,pmap,order); return eval_ids(p,ps,ids,[x.project_id for x in seq],scs)
def better(a,b):
    if b is None: return True
    if bool(a['admissible'])!=bool(b['admissible']): return bool(a['admissible'])
    return a['p85_profit']>b['p85_profit']
def make_targeted_orders(ps, baseline):
    U=sorted([x for x in ps if pref(x.project_id)=='U'],key=lambda p:(-runner.time_pressure(p),-p.deterministic_base_profit(),p.project_id))
    Up=sorted([x for x in ps if pref(x.project_id)=='U'],key=lambda p:(-p.deterministic_base_profit(),p.project_id))
    B=sorted([x for x in ps if pref(x.project_id)=='B'],key=lambda p:(runner.constraint_total(eng,p),-p.deterministic_base_profit(),p.project_id))
    F=sorted([x for x in ps if pref(x.project_id)=='F'],key=lambda p:(-runner.time_pressure(p),-p.deterministic_base_profit(),p.project_id))
    E=sorted([x for x in ps if pref(x.project_id)=='E'],key=lambda p:(runner.constraint_total(eng,p),-p.deterministic_base_profit(),p.project_id))
    method_sequences={m:baseline['methods'][m].get('sequence_ids',[]) for m in ['MSA','Octane','aOctane']}
    orders=runner.make_orders(eng,ps,method_sequences)
    orders['r7_u_time_f_b_e']=[x.project_id for x in U+F+B+E]
    orders['r7_u_profit_f_b_e']=[x.project_id for x in Up+F+B+E]
    orders['r7_f_u_b_e']=[x.project_id for x in F+U+B+E]
    orders['r7_bf_then_u_time']=[x.project_id for x in B+F+U+E]
    return orders, U, Up, B, F, E
def targeted_scpa_search(seed):
    p,ps=world(seed,SEARCH_MC); baseline=eng.serialize_world_result(eng.run_world(p,ps,world_seed=seed*1000)); orders,U,Up,B,F,E=make_targeted_orders(ps,baseline)
    pmap={x.project_id:x for x in ps}; seen=set(); subsets=[]
    def add(ids,src):
        ids=runner.dependency_closure_ids(eng,ids,pmap); key=tuple(ids)
        if len(ids)>=2 and key not in seen:
            seen.add(key); subsets.append((ids,src))
    Bids=[x.project_id for x in B]; Fids=[x.project_id for x in F]; Utime=[x.project_id for x in U]; Uprof=[x.project_id for x in Up]
    # core R7 sCPA-lite combination family: avoid heavy E block unless method baseline selected it; vary urgent block size/order.
    for k in range(0,len(Utime)+1): add(Bids+Fids+Utime[:k],f'BF_Utime_{k}')
    for k in range(0,len(Uprof)+1): add(Bids+Fids+Uprof[:k],f'BF_Uprofit_{k}')
    add([x.project_id for x in B+F+U], 'nonE_all')
    # include first-three selected sets as controls inside sCPA candidate family
    for m in ['MSA','Octane','aOctane']: add(baseline['methods'][m].get('selected_ids',[]),f'{m}_selected')
    scs=eng.generate_mc_scenarios(p,ps,seed*1000+424242)
    order_names=['r7_u_time_f_b_e','r7_u_profit_f_b_e','r7_f_u_b_e','r7_bf_then_u_time','time_pressure','profit_desc','low_constraint','pcucu_desc','aOctane_sequence','Octane_sequence']
    best=None; evals=0
    for ids,src in subsets:
        for on in order_names:
            cand=eval_candidate(p,ps,ids,orders[on],scs); evals+=1; cand['source']=src; cand['sequence_name']=on
            if better(cand,best): best=cand
    return {'baseline_selection':baseline,'candidate':best,'subsets_generated':len(subsets),'candidate_evaluations':evals,'search_mc':SEARCH_MC,'search_variant':'targeted R7 sCPA-lite BF/U combination-permutation family (MC100 search)'}
def pct(delta, denom): return None if denom is None or denom<=DENOM_EPS else delta/denom*100.0
def run_seed(seed):
    st=time.time(); search=targeted_scpa_search(seed)
    p,ps=world(seed,FINAL_MC); scs=eng.generate_mc_scenarios(p,ps,seed*1000+424242)
    baseline=search['baseline_selection']; methods={}
    for m in ['MSA','Octane','aOctane']:
        md=baseline['methods'][m]; methods[m]=eval_ids(p,ps,md.get('selected_ids',[]),md.get('sequence_ids',[]),scs)
    cand=search['candidate']; methods['sCPA_lite']=eval_ids(p,ps,cand['selected_ids'],cand['sequence_ids'],scs)
    admiss3=[(m,methods[m]['p85_profit']) for m in ['MSA','Octane','aOctane'] if methods[m]['admissible'] and methods[m]['stage_feasible'] and methods[m]['selected_count']>0]
    best3=max(admiss3,key=lambda x:x[1]) if admiss3 else (None,None)
    admiss4=[(m,methods[m]['p85_profit']) for m in methods if methods[m]['admissible'] and methods[m]['stage_feasible'] and methods[m]['selected_count']>0]
    best4=max(admiss4,key=lambda x:x[1]) if admiss4 else (None,None)
    delta=methods['sCPA_lite']['p85_profit']-best3[1] if best3[1] is not None and methods['sCPA_lite']['admissible'] else None
    out={'test_id':'R7_asymmetric_paired_4method_MC1000_s1p18bc0p20_TARGETED_v1','seed':seed,'regime':'R7_AOCTANE_SWAP_TRIUMPH','technical_template_id':'AOSWAP_STRONG_s1p18_bc0p20','engine_root':str(ENGINE_ROOT),'selection_search_mc':SEARCH_MC,'final_eval_mc':FINAL_MC,'common_random_number_seed':seed*1000+424242,'uncertainty_model':{'profit':'triangular 70/100/105','duration':'triangular 95/100/115 min 1','budget_usage':'triangular 95/100/110','constraint_usage':'triangular 95/100/110'},'search_stage':search,'final_mc1000_methods':methods,'best3_method':best3[0],'best3_p85':best3[1],'best4_method':best4[0],'best4_p85':best4[1],'scpa_delta_vs_best3':delta,'scpa_uplift_pct_vs_best3_positive_denominator_only':pct(delta,best3[1]) if delta is not None else None,'scpa_beats_best3_abs':bool(delta is not None and delta>0),'runtime_seconds':time.time()-st}
    (OUTDIR/f'seed{seed:03d}.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
    return out
def main():
    rows=[]
    for seed in SEEDS:
        r=run_seed(seed); rows.append(r)
        print(json.dumps({'seed':seed,'best3':r['best3_method'],'best3_p85':r['best3_p85'],'scpa_p85':r['final_mc1000_methods']['sCPA_lite']['p85_profit'],'scpa_adm':r['final_mc1000_methods']['sCPA_lite']['admissible'],'delta':r['scpa_delta_vs_best3'],'uplift_pct':r['scpa_uplift_pct_vs_best3_positive_denominator_only'],'best4':r['best4_method'],'runtime':round(r['runtime_seconds'],2)},ensure_ascii=False),flush=True)
    compact=[]
    for r in rows:
        d={'seed':r['seed'],'best3_method':r['best3_method'],'best3_p85':r['best3_p85'],'best4_method':r['best4_method'],'best4_p85':r['best4_p85'],'scpa_delta_vs_best3':r['scpa_delta_vs_best3'],'scpa_uplift_pct_pos_den_only':r['scpa_uplift_pct_vs_best3_positive_denominator_only'],'scpa_beats_best3_abs':r['scpa_beats_best3_abs'],'search_subsets':r['search_stage']['subsets_generated'],'search_candidate_evaluations':r['search_stage']['candidate_evaluations']}
        for m in ['MSA','Octane','aOctane','sCPA_lite']:
            md=r['final_mc1000_methods'][m]
            d[f'{m}_p85']=md['p85_profit']; d[f'{m}_admissible']=md['admissible']; d[f'{m}_budget_feas']=md['budget_feasibility_rate']; d[f'{m}_constraint_feas']=md['constraint_feasibility_rate']; d[f'{m}_selected_count']=md['selected_count']
        compact.append(d)
    deltas=[r['scpa_delta_vs_best3'] for r in rows if r['scpa_delta_vs_best3'] is not None]; uplifts=[r['scpa_uplift_pct_vs_best3_positive_denominator_only'] for r in rows if r['scpa_uplift_pct_vs_best3_positive_denominator_only'] is not None]
    summary={'test_id':'R7_asymmetric_paired_4method_MC1000_s1p18bc0p20_TARGETED_v1','status':'paired 4-method final MC1000 test. All methods are final-evaluated on the same 10 worlds/seeds, same asymmetric uncertainty model, same common MC1000 scenario matrix per world, same P85 metric, same >=80% budget and constraint admissibility thresholds. sCPA-lite uses a targeted R7 BF/U combination-permutation search at MC50 before final MC1000 evaluation; therefore this is a paired FAST/TARGETED rerun, not an exhaustive sCPA search.', 'world_count':len(rows),'method_world_evaluations':len(rows)*4,'seeds':SEEDS,'selection_search_mc':SEARCH_MC,'final_eval_mc':FINAL_MC,'scpa_admissible_worlds':sum(r['final_mc1000_methods']['sCPA_lite']['admissible'] for r in rows),'scpa_beats_best3_abs_worlds':sum(r['scpa_beats_best3_abs'] for r in rows),'scpa_best4_worlds':sum(r['best4_method']=='sCPA_lite' for r in rows),'median_scpa_p85':statistics.median([r['final_mc1000_methods']['sCPA_lite']['p85_profit'] for r in rows]),'median_best3_p85':statistics.median([r['best3_p85'] for r in rows if r['best3_p85'] is not None]),'median_delta_vs_best3':statistics.median(deltas),'mean_delta_vs_best3':statistics.mean(deltas),'min_delta_vs_best3':min(deltas),'max_delta_vs_best3':max(deltas),'median_uplift_pct_positive_best3_only':statistics.median(uplifts) if uplifts else None,'mean_uplift_pct_positive_best3_only':statistics.mean(uplifts) if uplifts else None,'positive_denominator_worlds_for_pct':len(uplifts),'method_admissible_counts':{m:sum(r['final_mc1000_methods'][m]['admissible'] for r in rows) for m in ['MSA','Octane','aOctane','sCPA_lite']},'best4_counts':{m:sum(r['best4_method']==m for r in rows) for m in ['MSA','Octane','aOctane','sCPA_lite',None]},'median_scpa_budget_feas':statistics.median([r['final_mc1000_methods']['sCPA_lite']['budget_feasibility_rate'] for r in rows]),'median_scpa_constraint_feas':statistics.median([r['final_mc1000_methods']['sCPA_lite']['constraint_feasibility_rate'] for r in rows]),'median_scpa_selected_count':statistics.median([r['final_mc1000_methods']['sCPA_lite']['selected_count'] for r in rows]),'runtime_total_seconds':sum(r['runtime_seconds'] for r in rows)}
    with open(OUTDIR/'per_seed_summary.csv','w',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=list(compact[0].keys())); w.writeheader(); w.writerows(compact)
    (OUTDIR/'summary.json').write_text(json.dumps({'summary':summary,'rows':compact},indent=2,ensure_ascii=False),encoding='utf-8')
    report=['POL R7 asymmetric uncertainty — paired 4-method MC1000 TARGETED v4 MC100-search','',summary['status'],'','Headline:',f"- Worlds: {summary['world_count']}; method-world final evaluations: {summary['method_world_evaluations']}",f"- sCPA-lite admissible: {summary['scpa_admissible_worlds']} / {summary['world_count']}",f"- sCPA-lite beats Best3: {summary['scpa_beats_best3_abs_worlds']} / {summary['world_count']}",f"- sCPA-lite is Best4: {summary['scpa_best4_worlds']} / {summary['world_count']}",f"- median sCPA P85: {summary['median_scpa_p85']:.6f}",f"- median Best3 P85: {summary['median_best3_p85']:.6f}",f"- median delta vs Best3: {summary['median_delta_vs_best3']:.6f}",f"- mean delta vs Best3: {summary['mean_delta_vs_best3']:.6f}",f"- min/max delta vs Best3: {summary['min_delta_vs_best3']:.6f} / {summary['max_delta_vs_best3']:.6f}"]
    if summary['median_uplift_pct_positive_best3_only'] is not None: report.append(f"- median pct uplift, positive Best3 denominator only: {summary['median_uplift_pct_positive_best3_only']:.6f}% over {summary['positive_denominator_worlds_for_pct']} worlds")
    report += ['', 'Admissibility counts:'] + [f"- {m}: {c} / {summary['world_count']}" for m,c in summary['method_admissible_counts'].items()]
    report += ['', 'Important limitation: sCPA-lite search is TARGETED/FAST, not exhaustive. The final MC1000 comparison itself is paired and fair; the search breadth remains an explicit limitation.']
    (OUTDIR/'REPORT_BG.txt').write_text('\n'.join(report),encoding='utf-8')
    (OUTDIR/'README.txt').write_text(summary['status']+'\n',encoding='utf-8')
    zip_path=Path('/mnt/data/POL_R7_asymmetric_paired_4method_MC1000_s1p18bc0p20_TARGETED_v1.zip')
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(Path(__file__),arcname='run_r7_asym_paired_4method_mc1000_s1p18bc0p20_targeted_v1.py'); z.write('/mnt/data/pol_scpa_lite_runner.py',arcname='pol_scpa_lite_runner.py')
        for p in OUTDIR.rglob('*'): z.write(p,arcname=str(p.relative_to(OUTDIR.parent)))
    print(json.dumps(summary,indent=2,ensure_ascii=False),flush=True); print('ZIP',zip_path,flush=True)
if __name__=='__main__': main()
