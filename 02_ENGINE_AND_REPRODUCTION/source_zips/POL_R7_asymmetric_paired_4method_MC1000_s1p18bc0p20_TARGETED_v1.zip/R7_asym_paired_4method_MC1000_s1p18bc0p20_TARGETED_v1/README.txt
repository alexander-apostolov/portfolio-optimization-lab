Corrected R7 s1p18_bc0p20 asymmetric paired 4-method MC1000 targeted run. See REPORT.md, summary.json and per_seed_summary.csv.
