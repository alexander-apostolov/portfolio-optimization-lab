# POL R7 asymmetric paired 4-method MC1000 corrected-template run

Status: corrected-template targeted benchmark, not exhaustive sCPA.
Template: AOSWAP_STRONG_s1p18_bc0p20.

Asymmetric uncertainty applied identically to all methods: profit -30%/+5%; duration -5%/+15%; budget usage -5%/+10%; constraint usage -5%/+10%.

## Headline
- Worlds/seeds: 10 ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
- Final evaluation: MC1000 with common random numbers per world
- sCPA-lite admissible: 10/10
- Worlds with at least one admissible ranking method: 9/10
- sCPA-lite beats best admissible ranking method: 9/9
- Ranking rescue worlds (no admissible MSA/O/aO): 1/10
- Strict 4-way comparable worlds: 4/10 seeds [1, 3, 5, 7]
- In strict 4-way comparable worlds, sCPA-lite beats all three ranking methods: 4/4

## Aggregation
- median_sCPA_p85: 3677.4810125020995
- median_best_admissible_ranking_p85: 565.6911957368856
- median_delta_vs_best_admissible_ranking: 3030.9353954536596
- mean_delta_vs_best_admissible_ranking: 3130.8673591636352
- min_delta_vs_best_admissible_ranking: 2191.5749015115025
- max_delta_vs_best_admissible_ranking: 4354.476781409329
- median_uplift_pct_positive_denominator_only: 536.8940555170616
- uplift_positive_denominator_worlds: 8
- median_sCPA_selected_count: 24.0
- median_sCPA_budget_feas: 1.0
- median_sCPA_constraint_feas: 1.0

## Per-seed short table
| Seed | Best admissible ranking | Best admiss. ranking P85 | sCPA P85 | Δ | Uplift % | MSA adm | O adm | aO adm | sCPA selected |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | aOctane | 579.975 | 3598.120 | 3018.145 | 520.39 | True | True | True | 24 |
| 2 | aOctane | 955.077 | 3749.455 | 2794.379 | 292.58 | False | True | True | 23 |
| 3 | aOctane | 370.803 | 3658.761 | 3287.958 | 886.71 | True | True | True | 24 |
| 4 | Octane | -656.642 | 3697.835 | 4354.477 |  | False | True | True | 24 |
| 5 | aOctane | 188.365 | 3614.879 | 3426.513 | 1819.08 | True | True | True | 23 |
| 6 | None |  | 3655.863 |  |  | False | False | False | 23 |
| 7 | aOctane | 365.536 | 3308.851 | 2943.314 | 805.20 | True | True | True | 24 |
| 8 | MSA | 565.691 | 3696.201 | 3130.510 | 553.40 | True | False | False | 24 |
| 9 | MSA | 1578.275 | 3769.849 | 2191.575 | 138.86 | True | False | False | 24 |
| 10 | aOctane | 694.862 | 3725.798 | 3030.935 | 436.19 | False | True | True | 23 |

## Search limitation
Full exhaustive sCPA is not feasible for this 38-project world family inside this run: 2^38 = 274,877,906,944 subsets before sequencing/permutation evaluation. The reported sCPA-lite result is targeted: BF/U family plus sequence variants, MC100 search, MC1000 finalist validation.