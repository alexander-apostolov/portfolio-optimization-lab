This folder contains v26 historical documentation kept for traceability only.
The current package is v27. For current R7 metrics and interpretation, use:
- docs/POL3_v27_R7_Dual_Gap_Canonical_Update_Report.txt
- docs/POL3_v27_MC100_MC500_Regeneration_Status.txt
- results/MC100/POL3_v27_Step1_MC100_summary.*
- results/MC500/POL3_v27_Step1_MC500_summary.*
