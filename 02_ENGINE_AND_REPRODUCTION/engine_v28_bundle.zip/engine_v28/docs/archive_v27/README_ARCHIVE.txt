Archived v27 documentation.

These files describe the v27 seven-regime package and the v27 dual-gap R7 update. In v28, the canonical View 1 set is reduced/rebuilt to six regimes and the weak/superseded v27 R5/R6 are not part of the canonical set.
