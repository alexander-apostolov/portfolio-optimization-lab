#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

REGIMES = ['R1_MSA_STRATEGIC_WIN','R2_MSA_SEQUENCING_EDGE','R3_NEUTRAL_KNOWLEDGE_WORK','R4_AOCTANE_TRANSITION','R5_AOCTANE_TIME_CONSTRAINT_WIN','R6_AOCTANE_STRONGHOLD','R7_AOCTANE_SWAP_TRIUMPH']
AO_FRIENDLY = {'R4_AOCTANE_TRANSITION','R5_AOCTANE_TIME_CONSTRAINT_WIN','R6_AOCTANE_STRONGHOLD','R7_AOCTANE_SWAP_TRIUMPH'}
MSA_FRIENDLY = {'R1_MSA_STRATEGIC_WIN','R2_MSA_SEQUENCING_EDGE'}
NEUTRAL = {'R3_NEUTRAL_KNOWLEDGE_WORK'}


def load(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def main() -> int:
    ap = argparse.ArgumentParser(description='Directional check for optional independent random MC500 samples. This is not an exact-match canonical reproduction test.')
    ap.add_argument('--results-dir', default=None, help='Defaults to <package_root>/results/random_mc500')
    ap.add_argument('--sample-size', type=int, default=None, help='Expected sample size; optional.')
    args = ap.parse_args()
    package_root = Path(__file__).resolve().parents[1]
    rdir = Path(args.results_dir).resolve() if args.results_dir else package_root / 'results' / 'random_mc500'
    failures = []
    warnings = []
    for r in REGIMES:
        matches = sorted(rdir.glob(f'random_mc500_{r}_n*_selmc100_evalmc500.json'))
        if not matches:
            failures.append(f'{r}: missing random sample result')
            continue
        d = load(matches[-1])
        n = d.get('world_count')
        if args.sample_size is not None and n != args.sample_size:
            warnings.append(f'{r}: sample size {n}, expected {args.sample_size}')
        if d.get('invariant_violations'):
            failures.append(f'{r}: invariant violations {d.get("invariant_violations")}')
        i3 = d.get('iteration3_metrics', {})
        w = i3.get('median_denominator_safe_percent_waste', {})
        ws = d.get('winner_share', {})
        print(f'{r}: n={n} accepted={d.get("accepted_worlds")} winner_share={ws} median %Waste={w}')
        # Directional checks are intentionally advisory for small random samples.
        if d.get('accepted_worlds', 0) == 0:
            warnings.append(f'{r}: no accepted worlds in this random sample; increase POL_RANDOM_SAMPLE_SIZE')
            continue
        if r in AO_FRIENDLY and w.get('aOctane') is not None and w.get('MSA') is not None and w.get('aOctane') > w.get('MSA'):
            warnings.append(f'{r}: aOctane waste > MSA waste in this small random sample')
        if r in MSA_FRIENDLY and w.get('MSA') is not None and w.get('aOctane') is not None and w.get('MSA') > w.get('aOctane'):
            warnings.append(f'{r}: MSA waste > aOctane waste in this small random sample')
    if warnings:
        print('\nDIRECTIONAL WARNINGS')
        for x in warnings:
            print('-', x)
    if failures:
        print('\nDIRECTIONAL ROBUSTNESS CHECK FAILED')
        for x in failures:
            print('-', x)
        return 1
    print('\nDIRECTIONAL ROBUSTNESS CHECK COMPLETED')
    print('Note: random MC500 robustness is directional, not an exact-match reproduction test. Use larger POL_RANDOM_SAMPLE_SIZE for stronger evidence.')
    return 0

if __name__ == '__main__':
    sys.exit(main())
