#!/usr/bin/env python3
"""Basic structural validator for v28 six-regime View 1 generated reference artifacts.

The v28 source changes the canonical generators, so the old v24/v25 exact metric
expectations are intentionally not reused. This validator checks that a full
R1-R7 run produced complete artifacts and that core Step 1 invariants hold.
Exact v28 numerical expectations should be frozen only after a full clean-room
reference run has been accepted.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

REGIMES = [
    'R1_MSA_STRATEGIC_WIN',
    'R2_MSA_SEQUENCING_EDGE',
    'R3_NEUTRAL_KNOWLEDGE_WORK',
    'R5_BOTTLENECKED_KNOWLEDGE_WORK',
    'R4_AOCTANE_TRANSITION',
    'R7_AOCTANE_SWAP_TRIUMPH',
]



def default_results_dir() -> Path:
    return Path(__file__).resolve().parents[1] / 'results' / 'reproduced'


def validate_dir(results_dir: Path, eval_mc: int = 500) -> int:
    failures = []
    for r in REGIMES:
        path = results_dir / f'step1_{r}_001_040_selmc100_evalmc{eval_mc}.json'
        if not path.exists():
            failures.append(f'{r}: missing {path}')
            continue
        d = json.loads(path.read_text(encoding='utf-8'))
        if d.get('world_count') != 40:
            failures.append(f'{r}: world_count got {d.get("world_count")} expected 40')
        if len(d.get('invariant_violations', [])) != 0:
            failures.append(f'{r}: aOctane/Octane invariant violations present: {d.get("invariant_violations")}')
        if d.get('accepted_worlds') is None:
            failures.append(f'{r}: missing accepted_worlds')
        if 'iteration3_metrics' not in d:
            failures.append(f'{r}: missing iteration3_metrics')
        print(f'{r}: generated artifact present | worlds={d.get("world_count")} | accepted={d.get("accepted_worlds")} | winner_share={d.get("winner_share", {})}')
    if failures:
        print('\nVALIDATION FAILED')
        for f in failures:
            print('-', f)
        return 1
    print('\nALL V28 SIX-REGIME GENERATED REFERENCE ARTIFACTS PASSED BASIC STRUCTURAL VALIDATION')
    print('Note: exact v28 metric expectations are not frozen in this source-correction package.')
    return 0


def main():
    ap = argparse.ArgumentParser(description='Basic structural validation for generated v28 six-regime artifacts.')
    ap.add_argument('--results-dir', default=None)
    ap.add_argument('--eval-mc', type=int, default=500)
    args = ap.parse_args()
    return validate_dir(Path(args.results_dir).resolve() if args.results_dir else default_results_dir(), args.eval_mc)

if __name__ == '__main__':
    sys.exit(main())
