#!/usr/bin/env python3
"""Iteration 3 Step 1 alignment smoke tests for MSA / Octane / aOctane.

These tests focus on the engine rules introduced by the Iteration 3 methodology:
- ranking-based methods do not use optimistic staging/prefiltering;
- aOctane local swap candidates are dependency-aware and deterministic-feasibility screened before MC evaluation;
- evaluated_profit and waste metrics are calculated per-world before regime aggregation;
- denominator-unsafe percentage metrics are suppressed.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENGINE_PATH = ROOT / "scripts" / "pol_engine_benchmark_v14_dependency_order_guarded.py"

spec = importlib.util.spec_from_file_location("pol_engine", ENGINE_PATH)
eng = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = eng
spec.loader.exec_module(eng)


def make_portfolio() -> eng.PortfolioInputs:
    return eng.PortfolioInputs(
        portfolio_id="alignment_test",
        budget_restriction_profile=[999.0] * 5,
        constraint_capacity_profile=[999.0] * 5,
        monte_carlo_iterations=5,
        budget_confidence_level=0.8,
        constraint_confidence_level=0.8,
        profit_confidence_level=0.85,
    )


def make_project(pid: str, profit: float, deps=None) -> eng.Project:
    return eng.Project(
        project_id=pid,
        base_profit=profit,
        duration=1,
        budget_usage_profile=[1.0],
        constraint_usage_profile=[1.0],
        structural_dependencies=list(deps or []),
    )


def make_outcome(method: str, evaluated_profit: float, admissible: bool = True) -> eng.MethodOutcome:
    stage = eng.StageResult(True, [method], [eng.StageRecord(method, 0, 1)])
    return eng.MethodOutcome(
        method=method,
        selected_ids=[method],
        repaired_ids=[method],
        sequence_ids=[method],
        stage_result=stage,
        deterministic_profit=evaluated_profit,
        budget_feasibility_rate=1.0,
        constraint_feasibility_rate=1.0,
        admissible=admissible,
        p85_profit=evaluated_profit,
        evaluated_profit=evaluated_profit,
        mc_profits=[evaluated_profit],
    )


def test_no_optimistic_prefilter_by_default() -> None:
    portfolio = make_portfolio()
    projects = [make_project("P1", 100.0)]
    scenarios = eng.generate_mc_scenarios(portfolio, projects, 123)

    original = eng._project_sampled_vectors

    def guard(project, rng, optimistic=False):
        if optimistic:
            raise AssertionError("optimistic sampling should not be used by default")
        return original(project, rng, optimistic=optimistic)

    eng._project_sampled_vectors = guard
    try:
        budget_rate, constraint_rate, admissible, p85, profits = eng.evaluate_stochastic_from_scenarios(
            portfolio, projects, projects, scenarios
        )
    finally:
        eng._project_sampled_vectors = original

    assert budget_rate == 1.0
    assert constraint_rate == 1.0
    assert admissible is True
    assert p85 > 0
    assert profits


def test_aoctane_dependency_swap_not_mc_evaluated() -> None:
    portfolio = make_portfolio()
    a = make_project("A", 100.0)
    b = make_project("B", 90.0, deps=["A"])
    selected = [a, b]
    scenarios = eng.generate_mc_scenarios(portfolio, selected, 456)

    original = eng.evaluate_stochastic_from_scenarios
    calls = {"n": 0}

    def counting_eval(*args, **kwargs):
        calls["n"] += 1
        return original(*args, **kwargs)

    eng.evaluate_stochastic_from_scenarios = counting_eval
    try:
        sequence, stage, objective = eng.improve_aoctane_sequence(selected, [a, b], portfolio, scenarios=scenarios)
    finally:
        eng.evaluate_stochastic_from_scenarios = original

    assert [p.project_id for p in sequence] == ["A", "B"]
    assert stage.feasible is True
    # one call for current objective; the invalid/same dependency-aware swap is not MC-evaluated
    assert calls["n"] == 1
    assert objective > 0


def test_waste_and_pairwise_metrics() -> None:
    methods = {
        "MSA": make_outcome("MSA", 100.0),
        "Octane": make_outcome("Octane", 200.0),
        "aOctane": make_outcome("aOctane", 300.0),
    }
    pairwise = eng.apply_iteration3_world_metrics(methods)

    assert methods["aOctane"].winner_flag is True
    assert methods["aOctane"].absolute_waste == 0.0
    assert methods["Octane"].absolute_waste == 100.0
    assert round(methods["Octane"].percent_waste, 6) == round(100.0 / 300.0 * 100.0, 6)
    assert methods["MSA"].absolute_waste == 200.0
    assert round(methods["MSA"].percent_waste, 6) == round(200.0 / 300.0 * 100.0, 6)
    assert pairwise["aOctane_vs_Octane"]["percent_delta_profit"] == 50.0
    assert pairwise["aOctane_vs_MSA"]["percent_delta_profit"] == 200.0


def test_negative_evaluated_profit_policy() -> None:
    methods = {
        "MSA": make_outcome("MSA", -50.0),
        "Octane": make_outcome("Octane", 80.0),
        "aOctane": make_outcome("aOctane", 100.0),
    }
    pairwise = eng.apply_iteration3_world_metrics(methods)

    # Negative evaluated profit is included in absolute waste and %Waste when Best Profit_w is positive.
    assert methods["aOctane"].winner_flag is True
    assert methods["MSA"].absolute_waste == 150.0
    assert methods["MSA"].percent_waste == 150.0

    # But negative evaluated profit is not a valid denominator for pairwise %Delta Profit.
    assert pairwise["aOctane_vs_MSA"]["delta_profit"] == 150.0
    assert pairwise["aOctane_vs_MSA"]["percent_delta_profit"] is None
    assert pairwise["aOctane_vs_MSA"]["denominator_safe"] is False


def test_denominator_safety_for_pairwise_percentages() -> None:
    methods = {
        "MSA": make_outcome("MSA", 0.0),
        "Octane": make_outcome("Octane", 200.0),
        "aOctane": make_outcome("aOctane", 300.0),
    }
    pairwise = eng.apply_iteration3_world_metrics(methods)
    assert pairwise["aOctane_vs_MSA"]["percent_delta_profit"] is None
    assert pairwise["aOctane_vs_MSA"]["denominator_safe"] is False
    assert pairwise["aOctane_vs_MSA"]["delta_profit"] == 300.0


if __name__ == "__main__":
    tests = [
        test_no_optimistic_prefilter_by_default,
        test_aoctane_dependency_swap_not_mc_evaluated,
        test_waste_and_pairwise_metrics,
        test_negative_evaluated_profit_policy,
        test_denominator_safety_for_pairwise_percentages,
    ]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")
    print("ALL ITERATION 3 STEP 1 ALIGNMENT TESTS PASSED")
