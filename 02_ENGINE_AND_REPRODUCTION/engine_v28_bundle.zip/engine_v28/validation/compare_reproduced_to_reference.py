#!/usr/bin/env python3
"""Disabled exact reference comparison for v27 canonical package.

The v26 base-profit-relative urgency source changes the canonical generators.
Therefore the old v24/v25 reference artifacts are not bundled and must not be
used for exact comparison. After a full v26 reference run is accepted, freeze
those artifacts in a new canonical package and re-enable exact comparison.
"""
print('Exact reproduced-to-reference comparison is intentionally disabled in this v27 canonical package.')
print('Reason: v24/v25 reference metrics are superseded by base-profit-relative urgency generator changes.')
