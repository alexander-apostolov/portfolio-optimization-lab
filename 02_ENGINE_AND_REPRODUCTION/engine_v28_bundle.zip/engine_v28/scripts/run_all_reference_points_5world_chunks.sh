#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p ../results/reproduced/chunks
for regime in R1_MSA_STRATEGIC_WIN R2_MSA_SEQUENCING_EDGE R3_NEUTRAL_KNOWLEDGE_WORK R5_BOTTLENECKED_KNOWLEDGE_WORK R4_AOCTANE_TRANSITION R7_AOCTANE_SWAP_TRIUMPH; do
  for start in 1 6 11 16 21 26 31 36; do
    end=$((start + 4))
    out="../results/reproduced/chunks/step1_${regime}_$(printf '%03d' "$start")_$(printf '%03d' "$end")_selmc100_evalmc500.json"
    if [ -f "$out" ]; then
      echo "SKIP existing $out"
    else
      python run_reference_point.py "$regime" --start "$start" --end "$end" --selection-mc 100 --eval-mc 500 --outdir ../results/reproduced/chunks
    fi
  done
  python merge_reference_worlds.py "$regime" --start 1 --end 40 --selection-mc 100 --eval-mc 500 --indir ../results/reproduced/chunks --outdir ../results/reproduced
done
python ../validation/validate_reference_results.py --results-dir ../results/reproduced
