#!/usr/bin/env python3
from __future__ import annotations
import random

import pol_step1_structured_regime_lab_v14 as lab
from pol_step1_reference_common import make_project, portfolio, eng


def _urgency_from_time_erosion(cot_delta: float, base_profit: float | None = None) -> str:
    """Derive MSA urgency from relative cost-of-time erosion.

    POL3 says the MSA urgency class is based on value erosion over time.  The
    generator therefore uses a scale-free rule: urgency is based on the share of
    the project's base profit lost per period, not on an absolute delta.

    Canonical rule for linear cost of time:
    - High:   |linear_delta_per_period| / |base_profit| >= 10%
    - Medium: 1% <= |linear_delta_per_period| / |base_profit| < 10%
    - Normal: |linear_delta_per_period| / |base_profit| < 1%

    ``base_profit`` is optional only for backward-compatible call sites whose
    value is recomputed by the project factory.  Actual stored project urgency is
    enforced in ``lab.make_project`` and ``_aoswap_make_project`` using the
    project's own most-likely base profit.
    """
    if base_profit is None:
        # Compatibility only: project factories recompute the stored urgency.
        return 'Normal'
    denom = max(abs(float(base_profit)), 1e-9)
    ratio = abs(float(cot_delta)) / denom
    if ratio >= 0.10:
        return 'High'
    if ratio >= 0.01:
        return 'Medium'
    return 'Normal'


def gen_KW1(seed: int, mc: int = 500):
    return lab.gen_kw1(seed, mc)


def gen_SEQPOLE0p00(seed: int, mc: int = 500):
    return gen_seqpole(seed, alpha=0.0, mc=mc)


def gen_DAOPOLE_P(seed: int, mc: int = 500):
    return gen_daopole(seed, variant='P', mc=mc)


def gen_AOBOUND_SAFE1p5(seed: int, mc: int = 500):
    return gen_aobound_safe(seed, intensity=1.5, mc=mc)


def gen_MSAWIDE_A(seed: int, mc: int = 500):
    rng = random.Random(72000 + seed)
    projects = []
    for i in range(1, 8):
        projects.append(make_project(
            f'W{i:02d}', rng.uniform(340, 520), rng.choice([3, 3, 4]), rng.uniform(48, 82), rng.uniform(3.9, 5.6), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(44.0, 66.0))), cot, profit_spread=0.032, budget_spread=0.022,
            constraint_spread=0.022, duration_spread=0.015,
        ))
    for i in range(8, 18):
        projects.append(make_project(
            f'W{i:02d}', rng.uniform(105, 190), rng.choice([1, 2, 2, 3]), rng.uniform(18, 48), rng.uniform(0.38, 1.18), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(0.25, 2.2))), cot,
            profit_spread=0.035, budget_spread=0.024, constraint_spread=0.024, duration_spread=0.018,
        ))
    for i in range(18, 24):
        projects.append(make_project(
            f'W{i:02d}', rng.uniform(70, 145), rng.choice([1, 2, 2, 3]), rng.uniform(20, 54), rng.uniform(0.75, 1.95), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(0.3, 2.8))), cot,
            profit_spread=0.038, budget_spread=0.026, constraint_spread=0.026, duration_spread=0.020,
        ))
    budget = [385, 370, 355, 340, 325, 310, 295, 280, 265, 250, 235, 220, 205, 190]
    capacity = [15.4, 15.0, 14.6, 14.1, 13.7, 13.2, 12.8, 12.4, 12.0, 11.6, 11.2, 10.8, 10.4, 10.0]
    return portfolio(f'MSAWIDE_A_seed_{seed}', budget, capacity, mc), projects


def gen_AOWIDE_T(seed: int, mc: int = 500):
    rng = random.Random(82000 + seed)
    projects = []
    for i in range(1, 14):
        projects.append(make_project(
            f'Z{i:02d}', rng.uniform(235, 385), rng.choice([2, 2, 3]), rng.uniform(30, 72), rng.uniform(0.32, 1.05), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(15.0, 30.0))), cot,
            profit_spread=0.030, budget_spread=0.020, constraint_spread=0.020, duration_spread=0.014,
        ))
    for i in range(14, 21):
        projects.append(make_project(
            f'Z{i:02d}', rng.uniform(265, 420), rng.choice([3, 4, 4]), rng.uniform(58, 112), rng.uniform(4.1, 6.6), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(0.05, 0.95))), cot, profit_spread=0.034, budget_spread=0.024,
            constraint_spread=0.024, duration_spread=0.016,
        ))
    for i in range(21, 29):
        projects.append(make_project(
            f'Z{i:02d}', rng.uniform(80, 180), rng.choice([1, 2, 2, 3]), rng.uniform(18, 58), rng.uniform(0.45, 1.75), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(0.9, 5.0))), cot,
            profit_spread=0.036, budget_spread=0.024, constraint_spread=0.024, duration_spread=0.018,
        ))
    budget = [610, 590, 565, 540, 515, 490, 465, 440, 415, 390, 365, 340, 315, 290]
    capacity = [20.2, 20.0, 19.5, 19.0, 18.4, 17.8, 17.2, 16.6, 16.0, 15.4, 14.8, 14.2, 13.6, 13.0]
    return portfolio(f'AOWIDE_T_seed_{seed}', budget, capacity, mc), projects


def gen_seqpole(seed: int, alpha: float, mc: int = 500):
    rng = random.Random(123000 + int(alpha * 1000) * 1000 + seed)
    projects = []
    for i in range(1, 7):
        projects.append(make_project(
            f'Q{i:02d}', rng.uniform(230, 330), rng.choice([3, 3, 4]), rng.uniform(45, 85),
            rng.uniform(3.8 - 2.7 * alpha, 5.2 - 3.2 * alpha), rng, _urgency_from_time_erosion((cot := -rng.uniform(15.0, 24.0))), cot,
            profit_spread=0.035, budget_spread=0.025, constraint_spread=0.025, duration_spread=0.02,
        ))
    for i in range(7, 15):
        profit = rng.uniform(105, 175) * (1 - alpha) + rng.uniform(165, 245) * alpha
        cot = -rng.uniform(0.1, 0.8) * (1 - alpha) - rng.uniform(10.0, 18.0) * alpha
        urgency = _urgency_from_time_erosion(cot)
        projects.append(make_project(
            f'Q{i:02d}', profit, rng.choice([2, 2, 3]), rng.uniform(25, 60), rng.uniform(0.55, 1.35), rng,
            urgency, cot, profit_spread=0.035, budget_spread=0.025, constraint_spread=0.025, duration_spread=0.02,
        ))
    for i in range(15, 21):
        projects.append(make_project(
            f'Q{i:02d}', rng.uniform(65, 130), rng.choice([1, 2, 2]), rng.uniform(18, 48), rng.uniform(0.5, 1.8), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(0.5, 2.5))), cot, profit_spread=0.035, budget_spread=0.025,
            constraint_spread=0.025, duration_spread=0.02,
        ))
    budget = [330, 320, 305, 290, 275, 260, 245, 230, 215, 200, 185, 170]
    capacity = [13.5, 13.2, 12.8, 12.4, 12.0, 11.6, 11.2, 10.8, 10.4, 10.0, 9.6, 9.2]
    return portfolio(f'SEQPOLE{alpha:.2f}_seed_{seed}', budget, capacity, mc), projects


def gen_daopole(seed: int, variant: str = 'P', mc: int = 500):
    rng = random.Random({'N': 99700, 'O': 99800, 'P': 99900, 'Q': 100100}[variant] + seed)
    projects = []
    nstars = 11; star_p = (285, 430); star_cot = (18, 32); star_c = (0.45, 1.20)
    ele_p = (330, 455); ele_c = (4.8, 7.2); budget = 780; cap = 9.45; ehigh = 0.56; decline = (0.009, 0.007)
    for i in range(1, nstars + 1):
        projects.append(make_project(
            f'N{i:02d}', rng.uniform(*star_p), rng.choice([2, 2, 3]), rng.uniform(32, 68), rng.uniform(*star_c), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(*star_cot))), cot,
            profit_spread=0.028, budget_spread=0.018, constraint_spread=0.018, duration_spread=0.012,
        ))
    for i in range(nstars + 1, nstars + 7):
        projects.append(make_project(
            f'N{i:02d}', rng.uniform(*ele_p), rng.choice([4, 5, 5]), rng.uniform(68, 125), rng.uniform(*ele_c), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(0.05, 0.70))), cot,
            profit_spread=0.028, budget_spread=0.018, constraint_spread=0.018, duration_spread=0.012,
        ))
    for i in range(nstars + 7, 27):
        projects.append(make_project(
            f'N{i:02d}', rng.uniform(80, 175), rng.choice([1, 2, 2, 3]), rng.uniform(20, 55), rng.uniform(0.50, 2.0), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(0.8, 3.6))), cot,
            profit_spread=0.032, budget_spread=0.022, constraint_spread=0.022, duration_spread=0.018,
        ))
    bd, cd = decline
    b = [round(budget * (1 - bd * i), 2) for i in range(30)]
    c = [round(cap * (1 - cd * i), 2) for i in range(30)]
    return portfolio(f'DAOPOLE_{variant}_seed_{seed}', b, c, mc), projects


def gen_aobound_safe(seed: int, intensity: float = 1.5, mc: int = 500):
    rng = random.Random(62000 + seed + int(intensity * 1000))
    projects = []
    for i in range(1, 11):
        projects.append(lab.make_project(
            f'AB{i:02d}', rng.uniform(230, 360) * (1 + 0.06 * (intensity - 1)), rng.choice([2, 2, 3]),
            rng.uniform(32, 70), rng.uniform(0.35, 1.05), rng, _urgency_from_time_erosion((cot := -rng.uniform(12, 24) * (1 + 0.25 * (intensity - 1)))), cot,
            profit_spread=0.05, budget_spread=0.04, constraint_spread=0.04, duration_spread=0.04,
        ))
    for i in range(11, 19):
        projects.append(lab.make_project(
            f'AB{i:02d}', rng.uniform(200, 285), rng.choice([3, 4]), rng.uniform(58, 98),
            rng.uniform(3.8, 5.8) * (1 + 0.05 * (intensity - 1)), rng, _urgency_from_time_erosion((cot := -rng.uniform(0.1, 1.0))), cot,
            profit_spread=0.06, budget_spread=0.05, constraint_spread=0.05, duration_spread=0.05,
        ))
    for i in range(19, 31):
        projects.append(lab.make_project(
            f'AB{i:02d}', rng.uniform(55, 150), rng.choice([1, 2, 3]), rng.uniform(18, 55), rng.uniform(0.45, 2.0), rng,
            _urgency_from_time_erosion((cot := -rng.uniform(1.0, 5.0))), cot,
            profit_spread=0.06, budget_spread=0.04, constraint_spread=0.04, duration_spread=0.04,
        ))
    budget = [500, 485, 460, 435, 410, 385, 360, 335, 310, 285, 260, 235, 210]
    cap = [20, 20, 19, 18.5, 18, 17, 16, 15, 14, 13, 12, 11, 10]
    return lab.portfolio(f'AOBOUND_SAFE{intensity:.2f}_seed_{seed}', budget, cap, mc), projects




# --- R5 canonical bottlenecked knowledge-work regime -------------------
def _bkw_make_project(pid, profit, dur, budget_total, cpeak, cot_delta, rng, profit_spread=0.025):
    """Project factory for canonical R5 Bottlenecked Knowledge Work.

    R5 intentionally keeps duration/budget/constraint feasibility deterministic
    and uses stochastic profit only. This isolates the PCUCU selection effect of
    a scarce shared expert constraint in a knowledge-work portfolio.
    """
    urgency = _urgency_from_time_erosion(cot_delta, profit)
    shape = [rng.uniform(0.9, 1.1) for _ in range(dur)]
    ss = sum(shape)
    budget = [round(budget_total * x / ss, 3) for x in shape]
    constraint = [round(cpeak * rng.uniform(0.96, 1.04), 3) for _ in range(dur)] if cpeak > 1e-9 else [0.0] * dur
    return eng.Project(
        project_id=pid,
        base_profit=eng.ThreePoint(round(profit * (1 + profit_spread), 3), round(profit, 3), round(profit * (1 - profit_spread), 3)),
        duration=dur,
        budget_usage_profile=budget,
        constraint_usage_profile=constraint,
        urgency_class={'High': eng.Urgency.HIGH, 'Medium': eng.Urgency.MEDIUM, 'Normal': eng.Urgency.NORMAL}[urgency],
        cost_of_time_profile=eng.CostOfTimeProfile(
            profile_type=eng.CostOfTimeType.LINEAR,
            linear_delta_per_period=round(cot_delta, 3),
        ),
    )


def gen_BKWD_B(seed: int, mc: int = 500):
    """Canonical R5 Bottlenecked Knowledge Work regime.

    The regime models many small, mostly independent knowledge-work initiatives
    competing for a scarce shared expert/governance constraint.  It is designed
    as an Octane-family selection regime: PCUCU matters because the portfolio
    cannot include everything, while time sensitivity is deliberately low so
    aOctane should add little over Standard Octane.
    """
    rng = random.Random(1234000 + 27005 + seed)
    projects = []
    # Lean high-PCUCU knowledge tasks.
    for i in range(1, 29):
        profit = rng.uniform(125, 175)
        dur = rng.choice([1, 1, 2])
        budget_total = rng.uniform(5, 14)
        cpeak = rng.uniform(0.18, 0.45)
        cot = -rng.uniform(0.02, 0.25)
        projects.append(_bkw_make_project(f'L{i:02d}', profit, dur, budget_total, cpeak, cot, rng))
    # Profit-attractive but constraint-heavy knowledge tasks.
    for i in range(1, 9):
        profit = rng.uniform(170, 210)
        dur = rng.choice([4, 4, 5])
        budget_total = rng.uniform(18, 38)
        cpeak = rng.uniform(3.8, 5.2)
        cot = -rng.uniform(0.02, 0.25)
        projects.append(_bkw_make_project(f'H{i:02d}', profit, dur, budget_total, cpeak, cot, rng))
    # Small filler tasks.
    for i in range(1, 5):
        profit = rng.uniform(55, 95)
        dur = rng.choice([1, 2])
        budget_total = rng.uniform(5, 12)
        cpeak = rng.uniform(0.3, 0.9)
        cot = -rng.uniform(0.02, 0.25)
        projects.append(_bkw_make_project(f'F{i:02d}', profit, dur, budget_total, cpeak, cot, rng))
    budget = [900 for _ in range(10)]
    capacity = [round(max(1.2, 4.8 - 0.01 * i), 2) for i in range(10)]
    return eng.PortfolioInputs(
        f'BKWD_B_seed_{seed}',
        budget,
        capacity,
        budget_horizon_rule=eng.HorizonRule.ZERO_BEYOND,
        monte_carlo_iterations=mc,
        budget_confidence_level=0.80,
        constraint_confidence_level=0.80,
        profit_confidence_level=0.85,
    ), projects


# --- R7 canonical sequencing-stress regime -------------------------------
# Canonical R7 technical template: AOSWAP_STRONG_s1p18_bc0p20.
# The reproduction package treats this as the only canonical R7 regime.

def _aoswap_make_project(pid, profit, dur, budget_total, cpeak, urgency, cot_delta, rng, profit_spread=0.02):
    # Enforce POL3 urgency alignment at construction time.  The caller-supplied
    # urgency parameter is ignored for canonical generation; it is retained only
    # for backward-compatible function signature stability.
    urgency = _urgency_from_time_erosion(cot_delta, profit)
    shape = [rng.uniform(0.9, 1.1) for _ in range(dur)]
    ss = sum(shape)
    budget = [round(budget_total * x / ss, 3) for x in shape]
    constraint = [round(cpeak * rng.uniform(0.95, 1.05), 3) for _ in range(dur)]
    return eng.Project(
        project_id=pid,
        base_profit=eng.ThreePoint(round(profit * (1 + profit_spread), 3), round(profit, 3), round(profit * (1 - profit_spread), 3)),
        duration=dur,
        budget_usage_profile=budget,
        constraint_usage_profile=constraint,
        urgency_class={'High': eng.Urgency.HIGH, 'Medium': eng.Urgency.MEDIUM, 'Normal': eng.Urgency.NORMAL}[urgency],
        cost_of_time_profile=eng.CostOfTimeProfile(
            profile_type=eng.CostOfTimeType.LINEAR,
            linear_delta_per_period=round(cot_delta, 3),
        ),
    )


def gen_AOSWAP_STRONG_s1p18_bc0p20(seed: int, mc: int = 500):
    """Canonical R7 aOctane Swap Triumph regime.

    This is the canonical POL3 Step 1 local-swap sequencing-stress regime.
    It is designed to test the value of aOctane local sequence correction under
    strong sequencing leverage while preserving strict 40/40 accepted, 40/40
    three-way comparable Step 1 worlds in the bundled reference run.
    """
    stress = 1.18
    slack = 1.0
    capbase = 4.8
    u_c = 2.45
    b_c = 0.20
    e_c = 3.8
    rng = random.Random(990000 + seed)
    projects = []
    for i in range(1, 11):
        projects.append(_aoswap_make_project(
            f'U{i:02d}', rng.uniform(420, 520), rng.choice([2, 2, 3]), rng.uniform(34, 52), rng.uniform(u_c * 0.9, u_c * 1.1),
            _urgency_from_time_erosion((cot := -rng.uniform(55, 75) * stress)), cot, rng,
        ))
    for i in range(1, 13):
        projects.append(_aoswap_make_project(
            f'B{i:02d}', rng.uniform(155, 215), rng.choice([1, 2, 2]), rng.uniform(16, 28), rng.uniform(b_c * 0.8, b_c * 1.2),
            _urgency_from_time_erosion((cot := -rng.uniform(0.1, 0.8))), cot, rng,
        ))
    for i in range(1, 9):
        projects.append(_aoswap_make_project(
            f'E{i:02d}', rng.uniform(300, 380), rng.choice([3, 4, 4]), rng.uniform(82, 125), rng.uniform(e_c * 0.9, e_c * 1.1),
            _urgency_from_time_erosion((cot := -rng.uniform(0.2, 1.0))), cot, rng,
        ))
    for i in range(1, 9):
        projects.append(_aoswap_make_project(
            f'F{i:02d}', rng.uniform(70, 140), rng.choice([1, 2]), rng.uniform(12, 25), rng.uniform(0.4, 1.2),
            _urgency_from_time_erosion((cot := -rng.uniform(0.2, 2.0))), cot, rng,
        ))
    budget = [round(x * slack, 2) for x in [700, 680, 660, 640, 620, 600, 580, 560, 540, 520, 500, 480, 460, 440, 420, 400, 380, 360, 340, 320, 300, 280]]
    cap = [round(max(2.8, capbase - i * 0.03) * slack, 2) for i in range(len(budget))]
    port = eng.PortfolioInputs(
        portfolio_id=f'AOSWAP_STRONG_s1p18_bc0p20_seed_{seed}',
        budget_restriction_profile=budget,
        constraint_capacity_profile=cap,
        budget_horizon_rule=eng.HorizonRule.ZERO_BEYOND,
        monte_carlo_iterations=mc,
        budget_confidence_level=0.80,
        constraint_confidence_level=0.80,
        profit_confidence_level=0.85,
    )
    return port, projects


# Canonical POL3 regime naming. The R* IDs are used for reproduction scripts,
# reports and reference artifacts. Technical template IDs are preserved for traceability.
REGIME_META = {
    'R1_MSA_STRATEGIC_WIN': {'display_name': 'R1 — MSA Strategic Win', 'short_name': 'R1 MSA Win', 'technical_template_id': 'MSAWIDE_A'},
    'R2_MSA_SEQUENCING_EDGE': {'display_name': 'R2 — MSA Sequencing Edge', 'short_name': 'R2 MSA Edge', 'technical_template_id': 'SEQPOLE0p00'},
    'R3_NEUTRAL_KNOWLEDGE_WORK': {'display_name': 'R3 — Neutral / Low-Scarcity Knowledge Work', 'short_name': 'R3 Neutral KW', 'technical_template_id': 'KW1'},
    'R5_BOTTLENECKED_KNOWLEDGE_WORK': {'display_name': 'R5 — Bottlenecked Knowledge Work', 'short_name': 'R5 BKW', 'technical_template_id': 'BKWD_B'},
    'R4_AOCTANE_TRANSITION': {'display_name': 'R4 — Octane-Family Selection Win', 'short_name': 'R4 O-family Win', 'technical_template_id': 'DAOPOLE_P'},
    'R7_AOCTANE_SWAP_TRIUMPH': {'display_name': 'R7 — aOctane Swap Triumph', 'short_name': 'R7 aO Triumph', 'technical_template_id': 'AOSWAP_STRONG_s1p18_bc0p20'},
}
CANONICAL_REGIME_ORDER = list(REGIME_META.keys())

_TECHNICAL_GENS = {
    'MSAWIDE_A': gen_MSAWIDE_A,
    'SEQPOLE0p00': gen_SEQPOLE0p00,
    'KW1': gen_KW1,
    'BKWD_B': gen_BKWD_B,
    'DAOPOLE_P': gen_DAOPOLE_P,
    'AOSWAP_STRONG_s1p18_bc0p20': gen_AOSWAP_STRONG_s1p18_bc0p20,
    # Superseded technical generators retained as non-canonical aliases only.
    'AOWIDE_T': gen_AOWIDE_T,
    'AOBOUND_SAFE1p5': gen_AOBOUND_SAFE1p5,
}

def _canonical_wrapper(canonical_id, technical_id, gen):
    def _wrapped(seed: int, mc: int = 500):
        port, projects = gen(seed, mc)
        port.portfolio_id = f'{canonical_id}_seed_{seed}'
        return port, projects
    _wrapped.__name__ = f'gen_{canonical_id}'
    return _wrapped

GENS = {canonical_id: _canonical_wrapper(canonical_id, meta['technical_template_id'], _TECHNICAL_GENS[meta['technical_template_id']])
        for canonical_id, meta in REGIME_META.items()}

# Backward-compatible technical aliases, not used by canonical reproduction.
GENS_ALIASES = dict(_TECHNICAL_GENS)
