from __future__ import annotations
import random, json, sys, time
from pathlib import Path

from pol_step1_reference_common import reevaluate, aggregate
from pol_step1_reference_generators import _aoswap_make_project
from pol_step1_reference_common import eng


def make_aoswap_gen(label, stress=1.1, slack=1.0, capbase=4.8, u_c=2.45, b_c=0.38, e_c=3.8, u_profit_mult=1.0, e_profit_mult=1.0, u_urg='Normal', e_urg='Medium', budget_mult=1.0):
    def gen(seed:int, mc:int=100):
        rng = random.Random(990000 + seed)
        projects=[]
        for i in range(1, 11):
            projects.append(_aoswap_make_project(
                f'U{i:02d}', rng.uniform(420,520)*u_profit_mult, rng.choice([2,2,3]), rng.uniform(34,52), rng.uniform(u_c*0.9,u_c*1.1),
                u_urg, -rng.uniform(55,75)*stress, rng,
            ))
        for i in range(1, 13):
            projects.append(_aoswap_make_project(
                f'B{i:02d}', rng.uniform(155,215), rng.choice([1,2,2]), rng.uniform(16,28), rng.uniform(b_c*0.8,b_c*1.2),
                'Normal', -rng.uniform(0.1,0.8), rng,
            ))
        for i in range(1, 9):
            projects.append(_aoswap_make_project(
                f'E{i:02d}', rng.uniform(300,380)*e_profit_mult, rng.choice([3,4,4]), rng.uniform(82,125), rng.uniform(e_c*0.9,e_c*1.1),
                e_urg, -rng.uniform(0.2,1.0), rng,
            ))
        for i in range(1, 9):
            projects.append(_aoswap_make_project(
                f'F{i:02d}', rng.uniform(70,140), rng.choice([1,2]), rng.uniform(12,25), rng.uniform(0.4,1.2),
                'Normal', -rng.uniform(0.2,2.0), rng,
            ))
        budget=[round(x*slack*budget_mult,2) for x in [700,680,660,640,620,600,580,560,540,520,500,480,460,440,420,400,380,360,340,320,300,280]]
        cap=[round(max(2.8, capbase - i*0.03)*slack,2) for i in range(len(budget))]
        port=eng.PortfolioInputs(portfolio_id=f'{label}_seed_{seed}', budget_restriction_profile=budget, constraint_capacity_profile=cap,
            budget_horizon_rule=eng.HorizonRule.ZERO_BEYOND, monte_carlo_iterations=mc,
            budget_confidence_level=0.80, constraint_confidence_level=0.80, profit_confidence_level=0.85)
        return port,projects
    return gen


def score_agg(agg):
    i3=agg['iteration3_metrics']
    w=i3['median_denominator_safe_percent_waste']
    ws=agg['winner_share']
    acc=agg['accepted_worlds']; wc=agg['world_count']
    aosh=ws.get('aOctane',0) or 0
    # prefer accepted all, high aO share, high MSA/O waste, aO zero
    return (acc/wc)*100 + aosh*100 + (w.get('MSA') or 0)*0.5 + (w.get('Octane') or 0)*0.5 - (w.get('aOctane') or 0)*5


def run_config(params, seeds=range(1,11), selmc=100, evalmc=100):
    label=params.pop('label')
    gen=make_aoswap_gen(label, **params)
    worlds=[]
    t0=time.time()
    for seed in seeds:
        worlds.append(reevaluate(label, gen, seed, selmc, evalmc))
    agg=aggregate(label, worlds, selmc, evalmc)
    params['label']=label
    return agg

if __name__=='__main__':
    candidates=[]
    base={'stress':1.1,'slack':1.0,'capbase':4.8,'u_c':2.45,'b_c':0.38,'e_c':3.8,'u_profit_mult':1.0,'e_profit_mult':1.0,'u_urg':'Normal','e_urg':'Medium','budget_mult':1.0}
    # focused candidates
    grids=[]
    for stress in [1.1,1.3,1.5,1.7,2.0]:
      for e_c in [3.8,4.4,5.0,5.6]:
        grids.append({'stress':stress,'e_c':e_c})
    for stress in [1.5,1.8,2.2]:
      for capbase in [4.4,4.8,5.2,5.6]:
        grids.append({'stress':stress,'capbase':capbase})
    for stress in [1.5,1.8]:
      for u_c in [1.7,2.0,2.45,2.8]:
        grids.append({'stress':stress,'u_c':u_c})
    for stress in [1.5,1.8]:
      for b_c in [0.25,0.38,0.55,0.75]:
        grids.append({'stress':stress,'b_c':b_c})
    # unique
    seen=set(); configs=[]
    for i,ov in enumerate(grids):
        p=base.copy(); p.update(ov); p['label']='AOSWAP_TRY_'+str(i)
        key=tuple(sorted((k,v) for k,v in p.items() if k!='label'))
        if key not in seen:
            seen.add(key); configs.append(p)
    print('configs',len(configs), flush=True)
    rows=[]
    for p in configs:
        q=p.copy()
        try:
            agg=run_config(q, seeds=range(1,11), selmc=100, evalmc=100)
            i3=agg['iteration3_metrics']; w=i3['median_denominator_safe_percent_waste']; pd=i3['pairwise_median_denominator_safe_percent_delta_profit']
            rows.append({'label':p['label'], **{k:v for k,v in p.items() if k!='label'}, 'accepted':agg['accepted_worlds'], 'three_way':agg['three_way_worlds'], 'winner_share':agg['winner_share'], 'waste':w, 'pairwise':pd, 'score':score_agg(agg)})
            print(p['label'], 'acc', agg['accepted_worlds'], 'win', agg['winner_share'], 'w', w, 'score', rows[-1]['score'], flush=True)
        except Exception as e:
            print('ERR',p,e, file=sys.stderr, flush=True)
    rows.sort(key=lambda r:r['score'], reverse=True)
    out=Path('../results/aoswap_param_sweep_10w.json')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding='utf-8')
    print('TOP')
    for r in rows[:10]:
        print(json.dumps(r, ensure_ascii=False))
