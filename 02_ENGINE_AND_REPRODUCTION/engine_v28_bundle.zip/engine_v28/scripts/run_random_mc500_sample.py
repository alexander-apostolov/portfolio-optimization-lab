#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, random, time
from pathlib import Path
from pol_step1_reference_common import reevaluate, aggregate, write_summary_txt, method_admissible
from pol_step1_reference_generators import GENS

REGIMES = ['R1_MSA_STRATEGIC_WIN','R2_MSA_SEQUENCING_EDGE','R3_NEUTRAL_KNOWLEDGE_WORK','R4_AOCTANE_TRANSITION','R5_AOCTANE_TIME_CONSTRAINT_WIN','R6_AOCTANE_STRONGHOLD','R7_AOCTANE_SWAP_TRIUMPH']


def main() -> int:
    ap = argparse.ArgumentParser(description='Optional independent random-world MC500 robustness sample. Not used for exact canonical reproduction.')
    ap.add_argument('--sample-size', type=int, default=5, help='Random world seeds per regime. Increase for stronger robustness checks.')
    ap.add_argument('--random-seed', type=int, default=None, help='Seed for choosing independent world seeds. Omit for a fresh random sample.')
    ap.add_argument('--seed-min', type=int, default=1001)
    ap.add_argument('--seed-max', type=int, default=9999)
    ap.add_argument('--selection-mc', type=int, default=100)
    ap.add_argument('--eval-mc', type=int, default=500)
    ap.add_argument('--outdir', default='../results/random_mc500')
    args = ap.parse_args()
    rng = random.Random(args.random_seed)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    manifest = {'random_seed': args.random_seed, 'sample_size': args.sample_size, 'seed_min': args.seed_min, 'seed_max': args.seed_max, 'regimes': {}}
    t0 = time.time()
    for regime in REGIMES:
        seeds = sorted(rng.sample(range(args.seed_min, args.seed_max + 1), args.sample_size))
        manifest['regimes'][regime] = seeds
        worlds = []
        gen = GENS[regime]
        print(f'=== {regime} random MC500 sample seeds={seeds} ===', flush=True)
        for seed in seeds:
            w = reevaluate(regime, gen, seed, args.selection_mc, args.eval_mc)
            worlds.append(w)
            adm = [m for m in ['MSA','Octane','aOctane'] if method_admissible(w['methods'][m])]
            print(regime, seed, 'accepted', w['accepted_for_comparative_analysis'], 'pattern', '+'.join(adm) or 'none', 'elapsed', round(time.time() - t0, 1), flush=True)
        agg = aggregate(regime, worlds, args.selection_mc, args.eval_mc)
        agg['random_robustness_sample'] = True
        agg['random_sample_world_seeds'] = seeds
        out = outdir / f'random_mc500_{regime}_n{args.sample_size}_selmc{args.selection_mc}_evalmc{args.eval_mc}.json'
        out.write_text(json.dumps(agg, indent=2, ensure_ascii=False), encoding='utf-8')
        write_summary_txt(agg, out.with_suffix('.txt'))
    (outdir / 'random_mc500_sample_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(f'Random MC500 robustness sample written to {outdir}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
