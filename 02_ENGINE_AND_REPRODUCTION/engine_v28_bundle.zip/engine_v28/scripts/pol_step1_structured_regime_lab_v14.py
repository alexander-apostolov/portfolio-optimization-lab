#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, math, random, sys
from pathlib import Path
from statistics import mean, median
from typing import List, Dict, Sequence, Tuple

ENGINE_PATH = Path(__file__).resolve().with_name('pol_engine_benchmark_v14_dependency_order_guarded.py')
spec = importlib.util.spec_from_file_location('eng', ENGINE_PATH)
eng = importlib.util.module_from_spec(spec); sys.modules['eng']=eng; spec.loader.exec_module(eng)

METHODS=['MSA','Octane','aOctane']



def urgency_from_time_erosion(cot_delta: float, base_profit: float) -> str:
    """POL3-aligned urgency bucket derived from relative value erosion.

    The MSA urgency class is based on the *share* of the project's base
    profit that is lost per period through linear cost-of-time erosion, not
    on an absolute currency/unit threshold.  Thresholds are intentionally
    scale-free:
    - High:   |linear_delta_per_period| / |base_profit| >= 10%
    - Medium: 1% <= |linear_delta_per_period| / |base_profit| < 10%
    - Normal: |linear_delta_per_period| / |base_profit| < 1%
    """
    denom = max(abs(float(base_profit)), 1e-9)
    ratio = abs(float(cot_delta)) / denom
    if ratio >= 0.10:
        return 'High'
    if ratio >= 0.01:
        return 'Medium'
    return 'Normal'

def TP_profit(ml, spread=0.10): return eng.ThreePoint(round(ml*(1+spread),3), round(ml,3), round(ml*(1-spread),3))
def TP_cost(ml, spread=0.08): return eng.ThreePoint(round(max(0,ml*(1-spread)),3), round(ml,3), round(ml*(1+spread),3))
def TP_dur(ml, spread=0.10):
    opt=max(1, int(math.floor(ml*(1-spread))))
    pes=max(opt+1, int(math.ceil(ml*(1+spread))))
    return eng.ThreePoint(opt, int(ml), pes)

def spread_profile(total, dur, rng, skew='flat'):
    if skew == 'front': raw=[rng.uniform(1.1,1.7) if i==0 else rng.uniform(0.65,1.15) for i in range(dur)]
    elif skew == 'back': raw=[rng.uniform(0.65,1.15) if i<dur-1 else rng.uniform(1.1,1.7) for i in range(dur)]
    else: raw=[rng.uniform(0.85,1.15) for _ in range(dur)]
    s=sum(raw)
    return [total*x/s for x in raw]

def make_project(pid, profit, dur, budget_total, constraint_peak, rng, urgency=None, cot_delta=-1.0, cliff=None,
                 deps=None, profit_spread=0.10, budget_spread=0.08, constraint_spread=0.08, duration_spread=0.10, synergy=None):
    budget=[TP_cost(v,budget_spread) for v in spread_profile(budget_total, dur, rng)]
    if constraint_peak <= 1e-9:
        constraint=[0.0 for _ in range(dur)]
    else:
        # smooth profile, total roughly peak*dur*0.85
        c=[max(0.0, constraint_peak*rng.uniform(0.75,1.05)) for _ in range(dur)]
        constraint=[TP_cost(v,constraint_spread) for v in c]
    if cliff is not None:
        cot=eng.CostOfTimeProfile(profile_type=eng.CostOfTimeType.CLIFF, cliff_period=cliff)
        # A cliff is a hard time-value discontinuity; treat it as High urgency for MSA sequencing.
        urgency = 'High'
    elif abs(cot_delta) > 1e-12:
        cot=eng.CostOfTimeProfile(profile_type=eng.CostOfTimeType.LINEAR, linear_delta_per_period=TP_profit(cot_delta, 0.10))
        urgency = urgency_from_time_erosion(cot_delta, profit)
    else:
        cot=eng.CostOfTimeProfile()
        urgency = 'Normal'
    urg={'High':eng.Urgency.HIGH,'Medium':eng.Urgency.MEDIUM,'Normal':eng.Urgency.NORMAL}[urgency]
    p=eng.Project(project_id=pid, base_profit=TP_profit(profit, profit_spread), duration=TP_dur(dur,duration_spread),
                  budget_usage_profile=budget, constraint_usage_profile=constraint,
                  structural_dependencies=list(deps or []), urgency_class=urg, cost_of_time_profile=cot)
    if synergy:
        p.synergies.extend(synergy)
    return p

def portfolio(pid, budget, capacity, mc=100):
    return eng.PortfolioInputs(portfolio_id=pid, budget_restriction_profile=budget, constraint_capacity_profile=capacity,
                               budget_horizon_rule=eng.HorizonRule.ZERO_BEYOND,
                               monte_carlo_iterations=mc, budget_confidence_level=0.80, constraint_confidence_level=0.80, profit_confidence_level=0.85)

def gen_kw1(seed:int, mc:int=100):
    rng=random.Random(10000+seed)
    projects=[]
    n=36
    for i in range(1,n+1):
        pid=f'K{i:02d}'
        tier='top' if i<=10 else 'mid' if i<=26 else 'low'
        profit = rng.uniform(105,165) if tier=='top' else rng.uniform(65,125) if tier=='mid' else rng.uniform(35,75)
        dur = rng.choice([1,2,2,3])
        budget_total = rng.uniform(22,58) if tier!='top' else rng.uniform(38,78)
        # weak constraint differentiation; most projects use small shared resource
        constraint_peak = rng.uniform(0.8,2.4) if rng.random()<0.90 else 0.0
        cot_delta = -rng.uniform(0.1,1.0)
        urgency = urgency_from_time_erosion(cot_delta, profit)
        projects.append(make_project(pid,profit,dur,budget_total,constraint_peak,rng,urgency,cot_delta,
                                     profit_spread=0.06,budget_spread=0.05,constraint_spread=0.05,duration_spread=0.05))
    budget=[390,370,350,330,310,290,270,250,230,210,190,170]
    capacity=[18,18,17,17,16,16,15,15,14,14,13,13]
    return portfolio(f'KW1_seed_{seed}',budget,capacity,mc), projects

def gen_pl1(seed:int, mc:int=100):
    rng=random.Random(20000+seed)
    projects=[]
    # 4 platform enablers, modest direct profit, important dependencies
    platform_ids=[]
    for i in range(1,5):
        pid=f'F{i:02d}'; platform_ids.append(pid)
        profit=rng.uniform(20,70)
        dur=rng.choice([3,4,5])
        budget_total=rng.uniform(80,140)
        cpeak=rng.uniform(2.2,4.2)
        projects.append(make_project(pid,profit,dur,budget_total,cpeak,rng,'Medium',-rng.uniform(0.2,1.2),
                                     profit_spread=0.08,budget_spread=0.06,constraint_spread=0.06,duration_spread=0.07))
    # downstream bundles
    for j in range(5,37):
        pid=f'F{j:02d}'
        group=(j-5)//8
        deps=[platform_ids[group%4]]
        if rng.random()<0.18: deps.append(platform_ids[(group+1)%4])
        profit=rng.uniform(95,240)
        dur=rng.choice([2,3,3,4])
        budget_total=rng.uniform(38,100)
        cpeak=rng.uniform(0.8,2.8)
        urg=rng.choices(['High','Medium','Normal'],weights=[0.16,0.34,0.50])[0]
        cot=-rng.uniform(1.0,4.0)
        projects.append(make_project(pid,profit,dur,budget_total,cpeak,rng,urg,cot,deps=deps,
                                     profit_spread=0.10,budget_spread=0.07,constraint_spread=0.07,duration_spread=0.08))
    # synergies: downstream in same platform group gets small factor if another group peer selected
    by_group={g:[] for g in range(4)}
    for p in projects[4:]:
        idx=int(p.project_id[1:])-5; by_group[idx//8].append(p)
    for g, ps in by_group.items():
        for p in ps:
            if rng.random()<0.18 and len(ps)>1:
                rel=rng.choice([q.project_id for q in ps if q.project_id!=p.project_id])
                val=eng.ThreePoint(1.12,1.06,0.98)
                p.synergies.append(eng.Synergy(p.project_id,[rel],'Factor',val))
    budget=[420,410,395,380,360,340,320,300,280,260,240,220,200,180]
    capacity=[19,19,18,18,17,17,16,16,15,15,14,14,13,13]
    return portfolio(f'PL1_seed_{seed}',budget,capacity,mc), projects

def gen_oc1(seed:int, mc:int=100):
    rng=random.Random(30000+seed)
    projects=[]
    # throughput stars: high profit, low constraint, high time value
    for i in range(1,13):
        pid=f'O{i:02d}'
        profit=rng.uniform(170,290)
        dur=rng.choice([2,3,3,4])
        budget_total=rng.uniform(45,95)
        cpeak=rng.uniform(0.7,1.7)
        urgency=rng.choices(['High','Medium','Normal'],weights=[0.12,0.28,0.60])[0]
        cot=-rng.uniform(4.0,9.0)
        cliff=(rng.randint(6,10) if rng.random()<0.18 else None)
        projects.append(make_project(pid,profit,dur,budget_total,cpeak,rng,urgency,cot,cliff=cliff,
                                     profit_spread=0.09,budget_spread=0.06,constraint_spread=0.06,duration_spread=0.07))
    # profit elephants: high base profit but poor constraint economics and more fragility
    for i in range(13,21):
        pid=f'O{i:02d}'
        profit=rng.uniform(220,360)
        dur=rng.choice([4,5,5,6])
        budget_total=rng.uniform(100,180)
        cpeak=rng.uniform(4.8,7.8)
        urgency=rng.choices(['High','Medium','Normal'],weights=[0.22,0.30,0.48])[0]
        cot=-rng.uniform(0.4,2.2)
        projects.append(make_project(pid,profit,dur,budget_total,cpeak,rng,urgency,cot,
                                     profit_spread=0.12,budget_spread=0.10,constraint_spread=0.10,duration_spread=0.10))
    # fillers/options
    for i in range(21,37):
        pid=f'O{i:02d}'
        profit=rng.uniform(55,165)
        dur=rng.choice([1,2,3,4])
        budget_total=rng.uniform(25,85)
        cpeak=rng.uniform(0.8,3.0)
        urgency=rng.choices(['High','Medium','Normal'],weights=[0.10,0.25,0.65])[0]
        cot=-rng.uniform(1.0,5.0)
        projects.append(make_project(pid,profit,dur,budget_total,cpeak,rng,urgency,cot,
                                     profit_spread=0.10,budget_spread=0.07,constraint_spread=0.07,duration_spread=0.08))
    budget=[340,330,315,300,285,270,255,240,225,210,195,180,165,150]
    capacity=[14,14,13.5,13.5,13,12.5,12,11.5,11,10.5,10,9.5,9,8.5]
    return portfolio(f'OC1_seed_{seed}',budget,capacity,mc), projects

def gen_oc2(seed:int, mc:int=100):
    # Slightly safer OC1: smaller elephants, stars less budget-fragile, intended direct comparison.
    port, projects = gen_oc1(seed, mc)
    port.portfolio_id=f'OC2_seed_{seed}'
    port.budget_restriction_profile=[round(x*1.12,3) for x in port.budget_restriction_profile]
    port.constraint_capacity_profile=[round(x+1.0,3) for x in port.constraint_capacity_profile]
    return port, projects

def serialize_world(w): return eng.serialize_world_result(w)

def pct(a,b): return None if b is None or abs(b)<=1e-12 else (a-b)/abs(b)*100.0

def aggregate(worlds:List[dict], name:str, generator:str):
    rows=[]
    for w in worlds:
        methods=w['methods']
        admiss=[m for m in METHODS if methods[m]['admissible'] and methods[m]['stage_feasible'] and methods[m]['selected_count']>0]
        p85={m: methods[m]['p85_profit'] for m in admiss}
        winner=max(p85,key=p85.get) if p85 else None
        rows.append((w,admiss,winner))
    def stat(vals):
        vals=[v for v in vals if v is not None]
        if not vals: return {'n':0,'mean':None,'median':None,'min':None,'max':None,'gt_0_share':None,'gt_5_share':None,'lt_minus_5_share':None}
        return {'n':len(vals),'mean':mean(vals),'median':median(vals),'min':min(vals),'max':max(vals),
                'gt_0_share':sum(v>0 for v in vals)/len(vals),'gt_5_share':sum(v>5 for v in vals)/len(vals),'lt_minus_5_share':sum(v<-5 for v in vals)/len(vals)}
    pair_stats={}
    for a,b in [('MSA','Octane'),('MSA','aOctane'),('Octane','aOctane')]:
        gaps=[]; wins={a:0,b:0,'tie':0}; n=0
        for w,adm,win in rows:
            if a in adm and b in adm:
                n+=1
                pa=w['methods'][a]['p85_profit']; pb=w['methods'][b]['p85_profit']
                # gap is b vs a for consistency? store both label explicitly
                gaps.append(pct(pb,pa))
                if abs(pa-pb)<1e-9: wins['tie']+=1
                elif pa>pb: wins[a]+=1
                else: wins[b]+=1
        pair_stats[f'{b}_vs_{a}_pct']={'coadmissible_worlds':n,'wins':wins,'gap_stats':stat(gaps)}
    method_stats={}
    for m in METHODS:
        sc=[w['methods'][m]['selected_count'] for w,_,__ in rows]
        minrates=[min(w['methods'][m]['budget_feasibility_rate'],w['methods'][m]['constraint_feasibility_rate']) for w,_,__ in rows]
        adm=[w for w,ad,win in rows if m in ad]
        method_stats[m]={
            'admissible_worlds':len(adm),
            'mean_selected':mean(sc) if sc else None,
            'median_selected':median(sc) if sc else None,
            'mean_min_feasibility_rate':mean(minrates) if minrates else None,
            'median_min_feasibility_rate':median(minrates) if minrates else None,
            'severe_below_0_70':sum(x<0.70 for x in minrates),
        }
        if m=='MSA':
            method_stats[m]['fsc_applied_worlds']=sum(bool(w['methods'][m].get('msa_fsc_applied')) for w,_,__ in rows)
            method_stats[m]['mean_fsc_removed']=mean([w['methods'][m].get('msa_fsc_removed_count',0) for w,_,__ in rows]) if rows else None
    pattern_counts={}
    winner_counts={}
    for w,adm,win in rows:
        pattern=' + '.join(adm) if adm else 'none'
        pattern_counts[pattern]=pattern_counts.get(pattern,0)+1
        winner_counts[win or 'none']=winner_counts.get(win or 'none',0)+1
    return {
        'name':name,'generator':generator,'world_count':len(worlds),
        'accepted_worlds':sum(w['accepted_for_comparative_analysis'] for w,_,__ in rows),
        'three_way_worlds':sum(len(ad)==3 for _,ad,__ in rows),
        'msa_participation_worlds':sum('MSA' in ad for _,ad,__ in rows),
        'octane_family_only_worlds':sum(('Octane'in ad and 'aOctane'in ad and 'MSA' not in ad) for _,ad,__ in rows),
        'winner_counts':winner_counts,'admissible_pattern_counts':pattern_counts,
        'methods':method_stats,'pairwise':pair_stats,
        'worlds':worlds
    }

def run_regime(regime, start, end, mc=100):
    gen={'KW1':gen_kw1,'PL1':gen_pl1,'OC1':gen_oc1,'OC2':gen_oc2}[regime]
    worlds=[]
    for seed in range(start,end+1):
        port, projects=gen(seed,mc)
        w=eng.run_world(port,projects,world_seed=seed*1000)
        worlds.append(serialize_world(w))
        print(regime, seed, 'accepted', worlds[-1]['accepted_for_comparative_analysis'], 'pattern', [m for m in METHODS if worlds[-1]['methods'][m]['admissible']], flush=True)
    agg=aggregate(worlds, f'{regime}_{start:03d}_{end:03d}', regime)
    out=Path(f'outputs/step1_{regime}_{start:03d}_{end:03d}_mc{mc}.json')
    out.write_text(json.dumps(agg,indent=2,ensure_ascii=False),encoding='utf-8')
    # compact text
    txt=Path(str(out).replace('.json','.txt'))
    lines=[f'{regime} {start}-{end} MC{mc}',f"worlds={agg['world_count']} accepted={agg['accepted_worlds']} three_way={agg['three_way_worlds']} msa_part={agg['msa_participation_worlds']} octfam_only={agg['octane_family_only_worlds']}",f"winners={agg['winner_counts']}",f"patterns={agg['admissible_pattern_counts']}"]
    for m,s in agg['methods'].items(): lines.append(f"{m}: adm={s['admissible_worlds']} mean_sel={s['mean_selected']:.2f} mean_min_rate={s['mean_min_feasibility_rate']:.3f} severe<.70={s['severe_below_0_70']}")
    for k,s in agg['pairwise'].items(): lines.append(f"{k}: coadm={s['coadmissible_worlds']} wins={s['wins']} gap_mean={s['gap_stats']['mean']} gap_median={s['gap_stats']['median']}")
    txt.write_text('\n'.join(lines),encoding='utf-8')
    return str(out)

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('regime',choices=['KW1','PL1','OC1','OC2'])
    ap.add_argument('--start',type=int,default=1)
    ap.add_argument('--end',type=int,default=6)
    ap.add_argument('--mc',type=int,default=100)
    args=ap.parse_args()
    print(run_regime(args.regime,args.start,args.end,args.mc))

# --- additional v2 generators (defined after main block; usable by import, not CLI from earlier main) ---

def gen_pl2(seed:int, mc:int=100):
    rng=random.Random(21000+seed)
    projects=[]
    platform_ids=[]
    # 3 platform enablers: valuable but not enough alone; prerequisite-rich portfolio.
    for i in range(1,4):
        pid=f'P{i:02d}'; platform_ids.append(pid)
        projects.append(make_project(pid, rng.uniform(90,145), rng.choice([2,3,3]), rng.uniform(48,82), rng.uniform(1.2,2.4), rng,
                                     'Medium', -rng.uniform(0.5,1.8), profit_spread=0.08,budget_spread=0.05,constraint_spread=0.05,duration_spread=0.06))
    # 27 downstream initiatives, each depends on one platform; several high-throughput downstream options.
    for j in range(4,31):
        pid=f'P{j:02d}'
        g=(j-4)%3
        deps=[platform_ids[g]]
        profit=rng.uniform(85,220)
        dur=rng.choice([1,2,2,3,4])
        budget_total=rng.uniform(26,72)
        cpeak=rng.uniform(0.6,2.8)
        urg=rng.choices(['High','Medium','Normal'],weights=[0.18,0.32,0.50])[0]
        cot=-rng.uniform(1.0,4.5)
        projects.append(make_project(pid,profit,dur,budget_total,cpeak,rng,urg,cot,deps=deps,
                                     profit_spread=0.09,budget_spread=0.06,constraint_spread=0.06,duration_spread=0.07))
    # Synergy within platform streams (not too large, enough to matter).
    groups={g:[] for g in range(3)}
    for p in projects[3:]: groups[(int(p.project_id[1:])-4)%3].append(p)
    for ps in groups.values():
        for p in ps:
            if rng.random()<0.25:
                rel=rng.choice([q.project_id for q in ps if q.project_id!=p.project_id])
                p.synergies.append(eng.Synergy(p.project_id,[rel],'Factor',eng.ThreePoint(1.10,1.045,0.98)))
    budget=[360,350,335,320,305,290,275,260,245,230,215,200,185]
    capacity=[15.5,15.5,15,14.5,14,13.5,13,12.5,12,11.5,11,10.5,10]
    return portfolio(f'PL2_seed_{seed}',budget,capacity,mc), projects

def gen_oc3(seed:int, mc:int=100):
    rng=random.Random(33000+seed)
    projects=[]
    # 10 throughput stars: high PCUCU, high time value.
    for i in range(1,11):
        projects.append(make_project(f'C{i:02d}', rng.uniform(170,285), rng.choice([2,3,3]), rng.uniform(36,78), rng.uniform(0.55,1.35), rng,
                                     rng.choices(['High','Medium','Normal'],weights=[0.10,0.30,0.60])[0], -rng.uniform(4.5,8.5),
                                     cliff=(rng.randint(6,9) if rng.random()<0.12 else None),
                                     profit_spread=0.07,budget_spread=0.05,constraint_spread=0.05,duration_spread=0.05))
    # 6 high-profit elephants: tempting to MSA, poor PCUCU but not automatically infeasible.
    for i in range(11,17):
        projects.append(make_project(f'C{i:02d}', rng.uniform(230,360), rng.choice([4,5]), rng.uniform(82,135), rng.uniform(3.5,5.7), rng,
                                     rng.choices(['High','Medium','Normal'],weights=[0.20,0.35,0.45])[0], -rng.uniform(0.4,1.8),
                                     profit_spread=0.08,budget_spread=0.07,constraint_spread=0.07,duration_spread=0.06))
    # 14 fillers/options.
    for i in range(17,31):
        projects.append(make_project(f'C{i:02d}', rng.uniform(60,165), rng.choice([1,2,3]), rng.uniform(24,64), rng.uniform(0.6,2.4), rng,
                                     rng.choices(['High','Medium','Normal'],weights=[0.10,0.25,0.65])[0], -rng.uniform(1.0,4.2),
                                     profit_spread=0.08,budget_spread=0.05,constraint_spread=0.05,duration_spread=0.06))
    budget=[330,320,305,290,275,260,245,230,215,200,185,170]
    capacity=[13.5,13.5,13,12.5,12,11.5,11,10.5,10,9.5,9,8.5]
    return portfolio(f'OC3_seed_{seed}',budget,capacity,mc), projects

def run_regime_v2(regime,start,end,mc=100):
    gen={'PL2':gen_pl2,'OC3':gen_oc3}.get(regime)
    if gen is None:
        return run_regime(regime,start,end,mc)
    worlds=[]
    for seed in range(start,end+1):
        port, projects=gen(seed,mc)
        w=eng.run_world(port,projects,world_seed=seed*1000)
        sw=serialize_world(w); worlds.append(sw)
        print(regime, seed, 'accepted', sw['accepted_for_comparative_analysis'], 'pattern', [m for m in METHODS if sw['methods'][m]['admissible']], flush=True)
    agg=aggregate(worlds, f'{regime}_{start:03d}_{end:03d}', regime)
    out=Path(f'outputs/step1_{regime}_{start:03d}_{end:03d}_mc{mc}.json')
    out.write_text(json.dumps(agg,indent=2,ensure_ascii=False),encoding='utf-8')
    txt=Path(str(out).replace('.json','.txt'))
    lines=[f'{regime} {start}-{end} MC{mc}',f"worlds={agg['world_count']} accepted={agg['accepted_worlds']} three_way={agg['three_way_worlds']} msa_part={agg['msa_participation_worlds']} octfam_only={agg['octane_family_only_worlds']}",f"winners={agg['winner_counts']}",f"patterns={agg['admissible_pattern_counts']}"]
    for m,s in agg['methods'].items(): lines.append(f"{m}: adm={s['admissible_worlds']} mean_sel={s['mean_selected']:.2f} mean_min_rate={s['mean_min_feasibility_rate']:.3f} severe<.70={s['severe_below_0_70']}")
    for k,s in agg['pairwise'].items(): lines.append(f"{k}: coadm={s['coadmissible_worlds']} wins={s['wins']} gap_mean={s['gap_stats']['mean']} gap_median={s['gap_stats']['median']}")
    txt.write_text('\n'.join(lines),encoding='utf-8')
    return str(out)
