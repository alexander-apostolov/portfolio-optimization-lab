#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
SAMPLE_SIZE="${POL_RANDOM_SAMPLE_SIZE:-5}"
# Leave POL_RANDOM_SEED empty for a fresh random sample; set it for repeatable robustness diagnostics.
if [ -n "${POL_RANDOM_SEED:-}" ]; then
  python run_random_mc500_sample.py --sample-size "$SAMPLE_SIZE" --random-seed "$POL_RANDOM_SEED" --outdir ../results/random_mc500
else
  python run_random_mc500_sample.py --sample-size "$SAMPLE_SIZE" --outdir ../results/random_mc500
fi
python ../validation/compare_random_mc500_to_directional_expectations.py --results-dir ../results/random_mc500
