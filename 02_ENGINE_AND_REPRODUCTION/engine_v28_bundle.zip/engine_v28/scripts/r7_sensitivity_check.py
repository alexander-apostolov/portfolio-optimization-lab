#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, time
from pathlib import Path
from aoswap_param_sweep import make_aoswap_gen
from pol_step1_reference_common import reevaluate, aggregate, write_summary_txt


def main():
    ap = argparse.ArgumentParser(description='Focused R7 sensitivity check around AOSWAP_STRONG_s1p18_bc0p20.')
    ap.add_argument('--start', type=int, default=1)
    ap.add_argument('--end', type=int, default=20)
    ap.add_argument('--selection-mc', type=int, default=100)
    ap.add_argument('--eval-mc', type=int, default=100)
    ap.add_argument('--outdir', default='../results/R7_sensitivity')
    args = ap.parse_args()
    outdir=Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    rows=[]
    grid=[]
    for stress in [1.10, 1.15, 1.20]:
        for b_c in [0.25, 0.30, 0.38]:
            label=f'R7_SENS_s{str(stress).replace(".","p")}_bc{str(b_c).replace(".","p")}'
            grid.append((label, stress, b_c))
    t_all=time.time()
    for label, stress, b_c in grid:
        gen=make_aoswap_gen(label, stress=stress, b_c=b_c, e_c=3.8, u_c=2.45, capbase=4.8)
        worlds=[]; t0=time.time()
        for seed in range(args.start, args.end+1):
            worlds.append(reevaluate(label, gen, seed, args.selection_mc, args.eval_mc))
        agg=aggregate(label, worlds, args.selection_mc, args.eval_mc)
        out=outdir/f'{label}_{args.start:03d}_{args.end:03d}_selmc{args.selection_mc}_evalmc{args.eval_mc}.json'
        out.write_text(json.dumps(agg, indent=2, ensure_ascii=False), encoding='utf-8')
        write_summary_txt(agg, out.with_suffix('.txt'))
        i3=agg['iteration3_metrics']
        row={
            'label': label,
            'stress': stress,
            'b_c': b_c,
            'worlds': agg['world_count'],
            'accepted': agg['accepted_worlds'],
            'three_way': agg['three_way_worlds'],
            'winner_share': agg.get('winner_share',{}),
            'median_waste': i3.get('median_denominator_safe_percent_waste',{}),
            'pairwise_delta': i3.get('pairwise_median_denominator_safe_percent_delta_profit',{}),
            'pairwise_valid_counts': i3.get('pairwise_percent_delta_valid_counts',{}),
            'invariant_violations': len(agg.get('invariant_violations',[])),
            'elapsed_sec': round(time.time()-t0,2),
        }
        rows.append(row)
        print(label, 'accepted', row['accepted'], 'winner', row['winner_share'], 'waste', row['median_waste'], 'elapsed', row['elapsed_sec'], flush=True)
    summary={'start':args.start,'end':args.end,'selection_mc':args.selection_mc,'eval_mc':args.eval_mc,'rows':rows,'elapsed_sec':round(time.time()-t_all,2)}
    (outdir/'R7_sensitivity_summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    # compact txt
    lines=[]
    lines.append('R7 sensitivity check around AOSWAP_STRONG_s1p18_bc0p20')
    lines.append(f'worlds={args.start}-{args.end}; selection_mc={args.selection_mc}; eval_mc={args.eval_mc}')
    lines.append('')
    lines.append('label | stress | b_c | accepted | aO winner share | MSA winner share | median %Waste MSA | median %Waste Octane | median %Waste aO | aO vs MSA | aO vs Octane')
    for r in rows:
        ws=r['winner_share']; w=r['median_waste']; pd=r['pairwise_delta']
        lines.append(f"{r['label']} | {r['stress']} | {r['b_c']} | {r['accepted']}/{r['worlds']} | {ws.get('aOctane',0)*100:.1f}% | {ws.get('MSA',0)*100:.1f}% | {w.get('MSA',float('nan')):.4f}% | {w.get('Octane',float('nan')):.4f}% | {w.get('aOctane',float('nan')):.4f}% | {pd.get('aOctane_vs_MSA',float('nan')):.4f}% | {pd.get('aOctane_vs_Octane',float('nan')):.4f}%")
    (outdir/'R7_sensitivity_summary.txt').write_text('\n'.join(lines), encoding='utf-8')
    print(outdir/'R7_sensitivity_summary.json')

if __name__=='__main__':
    main()
