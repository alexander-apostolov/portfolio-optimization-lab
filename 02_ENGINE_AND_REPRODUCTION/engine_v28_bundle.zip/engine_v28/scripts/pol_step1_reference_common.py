#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from statistics import mean, median

import pol_step1_structured_regime_lab_v14 as lab
# Canonical POL3 regime naming is defined here directly to avoid circular-import
# fallback during clean-room reproduction. Technical template IDs are preserved for traceability.
REGIME_META = {
    'R1_MSA_STRATEGIC_WIN': {'display_name': 'R1 — MSA Strategic Win', 'short_name': 'R1 MSA Win', 'technical_template_id': 'MSAWIDE_A'},
    'R2_MSA_SEQUENCING_EDGE': {'display_name': 'R2 — MSA Sequencing Edge', 'short_name': 'R2 MSA Edge', 'technical_template_id': 'SEQPOLE0p00'},
    'R3_NEUTRAL_KNOWLEDGE_WORK': {'display_name': 'R3 — Neutral Knowledge Work', 'short_name': 'R3 Neutral', 'technical_template_id': 'KW1'},
    'R4_AOCTANE_TRANSITION': {'display_name': 'R4 — aOctane Transition', 'short_name': 'R4 aO Transition', 'technical_template_id': 'DAOPOLE_P'},
    'R5_AOCTANE_TIME_CONSTRAINT_WIN': {'display_name': 'R5 — aOctane Time-Constraint Win', 'short_name': 'R5 aO Win', 'technical_template_id': 'AOWIDE_T'},
    'R6_AOCTANE_STRONGHOLD': {'display_name': 'R6 — aOctane Stronghold', 'short_name': 'R6 aO Stronghold', 'technical_template_id': 'AOBOUND_SAFE1p5'},
    'R7_AOCTANE_SWAP_TRIUMPH': {'display_name': 'R7 — aOctane Swap Triumph', 'short_name': 'R7 aO Triumph', 'technical_template_id': 'AOSWAP_STRONG_s1p18_bc0p20'},
}

eng = lab.eng
METHODS = ['MSA', 'Octane', 'aOctane']
make_project = lab.make_project
portfolio = lab.portfolio


def method_admissible(x: dict) -> bool:
    return bool(x.get('admissible')) and bool(x.get('stage_feasible')) and int(x.get('selected_count', 0)) > 0


DENOMINATOR_EPSILON = 1e-9


def pct(new, old):
    if old is None or old <= DENOMINATOR_EPSILON:
        return None
    return (new - old) / old * 100.0


def stat(vals):
    vals = [v for v in vals if v is not None]
    if not vals:
        return {'n': 0, 'mean': None, 'median': None, 'min': None, 'max': None,
                'gt_0_share': None, 'gt_2_share': None, 'gt_5_share': None,
                'lt_minus_2_share': None, 'lt_minus_5_share': None}
    return {'n': len(vals), 'mean': mean(vals), 'median': median(vals), 'min': min(vals), 'max': max(vals),
            'gt_0_share': sum(v > 0 for v in vals) / len(vals),
            'gt_2_share': sum(v > 2 for v in vals) / len(vals),
            'gt_5_share': sum(v > 5 for v in vals) / len(vals),
            'lt_minus_2_share': sum(v < -2 for v in vals) / len(vals),
            'lt_minus_5_share': sum(v < -5 for v in vals) / len(vals)}


def winner_label(p85: dict, eps: float = 1e-8) -> str:
    if not p85:
        return 'none'
    mx = max(p85.values())
    return '+'.join([m for m in METHODS if m in p85 and abs(p85[m] - mx) <= eps])


def apply_plain_world_metrics(methods: dict) -> dict:
    adm = [m for m in METHODS if method_admissible(methods[m])]
    if adm:
        best = max(methods[m].get('evaluated_profit', methods[m].get('p85_profit', 0.0)) for m in adm)
        best_safe = best > DENOMINATOR_EPSILON
        for m in METHODS:
            methods[m]['best_profit_in_world'] = best
            methods[m]['winner_flag'] = bool(m in adm and abs(methods[m].get('evaluated_profit', methods[m].get('p85_profit', 0.0)) - best) <= 1e-9)
            if m in adm:
                ev = methods[m].get('evaluated_profit', methods[m].get('p85_profit', 0.0))
                methods[m]['absolute_waste'] = max(0.0, best - ev)
                methods[m]['waste_denominator_safe'] = best_safe
                methods[m]['percent_waste'] = (methods[m]['absolute_waste'] / best * 100.0) if best_safe else None
                methods[m]['denominator_sensitive_reason'] = None if best_safe else 'best_profit_non_positive_or_near_zero'
            else:
                methods[m]['absolute_waste'] = None
                methods[m]['percent_waste'] = None
                methods[m]['waste_denominator_safe'] = False
                methods[m]['denominator_sensitive_reason'] = 'method_not_comparable_in_world'
    pairwise = {}
    for a, b in [('aOctane', 'MSA'), ('aOctane', 'Octane'), ('Octane', 'MSA')]:
        key = f'{a}_vs_{b}'
        if a in adm and b in adm:
            ea = methods[a].get('evaluated_profit', methods[a].get('p85_profit', 0.0))
            eb = methods[b].get('evaluated_profit', methods[b].get('p85_profit', 0.0))
            delta = ea - eb
            pct_delta = pct(ea, eb)
            pairwise[key] = {
                'method_a': a, 'method_b': b, 'delta_profit': delta,
                'percent_delta_profit': pct_delta, 'denominator_safe': pct_delta is not None,
                'denominator_sensitive_reason': None if pct_delta is not None else 'baseline_non_positive_or_near_zero',
                'baseline_profit': eb,
            }
        else:
            pairwise[key] = {
                'method_a': a, 'method_b': b, 'delta_profit': None,
                'percent_delta_profit': None, 'denominator_safe': False,
                'denominator_sensitive_reason': 'pair_not_comparable_in_world',
            }
    return pairwise


def subset_scenarios(scenarios, ids):
    ids = set(ids)
    return [eng.MonteCarloScenario(
        project_vectors={pid: sc.project_vectors[pid] for pid in ids},
        linear_cot_deltas={pid: sc.linear_cot_deltas[pid] for pid in ids if pid in sc.linear_cot_deltas},
        piecewise_cot_values={pid: sc.piecewise_cot_values[pid] for pid in ids if pid in sc.piecewise_cot_values},
        synergy_values={(pid, i): v for (pid, i), v in sc.synergy_values.items() if pid in ids},
    ) for sc in scenarios]


def reevaluate(name: str, generator, seed: int, selection_mc: int = 100, eval_mc: int = 500) -> dict:
    # First pass: select and sequence under MC100.
    port, projects = generator(seed, selection_mc)
    selection_world = eng.serialize_world_result(eng.run_world(port, projects, world_seed=seed * 1000))

    # Second pass: re-evaluate the fixed selected/sequenced portfolios under MC500 scenarios.
    eport, eprojects = generator(seed, eval_mc)
    pmap = {p.project_id: p for p in eprojects}
    scenarios = eng.generate_mc_scenarios(eport, eprojects, seed * 1000 + 424242)

    methods = {}
    for m in METHODS:
        old = selection_world['methods'][m]
        selected_ids = old.get('selected_ids', [])
        selected = [pmap[pid] for pid in selected_ids]
        sequence = [pmap[pid] for pid in old.get('sequence_ids', [])]
        if selected and old.get('stage_feasible'):
            br, cr, adm, p85, _ = eng.evaluate_stochastic_from_scenarios(
                eport, selected, sequence, subset_scenarios(scenarios, selected_ids)
            )
        else:
            br = cr = 0.0
            adm = False
            p85 = 0.0
        d = dict(old)
        d.update({
            'budget_feasibility_rate': br,
            'constraint_feasibility_rate': cr,
            'admissible': bool(adm),
            'p85_profit': p85,
            'evaluated_profit': p85,
            'selection_mc': selection_mc,
            'eval_mc': eval_mc,
        })
        methods[m] = d

    # Hard invariant guard for reporting/evaluation layer.
    if method_admissible(methods['Octane']):
        if (not method_admissible(methods['aOctane'])) or methods['aOctane'].get('evaluated_profit', methods['aOctane']['p85_profit']) + 1e-9 < methods['Octane'].get('evaluated_profit', methods['Octane']['p85_profit']):
            for key in ['selected_count', 'selected_ids', 'sequence_ids', 'budget_feasibility_rate',
                        'constraint_feasibility_rate', 'admissible', 'stage_feasible', 'p85_profit', 'evaluated_profit']:
                methods['aOctane'][key] = methods['Octane'][key]
            methods['aOctane']['eval_guard_fallback_to_octane'] = True

    adm = [m for m in METHODS if method_admissible(methods[m])]
    pairwise_comparisons = apply_plain_world_metrics(methods)
    return {
        'engine_version': eng.ENGINE_VERSION,
        'portfolio_id': f'{name}_seed_{seed}',
        'world_seed': seed,
        'selection_mc': selection_mc,
        'eval_mc': eval_mc,
        'accepted_for_comparative_analysis': len(adm) >= 2,
        'pairwise_comparisons': pairwise_comparisons,
        'methods': methods,
    }


def aggregate(name: str, worlds: list, selection_mc: int = 100, eval_mc: int = 500) -> dict:
    rows = []
    violations = []
    for idx, w in enumerate(worlds, 1):
        adm = [m for m in METHODS if method_admissible(w['methods'][m])]
        p85 = {m: w['methods'][m].get('evaluated_profit', w['methods'][m]['p85_profit']) for m in adm}
        win = winner_label(p85) if len(adm) >= 2 else 'none'
        if method_admissible(w['methods']['Octane']):
            if (not method_admissible(w['methods']['aOctane'])) or w['methods']['aOctane']['p85_profit'] + 1e-9 < w['methods']['Octane']['p85_profit']:
                violations.append(w.get('world_seed', idx))
        rows.append((w, adm, win))

    accepted_count = sum(w['accepted_for_comparative_analysis'] for w, _, __ in rows)

    # Raw counts over all generated worlds are kept for traceability, but the Iteration 3
    # ranking uses winner share over accepted / comparable worlds only.
    raw_winner_counts = {}
    winner_counts = {}
    pattern_counts = {}
    for w, adm, win in rows:
        raw_winner_counts[win] = raw_winner_counts.get(win, 0) + 1
        if w['accepted_for_comparative_analysis']:
            winner_counts[win] = winner_counts.get(win, 0) + 1
        pattern = ' + '.join(adm) if adm else 'none'
        pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
    winner_share = {k: (v / accepted_count if accepted_count else None) for k, v in winner_counts.items()}

    method_stats = {}
    for m in METHODS:
        sels = [w['methods'][m]['selected_count'] for w, _, __ in rows]
        mins = [min(w['methods'][m]['budget_feasibility_rate'], w['methods'][m]['constraint_feasibility_rate']) for w, _, __ in rows]
        method_stats[m] = {
            'admissible_worlds': sum(m in adm for _, adm, __ in rows),
            'mean_selected': mean(sels),
            'median_selected': median(sels),
            'mean_min_feasibility_rate': mean(mins),
            'median_min_feasibility_rate': median(mins),
            'near_0_75_to_0_85': sum(0.75 <= x <= 0.85 for x in mins),
            'severe_below_0_70': sum(x < 0.70 for x in mins),
        }

    pairwise = {}
    for a, b in [('MSA', 'Octane'), ('MSA', 'aOctane'), ('Octane', 'aOctane')]:
        gaps = []
        wins = {a: 0, b: 0, 'tie': 0}
        n = 0
        for w, adm, _ in rows:
            if a in adm and b in adm:
                n += 1
                pa = w['methods'][a]['p85_profit']
                pb = w['methods'][b]['p85_profit']
                gaps.append(pct(pb, pa))
                if abs(pa - pb) <= 1e-9:
                    wins['tie'] += 1
                elif pa > pb:
                    wins[a] += 1
                else:
                    wins[b] += 1
        pairwise[f'{b}_vs_{a}_pct'] = {'coadmissible_worlds': n, 'wins': wins, 'gap_stats': stat(gaps)}

    waste_values = {}
    abs_waste_values = {}
    eval_profit_values = {}
    waste_valid_counts = {}
    waste_unsafe_counts = {}
    for m in METHODS:
        valid_vals = []
        abs_vals = []
        eval_vals = []
        unsafe = 0
        for w, adm, _ in rows:
            if m not in adm:
                continue
            ev = w['methods'][m].get('evaluated_profit', w['methods'][m].get('p85_profit', 0.0))
            eval_vals.append(ev)
            aw = w['methods'][m].get('absolute_waste')
            if aw is not None:
                abs_vals.append(aw)
            pw = w['methods'][m].get('percent_waste')
            if pw is not None:
                valid_vals.append(pw)
            else:
                unsafe += 1
        waste_values[m] = valid_vals
        abs_waste_values[m] = abs_vals
        eval_profit_values[m] = eval_vals
        waste_valid_counts[m] = len(valid_vals)
        waste_unsafe_counts[m] = unsafe

    pairwise_i3 = {}
    pairwise_i3_valid_counts = {}
    pairwise_i3_unsafe_counts = {}
    pairwise_i3_coadmissible_counts = {}
    for k in ['aOctane_vs_MSA', 'aOctane_vs_Octane', 'Octane_vs_MSA']:
        vals = []
        unsafe = 0
        coadm = 0
        for w, adm, _ in rows:
            comp = w.get('pairwise_comparisons', {}).get(k, {})
            if comp.get('delta_profit') is not None:
                coadm += 1
            if comp.get('percent_delta_profit') is not None:
                vals.append(comp.get('percent_delta_profit'))
            elif comp:
                unsafe += 1
        pairwise_i3[k] = vals
        pairwise_i3_valid_counts[k] = len(vals)
        pairwise_i3_unsafe_counts[k] = unsafe
        pairwise_i3_coadmissible_counts[k] = coadm

    return {
        'name': name,
        'generator': name,
        'display_name': REGIME_META.get(name, {}).get('display_name', name),
        'short_name': REGIME_META.get(name, {}).get('short_name', name),
        'technical_template_id': REGIME_META.get(name, {}).get('technical_template_id', name),
        'selection_mc': selection_mc,
        'eval_mc': eval_mc,
        'world_count': len(worlds),
        'accepted_worlds': accepted_count,
        'three_way_worlds': sum(len(adm) == 3 for _, adm, __ in rows),
        'msa_participation_worlds': sum('MSA' in adm for _, adm, __ in rows),
        'octane_family_only_worlds': sum(('Octane' in adm and 'aOctane' in adm and 'MSA' not in adm) for _, adm, __ in rows),
        'winner_counts': winner_counts,
        'winner_share': winner_share,
        'raw_winner_counts_all_generated_worlds': raw_winner_counts,
        'admissible_pattern_counts': pattern_counts,
        'methods': method_stats,
        'iteration3_metrics': {
            'median_evaluated_profit': {m: (median(v) if v else None) for m, v in eval_profit_values.items()},
            'median_absolute_waste': {m: (median(v) if v else None) for m, v in abs_waste_values.items()},
            'median_denominator_safe_percent_waste': {m: (median(v) if v else None) for m, v in waste_values.items()},
            'percent_waste_valid_counts': waste_valid_counts,
            'percent_waste_unsafe_counts': waste_unsafe_counts,
            'pairwise_median_denominator_safe_percent_delta_profit': {k: (median(v) if v else None) for k, v in pairwise_i3.items()},
            'pairwise_percent_delta_valid_counts': pairwise_i3_valid_counts,
            'pairwise_percent_delta_unsafe_counts': pairwise_i3_unsafe_counts,
            'pairwise_coadmissible_counts': pairwise_i3_coadmissible_counts,
        },
        'pairwise': pairwise,
        'invariant_violations': violations,
        'worlds': worlds,
        'note': 'Step 1 Iteration 3-aligned three-method evaluation. Ranking-based methods use final candidate portfolios, not optimistic prefiltering; sCPA is out of scope for this package.',
    }

def write_summary_txt(agg: dict, path: Path) -> None:
    i3 = agg.get('iteration3_metrics', {})
    lines = [
        f"{agg.get('display_name', agg['name'])} [{agg['name']}] selectionMC{agg['selection_mc']} evalMC{agg['eval_mc']}",
        f"short_name={agg.get('short_name', agg['name'])} technical_template_id={agg.get('technical_template_id', agg['name'])}",
        f"worlds={agg['world_count']} accepted={agg['accepted_worlds']} three_way={agg['three_way_worlds']} msa_part={agg['msa_participation_worlds']} octfam_only={agg['octane_family_only_worlds']}",
        f"winners_accepted={agg.get('winner_counts', {})}",
        f"winner_share_accepted={agg.get('winner_share', {})}",
        f"winners_all_generated_raw={agg.get('raw_winner_counts_all_generated_worlds', {})}",
        f"patterns={agg['admissible_pattern_counts']}",
        f"invariant_violations={len(agg['invariant_violations'])}",
        "",
        "Iteration 3 metrics:",
        f"median_evaluated_profit={i3.get('median_evaluated_profit', {})}",
        f"median_absolute_waste={i3.get('median_absolute_waste', {})}",
        f"median_denominator_safe_percent_waste={i3.get('median_denominator_safe_percent_waste', {})}",
        f"percent_waste_valid_counts={i3.get('percent_waste_valid_counts', {})}",
        f"percent_waste_unsafe_counts={i3.get('percent_waste_unsafe_counts', {})}",
        f"pairwise_median_denominator_safe_percent_delta_profit={i3.get('pairwise_median_denominator_safe_percent_delta_profit', {})}",
        f"pairwise_percent_delta_valid_counts={i3.get('pairwise_percent_delta_valid_counts', {})}",
        f"pairwise_percent_delta_unsafe_counts={i3.get('pairwise_percent_delta_unsafe_counts', {})}",
        f"pairwise_coadmissible_counts={i3.get('pairwise_coadmissible_counts', {})}",
        "",
        "Method diagnostics:",
    ]
    for m, s in agg['methods'].items():
        lines.append(f"{m}: adm={s['admissible_worlds']} mean_sel={s['mean_selected']:.2f} mean_min={s['mean_min_feasibility_rate']:.3f} median_min={s['median_min_feasibility_rate']:.3f}")
    lines.append("")
    lines.append("Legacy pairwise diagnostics:")
    for k, s in agg['pairwise'].items():
        lines.append(f"{k}: coadm={s['coadmissible_worlds']} wins={s['wins']} gap_mean={s['gap_stats']['mean']} gap_median={s['gap_stats']['median']} gt2={s['gap_stats']['gt_2_share']} gt5={s['gap_stats']['gt_5_share']}")
    path.write_text('\n'.join(lines), encoding='utf-8')
