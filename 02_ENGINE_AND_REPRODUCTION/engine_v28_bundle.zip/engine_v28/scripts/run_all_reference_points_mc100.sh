#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p ../results/MC100/worlds
for regime in R1_MSA_STRATEGIC_WIN R2_MSA_SEQUENCING_EDGE R3_NEUTRAL_KNOWLEDGE_WORK R5_BOTTLENECKED_KNOWLEDGE_WORK R4_AOCTANE_TRANSITION R7_AOCTANE_SWAP_TRIUMPH; do
  echo "=== $regime: MC100 world-by-world regeneration ==="
  for seed in $(seq 1 40); do
    out="../results/MC100/worlds/step1_${regime}_$(printf '%03d' "$seed")_$(printf '%03d' "$seed")_selmc100_evalmc100.json"
    if [ -f "$out" ]; then
      echo "SKIP existing $out"
    else
      python run_reference_point.py "$regime" --start "$seed" --end "$seed" --selection-mc 100 --eval-mc 100 --outdir ../results/MC100/worlds
    fi
  done
  python merge_reference_worlds.py "$regime" --start 1 --end 40 --selection-mc 100 --eval-mc 100 --indir ../results/MC100/worlds --outdir ../results/MC100
 done
