from aoswap_param_sweep import make_aoswap_gen
from pol_step1_reference_common import reevaluate, aggregate, write_summary_txt
import argparse,json,time
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('--label',default='AOSWAP_STRONG_s1p3'); ap.add_argument('--stress',type=float,default=1.3); ap.add_argument('--e-c',type=float,default=3.8); ap.add_argument('--u-c',type=float,default=2.45); ap.add_argument('--b-c',type=float,default=0.38); ap.add_argument('--capbase',type=float,default=4.8); ap.add_argument('--start',type=int,default=1); ap.add_argument('--end',type=int,default=40); ap.add_argument('--selmc',type=int,default=100); ap.add_argument('--evalmc',type=int,default=100); ap.add_argument('--outdir',default='../results/aoswap_candidates')
args=ap.parse_args()
gen=make_aoswap_gen(args.label, stress=args.stress, e_c=args.e_c, u_c=args.u_c, b_c=args.b_c, capbase=args.capbase)
worlds=[]; t=time.time()
for seed in range(args.start,args.end+1):
    w=reevaluate(args.label, gen, seed, args.selmc, args.evalmc); worlds.append(w)
    if seed%5==0 or seed==args.end: print(args.label, seed, 'elapsed', round(time.time()-t,1), flush=True)
agg=aggregate(args.label, worlds, args.selmc, args.evalmc)
outdir=Path(args.outdir); outdir.mkdir(parents=True,exist_ok=True)
out=outdir/f'{args.label}_{args.start:03d}_{args.end:03d}_selmc{args.selmc}_evalmc{args.evalmc}.json'
out.write_text(json.dumps(agg, indent=2, ensure_ascii=False), encoding='utf-8'); write_summary_txt(agg,out.with_suffix('.txt'))
print(out)
print(out.with_suffix('.txt').read_text())
