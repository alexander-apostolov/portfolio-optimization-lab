#!/usr/bin/env python3
from __future__ import annotations
import json, math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
SUMMARY = ROOT / 'results' / 'MC500' / 'POL3_v28_Step1_MC500_summary.json'
OUT = ROOT / 'visualizations' / 'POL3_v28_parameter_transition_sliders.png'

W, H = 1920, 1080
BLUE = (14, 96, 184)
BLUE2 = (55, 137, 221)
ORANGE = (255, 90, 20)
NAVY = (8, 20, 58)
TEXT = (33, 39, 55)
GREY = (112, 116, 128)
LIGHT = (244, 246, 250)
MID = (224, 226, 232)
WHITE = (255, 255, 255)

FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')
def font(name, size):
    return ImageFont.truetype(str(FONT_DIR / name), size)
F_TITLE = font('DejaVuSans-Bold.ttf', 58)
F_SUB = font('DejaVuSans.ttf', 28)
F_ROW_TITLE = font('DejaVuSans-Bold.ttf', 22)
F_ROW_TEXT = font('DejaVuSans.ttf', 20)
F_AXIS = font('DejaVuSans-Bold.ttf', 20)
F_SMALL = font('DejaVuSans.ttf', 18)
F_SMALL_B = font('DejaVuSans-Bold.ttf', 18)
F_SPINE_TITLE = font('DejaVuSans-Bold.ttf', 26)
F_LABEL = font('DejaVuSans-Bold.ttf', 18)
F_LABEL_SMALL = font('DejaVuSans.ttf', 16)
F_FOOT = font('DejaVuSans-Oblique.ttf', 21)


def text_size(draw, text, f):
    b = draw.textbbox((0,0), text, font=f)
    return b[2]-b[0], b[3]-b[1]


def draw_wrapped(draw, xy, text, f, fill, max_width, line_spacing=5):
    x,y=xy
    words=text.split()
    line=''
    for w in words:
        test = (line+' '+w).strip()
        if text_size(draw, test, f)[0] <= max_width or not line:
            line=test
        else:
            draw.text((x,y), line, font=f, fill=fill)
            y += text_size(draw, line, f)[1] + line_spacing
            line=w
    if line:
        draw.text((x,y), line, font=f, fill=fill)
        y += text_size(draw, line, f)[1] + line_spacing
    return y


def rounded_gradient(draw_img, xy, radius=18):
    x1,y1,x2,y2=xy
    ww,hh=x2-x1,y2-y1
    grad=Image.new('RGBA',(ww,hh),(0,0,0,0))
    pix=grad.load()
    for x in range(ww):
        t=x/(ww-1)
        # blue -> near-white center -> orange
        if t<0.5:
            tt=t/0.5
            col=tuple(int(BLUE2[i]*(1-tt)+ (230,232,237)[i]*tt) for i in range(3))
        else:
            tt=(t-0.5)/0.5
            col=tuple(int((230,232,237)[i]*(1-tt)+ORANGE[i]*tt) for i in range(3))
        for y in range(hh):
            pix[x,y]=(*col,255)
    mask=Image.new('L',(ww,hh),0)
    md=ImageDraw.Draw(mask)
    md.rounded_rectangle((0,0,ww,hh),radius=radius,fill=255)
    base.alpha_composite(grad,(x1,y1),source=(0,0,ww,hh))
    # shadow and border
    draw.rounded_rectangle(xy, radius=radius, outline=(185,188,196), width=2)


def draw_slider(draw, y, title, desc, knob, idx):
    # divider
    if idx>1:
        draw.line((35,y-18,W-35,y-18), fill=(210,214,220), width=1)
    # number circle
    cx,cy=48,y+24
    draw.ellipse((cx-21,cy-21,cx+21,cy+21), fill=BLUE, outline=(255,255,255), width=3)
    tw,th=text_size(draw,str(idx),F_AXIS)
    draw.text((cx-tw/2,cy-th/2-1),str(idx),font=F_AXIS,fill=WHITE)
    # text
    draw.text((88,y), title, font=F_ROW_TITLE, fill=(20,20,20))
    draw_wrapped(draw, (88,y+30), desc, F_ROW_TEXT, (56,60,72), 500, 2)
    # slider labels and bar
    x1,x2=790,1660
    by=y+31
    draw.text((630, by-10), 'MSA-friendly', font=F_AXIS, fill=BLUE)
    draw.text((1680, by-10), 'aOctane-friendly', font=F_AXIS, fill=ORANGE)
    rounded_gradient(base, (x1,by,x2,by+42), radius=21)
    kx=x1+knob*(x2-x1)
    # knob shadow
    shadow=Image.new('RGBA',(64,64),(0,0,0,0))
    sd=ImageDraw.Draw(shadow)
    sd.ellipse((8,8,56,56), fill=(0,0,0,70))
    shadow=shadow.filter(ImageFilter.GaussianBlur(4))
    base.alpha_composite(shadow,(int(kx-32),by-12))
    draw.ellipse((kx-26,by-8,kx+26,by+44), fill=(248,248,248), outline=(190,190,190), width=2)

# canvas
base=Image.new('RGBA',(W,H),WHITE)
draw=ImageDraw.Draw(base)
# title
title='POL3 v28 Step 1: Six canonical View 1 regimes and driving parameters'
tw,th=text_size(draw,title,F_TITLE)
draw.text(((W-tw)/2,28),title,font=F_TITLE,fill=NAVY)
sub='Left = MSA-friendly  •  Center = transition / near-neutral  •  Right = aOctane-friendly'
sw,sh=text_size(draw,sub,F_SUB)
draw.text(((W-sw)/2,100),sub,font=F_SUB,fill=(70,72,85))

rows=[
('Urgency-value alignment  ↔  PCUCU-time alignment',
 'When strategic urgency dominates, MSA wins; when time-critical work is also constraint-efficient, Octane-family logic gains.',0.54),
('Constraint scarcity  ↔  Selection-size pressure',
 'High constraint scarcity strengthens constraint economics; selection and admissibility pressure can reshape the result.',0.50),
('Cost-of-time severity  ↔  Constraint-economics strength',
 'The more severe the cost of delay and the stronger the constraint economics, the stronger the aOctane pole.',0.76),
('Dependency / synergy density  ↔  Sequencing leverage',
 'Dependencies and synergies matter, but sequence-aware correction is the driver of larger method differences.',0.62),
('Stochastic fragility  ↔  Comparative survivability',
 'When survival/admissibility dominates, the method with more robust feasible portfolios can win before profit comparison.',0.34),
]
y0=165
for i,(t,d,k) in enumerate(rows,1):
    draw_slider(draw,y0+(i-1)*120,t,d,k,i)

# lower spine
spine_y=820
draw.line((30,spine_y-35,W-30,spine_y-35), fill=(180,184,192), width=1)
st='Polarity spine (MC500 validated regimes)'
stw,sth=text_size(draw,st,F_SPINE_TITLE)
draw.text(((W-stw)/2,spine_y-24),st,font=F_SPINE_TITLE,fill=NAVY)
sub2='Labels show median denominator-safe %Delta Evaluated Profit: aOctane vs MSA'
s2w,s2h=text_size(draw,sub2,F_SMALL)
draw.text(((W-s2w)/2,spine_y+10),sub2,font=F_SMALL,fill=(70,72,85))

bar_x1,bar_x2=80,1840
bar_y=925
rounded_gradient(base,(bar_x1,bar_y,bar_x2,bar_y+36),radius=18)
draw.text((80,bar_y+48),'Strong MSA pole',font=F_AXIS,fill=BLUE)
rt='Strong aOctane pole'
rw,rh=text_size(draw,rt,F_AXIS)
draw.text((bar_x2-rw,bar_y+48),rt,font=F_AXIS,fill=ORANGE)

# data
summary=json.loads(SUMMARY.read_text(encoding='utf-8'))
vals=[]
for key in ['R1_MSA_STRATEGIC_WIN','R2_MSA_SEQUENCING_EDGE','R3_NEUTRAL_KNOWLEDGE_WORK','R5_BOTTLENECKED_KNOWLEDGE_WORK','R4_AOCTANE_TRANSITION','R7_AOCTANE_SWAP_TRIUMPH']:
    item=summary[key]
    val=item['pairwise_median_percent_delta_profit']['aOctane_vs_MSA']
    vals.append((item['short_name'], val, item['regime']))
minv,maxv=(min(v for _,v,_ in vals)-5, max(v for _,v,_ in vals)+5)
# offsets to reduce overlap
label_offsets=[-58,-52,-58,-52,-58,-62]
for idx,(label,val,reg) in enumerate(vals):
    t=(val-minv)/(maxv-minv)
    x=bar_x1+t*(bar_x2-bar_x1)
    col=BLUE if val < -1 else (ORANGE if val > 1 else (95,95,95))
    draw.line((x,bar_y-22,x,bar_y+18),fill=(30,30,35),width=2)
    draw.ellipse((x-13,bar_y+5,x+13,bar_y+31),fill=WHITE,outline=col,width=4)
    txt=f'{label}\n{val:+.2f}%'
    # label above, staggered
    ly=bar_y+label_offsets[idx]
    lines=txt.split('\n')
    for j,line in enumerate(lines):
        f=F_LABEL if j==0 else F_LABEL_SMALL
        tw,th=text_size(draw,line,f)
        draw.text((x-tw/2, ly+j*22), line, font=f, fill=col if j==1 else NAVY)

foot='Conclusion: no universal winner; the winning logic is the one best aligned with the input portfolio structure.'
fw,fh=text_size(draw,foot,F_FOOT)
draw.text(((W-fw)/2,1030),foot,font=F_FOOT,fill=(70,72,85))

OUT.parent.mkdir(parents=True,exist_ok=True)
base.convert('RGB').save(OUT, quality=95)
print(OUT)
