#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from pol_step1_reference_common import aggregate, write_summary_txt


def main() -> int:
    ap = argparse.ArgumentParser(description='Merge POL Step 1 single-world/chunk outputs into the canonical 001-040 aggregate result.')
    ap.add_argument('regime')
    ap.add_argument('--start', type=int, default=1)
    ap.add_argument('--end', type=int, default=40)
    ap.add_argument('--selection-mc', type=int, default=100)
    ap.add_argument('--eval-mc', type=int, default=500)
    ap.add_argument('--indir', default='../results/reproduced/worlds')
    ap.add_argument('--outdir', default='../results/reproduced')
    args = ap.parse_args()

    indir = Path(args.indir)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    worlds_by_seed = {}
    pattern = f'step1_{args.regime}_*_selmc{args.selection_mc}_evalmc{args.eval_mc}.json'
    for p in sorted(indir.glob(pattern)):
        d = json.loads(p.read_text(encoding='utf-8'))
        for w in d.get('worlds', []):
            seed = int(w.get('world_seed'))
            if args.start <= seed <= args.end:
                worlds_by_seed[seed] = w
    missing = [s for s in range(args.start, args.end + 1) if s not in worlds_by_seed]
    if missing:
        print(f'MISSING WORLDS for {args.regime}: {missing}', file=sys.stderr)
        return 1
    worlds = [worlds_by_seed[s] for s in range(args.start, args.end + 1)]
    agg = aggregate(args.regime, worlds, args.selection_mc, args.eval_mc)
    out = outdir / f'step1_{args.regime}_{args.start:03d}_{args.end:03d}_selmc{args.selection_mc}_evalmc{args.eval_mc}.json'
    out.write_text(json.dumps(agg, indent=2, ensure_ascii=False), encoding='utf-8')
    write_summary_txt(agg, out.with_suffix('.txt'))
    print(out)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
