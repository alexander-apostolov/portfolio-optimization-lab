from aoswap_param_sweep import make_aoswap_gen, score_agg
from pol_step1_reference_common import reevaluate, aggregate
import json, time
from pathlib import Path
base={'stress':1.1,'slack':1.0,'capbase':4.8,'u_c':2.45,'b_c':0.38,'e_c':3.8,'u_profit_mult':1.0,'e_profit_mult':1.0,'u_urg':'Normal','e_urg':'Medium','budget_mult':1.0}
configs=[]
for i,ov in enumerate([
 {}, {'stress':1.3}, {'stress':1.5}, {'stress':1.8}, {'stress':2.2},
 {'stress':1.5,'e_c':4.6}, {'stress':1.8,'e_c':5.2}, {'stress':1.5,'u_c':2.0}, {'stress':1.8,'u_c':2.0}, {'stress':1.8,'b_c':0.25}, {'stress':1.8,'capbase':4.4}, {'stress':1.8,'capbase':5.4}, {'stress':1.8,'e_c':5.2,'u_c':2.0}, {'stress':2.2,'e_c':5.2,'u_c':2.0},
]):
    p=base.copy(); p.update(ov); p['label']='Q'+str(i); configs.append(p)
rows=[]
for p in configs:
    label=p['label']; params={k:v for k,v in p.items() if k!='label'}; gen=make_aoswap_gen(label, **params)
    t=time.time(); worlds=[]
    for seed in range(1,6):
        worlds.append(reevaluate(label, gen, seed, 50, 50))
    agg=aggregate(label, worlds, 50, 50)
    i3=agg['iteration3_metrics']; w=i3['median_denominator_safe_percent_waste']; pd=i3['pairwise_median_denominator_safe_percent_delta_profit']
    r={'label':label, **params, 'accepted':agg['accepted_worlds'], 'three_way':agg['three_way_worlds'], 'winner_share':agg['winner_share'], 'waste':w, 'pairwise':pd, 'score':score_agg(agg), 'elapsed':time.time()-t}
    rows.append(r)
    print(label, 'params', params, 'acc', agg['accepted_worlds'], 'win',agg['winner_share'],'w',w,'pd',pd,'score',round(r['score'],2),'elapsed',round(r['elapsed'],1), flush=True)
rows.sort(key=lambda r:r['score'], reverse=True)
out=Path('../results/aoswap_quick_sweep_5w_mc50.json'); out.parent.mkdir(exist_ok=True, parents=True); out.write_text(json.dumps(rows, indent=2), encoding='utf-8')
print('TOP')
for r in rows[:5]: print(json.dumps(r, ensure_ascii=False))
