from __future__ import annotations

ENGINE_VERSION = "v26_pol3_baseprofit_relative_urgency_source"
# v15 changes:
# - Iteration 3 Step 1 alignment for MSA / Octane / aOctane.
# - Ranking-based methods do not use optimistic staging or optimistic prefiltering.
# - aOctane local swap candidates are deterministic-feasibility screened before MC evaluation.
# - Evaluated Profit and per-world waste metrics are reported.


from dataclasses import dataclass, field
from enum import Enum
from itertools import combinations
import json
import math
import random
from statistics import mean, median, pstdev
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


DENOMINATOR_EPSILON = 1e-9


class HorizonRule(str, Enum):
    ZERO_BEYOND = "zero_beyond_horizon"
    REPEAT_LAST = "repeat_last_value"
    CONTINUE_DECLINE = "continue_decline"


class Urgency(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    NORMAL = "Normal"


class CostOfTimeType(str, Enum):
    NONE = "None"
    LINEAR = "Linear"
    CLIFF = "Cliff"
    PIECEWISE = "Piecewise"


@dataclass(frozen=True)
class ThreePoint:
    optimistic: float
    most_likely: float
    pessimistic: float

    def sample(self, rng: random.Random, profit_parameter: bool = False) -> float:
        # Triangular is the simplest robust default for engine v1.
        lo, mode, hi = self.optimistic, self.most_likely, self.pessimistic
        if profit_parameter:
            lo, mode, hi = self.pessimistic, self.most_likely, self.optimistic
        return rng.triangular(lo, hi, mode)

    def deterministic(self) -> float:
        return self.most_likely


ScalarOr3P = float | int | ThreePoint


@dataclass
class CostOfTimeProfile:
    profile_type: CostOfTimeType = CostOfTimeType.NONE
    linear_delta_per_period: ScalarOr3P = 0.0  # additive in profit units
    cliff_period: Optional[int] = None  # 1-based from reference date
    piecewise_adjustments: Optional[List[ScalarOr3P]] = None  # indexed from period 1

    def deterministic_adjustment(self, completion_period_1_based: int) -> float:
        if self.profile_type == CostOfTimeType.NONE:
            return 0.0
        if self.profile_type == CostOfTimeType.LINEAR:
            delta = _det(self.linear_delta_per_period)
            return delta * max(0, completion_period_1_based - 1)
        if self.profile_type == CostOfTimeType.CLIFF:
            if self.cliff_period is not None and completion_period_1_based > self.cliff_period:
                return float("-inf")
            return 0.0
        if self.profile_type == CostOfTimeType.PIECEWISE:
            values = [_det(v) for v in (self.piecewise_adjustments or [])]
            idx = completion_period_1_based - 1
            if idx < len(values):
                return values[idx]
            return 0.0
        raise ValueError(f"Unsupported cost of time type: {self.profile_type}")

    def sampled_adjustment(self, completion_period_1_based: int, rng: random.Random) -> float:
        if self.profile_type == CostOfTimeType.NONE:
            return 0.0
        if self.profile_type == CostOfTimeType.LINEAR:
            delta = _sample(self.linear_delta_per_period, rng, profit_parameter=True)
            return delta * max(0, completion_period_1_based - 1)
        if self.profile_type == CostOfTimeType.CLIFF:
            if self.cliff_period is not None and completion_period_1_based > self.cliff_period:
                return float("-inf")
            return 0.0
        if self.profile_type == CostOfTimeType.PIECEWISE:
            values = [_sample(v, rng, profit_parameter=True) for v in (self.piecewise_adjustments or [])]
            idx = completion_period_1_based - 1
            if idx < len(values):
                return values[idx]
            return 0.0
        raise ValueError(f"Unsupported cost of time type: {self.profile_type}")

    def cliff_deadline(self) -> Optional[int]:
        if self.profile_type == CostOfTimeType.CLIFF:
            return self.cliff_period
        return None


@dataclass
class Synergy:
    target_project_id: str
    related_project_ids: List[str]
    synergy_type: str  # "Factor" or "Fixed Adjustment"
    value: ScalarOr3P


@dataclass
class Project:
    project_id: str
    base_profit: ScalarOr3P
    duration: int | ThreePoint
    budget_usage_profile: Optional[List[ScalarOr3P]] = None
    total_project_budget: Optional[ScalarOr3P] = None
    constraint_usage_profile: Optional[List[ScalarOr3P]] = None
    structural_dependencies: List[str] = field(default_factory=list)
    synergies: List[Synergy] = field(default_factory=list)
    urgency_class: Urgency = Urgency.NORMAL
    cost_of_time_profile: CostOfTimeProfile = field(default_factory=CostOfTimeProfile)

    def deterministic_duration(self) -> int:
        return max(1, round(_det(self.duration)))

    def deterministic_base_profit(self) -> float:
        return _det(self.base_profit)


@dataclass
class PortfolioInputs:
    portfolio_id: str
    budget_restriction_profile: List[float]
    constraint_capacity_profile: List[float]
    budget_horizon_rule: HorizonRule = HorizonRule.ZERO_BEYOND
    reference_date: str = "now"
    budget_confidence_level: float = 0.8
    constraint_confidence_level: float = 0.8
    profit_confidence_level: float = 0.85
    monte_carlo_iterations: int = 200


@dataclass
class StageRecord:
    project_id: str
    start_period_0: int
    completion_period_1: int


@dataclass
class StageResult:
    feasible: bool
    sequence: List[str]
    records: List[StageRecord]
    failure_reason: Optional[str] = None
    budget_feasible: bool = True
    constraint_feasible: bool = True


@dataclass
class MethodOutcome:
    method: str
    selected_ids: List[str]
    repaired_ids: List[str]
    sequence_ids: List[str]
    stage_result: StageResult
    deterministic_profit: float
    budget_feasibility_rate: float
    constraint_feasibility_rate: float
    admissible: bool
    p85_profit: float
    evaluated_profit: float
    mc_profits: List[float] = field(default_factory=list)

    # Iteration 3 Step 1 comparison / waste metadata.
    stochastic_evaluation_object: str = "final_candidate_portfolio"
    optimistic_prefilter_applied: bool = False
    best_profit_in_world: Optional[float] = None
    winner_flag: bool = False
    absolute_waste: Optional[float] = None
    percent_waste: Optional[float] = None
    waste_denominator_safe: Optional[bool] = None
    denominator_sensitive_reason: Optional[str] = None
    aoctane_guard_fallback_used: bool = False

    # v13 MSA Final-Sequence Feasibility Cap metadata.
    # Populated for method == "MSA" when the cap is applied.
    msa_candidate_ids: List[str] = field(default_factory=list)
    msa_candidate_sequence_ids: List[str] = field(default_factory=list)
    msa_candidate_stage_feasible: Optional[bool] = None
    msa_candidate_stage_failure_reason: Optional[str] = None
    msa_fsc_applied: bool = False
    msa_fsc_removed_ids: List[str] = field(default_factory=list)



@dataclass
class MonteCarloScenario:
    project_vectors: Dict[str, Tuple[int, List[float], List[float], float]]
    linear_cot_deltas: Dict[str, float] = field(default_factory=dict)
    piecewise_cot_values: Dict[str, List[float]] = field(default_factory=dict)
    synergy_values: Dict[Tuple[str, int], float] = field(default_factory=dict)

@dataclass
class ComparativeWorldResult:
    portfolio_id: str
    methods: Dict[str, MethodOutcome]
    accepted_for_comparative_analysis: bool
    acceptance_reasons: List[str]
    pairwise_comparisons: Dict[str, Dict[str, object]] = field(default_factory=dict)


# -------------------------
# Helpers
# -------------------------


def _det(x: ScalarOr3P) -> float:
    return float(x.deterministic() if isinstance(x, ThreePoint) else x)


def _sample(x: ScalarOr3P, rng: random.Random, profit_parameter: bool = False) -> float:
    return float(x.sample(rng, profit_parameter=profit_parameter) if isinstance(x, ThreePoint) else x)


def derive_urgency_from_cost_of_time(base_profit: ScalarOr3P, cot: CostOfTimeProfile) -> Urgency:
    """Derive MSA urgency from relative value erosion.

    POL3 defines MSA expert/governance priority as based on value erosion over
    time.  For linear cost-of-time profiles the generator therefore uses the
    per-period erosion as a percentage of the project's deterministic base
    profit, rather than an absolute delta.

    - High:   |linear_delta_per_period| / |base_profit| >= 10%
    - Medium: 1% <= |linear_delta_per_period| / |base_profit| < 10%
    - Normal: |linear_delta_per_period| / |base_profit| < 1%

    Cliff profiles represent a hard time-value discontinuity and are classified
    as High urgency for MSA sequencing.
    """
    if cot is None or cot.profile_type == CostOfTimeType.NONE:
        return Urgency.NORMAL
    if cot.profile_type == CostOfTimeType.CLIFF:
        return Urgency.HIGH
    if cot.profile_type == CostOfTimeType.LINEAR:
        denom = max(abs(_det(base_profit)), 1e-9)
        ratio = abs(_det(cot.linear_delta_per_period)) / denom
        if ratio >= 0.10:
            return Urgency.HIGH
        if ratio >= 0.01:
            return Urgency.MEDIUM
        return Urgency.NORMAL
    # Piecewise profiles are not used in the canonical Step 1 generators; keep a
    # conservative default unless a future generator defines an explicit mapping.
    return Urgency.NORMAL


def _normalize_profile(raw: Optional[List[ScalarOr3P]], duration: int) -> List[ScalarOr3P]:
    if raw is None:
        return [0.0] * duration
    out = list(raw)
    if len(out) < duration:
        out.extend([0.0] * (duration - len(out)))
    return out[:duration]


def _derive_budget_profile(project: Project, duration: int) -> List[ScalarOr3P]:
    if project.budget_usage_profile is not None:
        profile = _normalize_profile(project.budget_usage_profile, duration)
        if project.total_project_budget is None:
            return profile
        total_profile = sum(_det(v) for v in profile)
        total_declared = _det(project.total_project_budget)
        if total_declared <= total_profile + 1e-12:
            return profile
        # scale up uniformly to the declared total if larger.
        if total_profile <= 1e-12:
            return [project.total_project_budget if i == 0 else 0.0 for i in range(duration)]
        scale = total_declared / total_profile
        return [(_det(v) * scale) for v in profile]
    if project.total_project_budget is not None:
        total = _det(project.total_project_budget)
        return [total / duration] * duration
    return [0.0] * duration


def _stretch_profile(values: Sequence[float], target_duration: int) -> List[float]:
    if target_duration <= 0:
        return []
    if not values:
        return [0.0] * target_duration
    if len(values) == target_duration:
        return list(values)
    if len(values) == 1:
        return [values[0]] * target_duration
    out: List[float] = []
    src_n = len(values)
    for i in range(target_duration):
        pos = i * (src_n - 1) / max(1, target_duration - 1)
        left = int(math.floor(pos))
        right = min(src_n - 1, left + 1)
        frac = pos - left
        out.append(values[left] * (1 - frac) + values[right] * frac)
    return out


def _budget_available(profile: Sequence[float], idx0: int, rule: HorizonRule) -> float:
    if idx0 < len(profile):
        return profile[idx0]
    if rule == HorizonRule.ZERO_BEYOND:
        return 0.0
    if rule == HorizonRule.REPEAT_LAST:
        return profile[-1] if profile else 0.0
    if rule == HorizonRule.CONTINUE_DECLINE:
        if not profile:
            return 0.0
        if len(profile) < 2:
            return profile[-1]
        step = profile[-1] - profile[-2]
        val = profile[-1] + step * (idx0 - len(profile) + 1)
        return max(0.0, val)
    raise ValueError(rule)


def _constraint_available(profile: Sequence[float], idx0: int) -> float:
    if idx0 < len(profile):
        return profile[idx0]
    return profile[-1] if profile else 0.0


def _effective_budget_stop(profile: Sequence[float], rule: HorizonRule) -> int:
    # Effective budget horizon for staging search is the explicit budget profile length.
    # Budget semantics beyond that horizon may affect in-profile active periods via _budget_available,
    # but no new starts are searched beyond the explicit horizon.
    return len(profile)


def _project_sampled_vectors(project: Project, rng: random.Random, optimistic: bool = False) -> Tuple[int, List[float], List[float], float]:
    if optimistic:
        duration = max(1, round(project.duration.optimistic if isinstance(project.duration, ThreePoint) else project.duration))
    else:
        duration = max(1, round(_sample(project.duration, rng)))
    base_budget = _derive_budget_profile(project, project.deterministic_duration())
    base_constraint = _normalize_profile(project.constraint_usage_profile, project.deterministic_duration())
    if optimistic:
        budget_vals = [v.optimistic if isinstance(v, ThreePoint) else float(v) for v in base_budget]
        constraint_vals = [v.optimistic if isinstance(v, ThreePoint) else float(v) for v in base_constraint]
        base_profit = project.base_profit.pessimistic if isinstance(project.base_profit, ThreePoint) else float(project.base_profit)
    else:
        budget_vals = [_sample(v, rng) for v in base_budget]
        constraint_vals = [_sample(v, rng) for v in base_constraint]
        base_profit = _sample(project.base_profit, rng, profit_parameter=True)
    if len(budget_vals) != duration:
        budget_vals = _stretch_profile(budget_vals, duration)
    if len(constraint_vals) != duration:
        constraint_vals = _stretch_profile(constraint_vals, duration)
    return duration, budget_vals, constraint_vals, base_profit


# -------------------------
# Sequencing
# -------------------------


def octane_score(project: Project) -> float:
    profit = project.deterministic_base_profit()
    duration = project.deterministic_duration()
    constraint = [_det(v) for v in _normalize_profile(project.constraint_usage_profile, duration)]
    total_use = sum(constraint)
    if total_use <= 1e-12:
        return profit
    return profit / total_use


def octane_peak_constraint(project: Project) -> float:
    duration = project.deterministic_duration()
    return max([_det(v) for v in _normalize_profile(project.constraint_usage_profile, duration)] or [0.0])


def build_base_ranking(projects: Sequence[Project], method: str) -> List[Project]:
    if method == "MSA":
        return sorted(projects, key=lambda p: (-p.deterministic_base_profit(), p.project_id))
    if method in {"Octane", "aOctane"}:
        return sorted(projects, key=lambda p: (-octane_score(p), octane_peak_constraint(p), p.project_id))
    raise ValueError(method)


def apply_msa_sequence(selected: Sequence[Project], base_ranking: Sequence[Project], portfolio: PortfolioInputs) -> List[Project]:
    rank_index = {p.project_id: i for i, p in enumerate(base_ranking)}
    selected_sorted = sorted(selected, key=lambda p: rank_index[p.project_id])
    urgency_order = {Urgency.HIGH: 0, Urgency.MEDIUM: 1, Urgency.NORMAL: 2}
    seq = sorted(selected_sorted, key=lambda p: (urgency_order[p.urgency_class], rank_index[p.project_id]))

    max_passes = max(1, len(seq) * len(seq))
    for _ in range(max_passes):
        base_stage = stage_sequence(seq, portfolio)
        base_comp = {r.project_id: r.completion_period_1 for r in base_stage.records}
        changed = False
        for idx, proj in enumerate(list(seq)):
            deadline = proj_cost_cliff_deadline(proj)
            current_completion = base_comp.get(proj.project_id)
            if deadline is None or current_completion is None or current_completion <= deadline:
                continue

            protected_ids = []
            for earlier in seq[:idx]:
                earlier_deadline = proj_cost_cliff_deadline(earlier)
                if earlier_deadline is not None:
                    earlier_completion = base_comp.get(earlier.project_id)
                    if earlier_completion is not None and earlier_completion <= earlier_deadline:
                        protected_ids.append(earlier.project_id)

            for new_idx in range(idx - 1, -1, -1):
                trial = list(seq)
                item = trial.pop(idx)
                trial.insert(new_idx, item)
                staged = stage_sequence(trial, portfolio)
                if not staged.feasible:
                    continue
                trial_comp = {r.project_id: r.completion_period_1 for r in staged.records}
                trial_completion = trial_comp.get(proj.project_id)
                if trial_completion is None or trial_completion > deadline:
                    continue
                creates_conflict = False
                for protected_id in protected_ids:
                    protected_proj = next(p for p in seq if p.project_id == protected_id)
                    protected_deadline = proj_cost_cliff_deadline(protected_proj)
                    if protected_deadline is None:
                        continue
                    if trial_comp.get(protected_id, 10**9) > protected_deadline:
                        creates_conflict = True
                        break
                if creates_conflict:
                    continue
                seq = trial
                changed = True
                break
            if changed:
                break
        if not changed:
            break
    return seq


def proj_cost_cliff_deadline(project: Project) -> Optional[int]:
    # Recognize pure cliff or piecewise containing -inf after deadline only through explicit CLIFF profile.
    return project.cost_of_time_profile.cliff_deadline()


def _stage_sequence_core(
    sequence: Sequence[Project],
    portfolio: PortfolioInputs,
    sampled_vectors: Optional[Dict[str, Tuple[int, List[float], List[float], float]]] = None,
) -> StageResult:
    records: List[StageRecord] = []
    sequence_ids = [p.project_id for p in sequence]
    max_start_search = _effective_budget_stop(portfolio.budget_restriction_profile, portfolio.budget_horizon_rule)

    prepared: Dict[str, Tuple[int, List[float], List[float]]] = {}
    dependency_finish: Dict[str, int] = {}
    max_duration = 0
    for project in sequence:
        if sampled_vectors is None:
            duration = project.deterministic_duration()
            budget_profile = [float(_det(v)) for v in _derive_budget_profile(project, duration)]
            constraint_profile = [float(_det(v)) for v in _normalize_profile(project.constraint_usage_profile, duration)]
        else:
            duration, budget_profile, constraint_profile, _ = sampled_vectors[project.project_id]
        prepared[project.project_id] = (duration, list(budget_profile), list(constraint_profile))
        max_duration = max(max_duration, duration)

    timeline_len = max(1, max_start_search + max_duration + 1)
    budget_used = [0.0] * timeline_len
    constraint_used = [0.0] * timeline_len

    for project in sequence:
        duration, budget_profile, constraint_profile = prepared[project.project_id]

        earliest_dep_start = 0
        for dep in project.structural_dependencies:
            if dep not in dependency_finish:
                return StageResult(False, sequence_ids, records, f"missing dependency during staging: {dep}", True, True)
            earliest_dep_start = max(earliest_dep_start, dependency_finish[dep])

        latest_start_to_try = max_start_search - 1
        feasible_start: Optional[int] = None
        any_budget_violation = False
        any_constraint_violation = False

        for start in range(earliest_dep_start, latest_start_to_try + 1):
            end = start + duration
            if end > timeline_len:
                any_budget_violation = True
                continue
            budget_violation = False
            constraint_violation = False
            for offset, (b_need, c_need) in enumerate(zip(budget_profile, constraint_profile)):
                t = start + offset
                budget_capacity = _budget_available(portfolio.budget_restriction_profile, t, portfolio.budget_horizon_rule)
                if (budget_capacity <= 1e-12 and b_need > 1e-12) or (budget_used[t] + b_need > budget_capacity + 1e-12):
                    budget_violation = True
                constraint_capacity = _constraint_available(portfolio.constraint_capacity_profile, t)
                if constraint_used[t] + c_need > constraint_capacity + 1e-12:
                    constraint_violation = True
            if not budget_violation and not constraint_violation:
                feasible_start = start
                for offset, (b_need, c_need) in enumerate(zip(budget_profile, constraint_profile)):
                    t = start + offset
                    budget_used[t] += b_need
                    constraint_used[t] += c_need
                completion = feasible_start + duration
                dependency_finish[project.project_id] = completion
                records.append(StageRecord(project.project_id, feasible_start, completion))
                break
            any_budget_violation = any_budget_violation or budget_violation
            any_constraint_violation = any_constraint_violation or constraint_violation

        if feasible_start is None:
            failure_bits = []
            if any_budget_violation:
                failure_bits.append("budget")
            if any_constraint_violation:
                failure_bits.append("constraint")
            if not failure_bits:
                failure_bits.append("no_feasible_start")
            return StageResult(
                False,
                sequence_ids,
                records,
                f"no feasible start for {project.project_id}: {'+'.join(failure_bits)}",
                budget_feasible=not any_budget_violation,
                constraint_feasible=not any_constraint_violation,
            )

    return StageResult(True, sequence_ids, records, None, True, True)


def stage_sequence_with_feasibility_details(
    sequence: Sequence[Project],
    portfolio: PortfolioInputs,
    sampled_vectors: Optional[Dict[str, Tuple[int, List[float], List[float], float]]] = None,
) -> StageResult:
    return _stage_sequence_core(sequence, portfolio, sampled_vectors)


# -------------------------
# Staging
# -------------------------


def stage_sequence(sequence: Sequence[Project], portfolio: PortfolioInputs, sampled_vectors: Optional[Dict[str, Tuple[int, List[float], List[float], float]]] = None) -> StageResult:
    return _stage_sequence_core(sequence, portfolio, sampled_vectors)


# -------------------------
# Repair + candidate construction
# -------------------------


def _dependency_closure(selected_ids: List[str], project_map: Dict[str, Project]) -> List[str]:
    out = list(selected_ids)
    seen = set(out)
    changed = True
    while changed:
        changed = False
        for pid in list(out):
            for dep in project_map[pid].structural_dependencies:
                if dep not in seen:
                    out.append(dep)
                    seen.add(dep)
                    changed = True
    return out


def _structural_cleanup(selected_ids: List[str], project_map: Dict[str, Project]) -> List[str]:
    selected = set(selected_ids)
    changed = True
    while changed:
        changed = False
        for pid in list(selected):
            deps = set(project_map[pid].structural_dependencies)
            if not deps.issubset(selected):
                selected.remove(pid)
                changed = True
    return [pid for pid in selected_ids if pid in selected]


def _dependency_aware_stable_order(sequence: Sequence[Project]) -> List[Project]:
    """Stable dependency-aware ordering for any sequence passed to staging.

    Structural prerequisites must precede their dependents. Among all dependency-valid
    orders, preserve the method-preferred sequence as much as possible. This is a
    stable topological ordering of the supplied method-preferred sequence.
    """
    seq = list(sequence)
    if len(seq) <= 1:
        return seq
    project_by_id = {p.project_id: p for p in seq}
    selected_ids = set(project_by_id)
    original_pos = {p.project_id: i for i, p in enumerate(seq)}
    outgoing: Dict[str, List[str]] = {p.project_id: [] for p in seq}
    indegree: Dict[str, int] = {p.project_id: 0 for p in seq}
    for p in seq:
        for dep in p.structural_dependencies:
            if dep in selected_ids and dep != p.project_id:
                outgoing[dep].append(p.project_id)
                indegree[p.project_id] += 1
    ready = sorted([pid for pid, d in indegree.items() if d == 0], key=lambda pid: original_pos[pid])
    ordered_ids: List[str] = []
    while ready:
        pid = ready.pop(0)
        ordered_ids.append(pid)
        for child in sorted(outgoing[pid], key=lambda x: original_pos[x]):
            indegree[child] -= 1
            if indegree[child] == 0:
                ready.append(child)
                ready.sort(key=lambda x: original_pos[x])
    if len(ordered_ids) != len(seq):
        # Cyclic structural dependencies are invalid input. Keep original order so the
        # downstream staging/evaluation can fail visibly instead of masking the issue.
        return seq
    return [project_by_id[pid] for pid in ordered_ids]


def build_sequence(selected: Sequence[Project], method: str, base_ranking: Sequence[Project], portfolio: PortfolioInputs) -> List[Project]:
    if method == "MSA":
        preferred = apply_msa_sequence(selected, base_ranking, portfolio)
    elif method in {"Octane", "aOctane"}:
        selected_ids = {p.project_id for p in selected}
        preferred = [p for p in base_ranking if p.project_id in selected_ids]
    else:
        raise ValueError(method)
    return _dependency_aware_stable_order(preferred)


def build_selection_sequence(selected: Sequence[Project], method: str, base_ranking: Sequence[Project], portfolio: PortfolioInputs) -> List[Project]:
    """
    Selection/repair-time feasibility sequence.
    For MSA this must remain the base ranking order and must not inject urgency/cliff override
    into the selection path. Dependency order is still a hard validity constraint for
    any sequence passed to staging.
    """
    selected_ids = {p.project_id for p in selected}
    preferred = [p for p in base_ranking if p.project_id in selected_ids]
    return _dependency_aware_stable_order(preferred)


def _ordered_ids(ids: Sequence[str], ranking_ids: Sequence[str]) -> List[str]:
    selected = set(ids)
    return [pid for pid in ranking_ids if pid in selected]


def _stabilize_subset(
    trial_ids: Sequence[str],
    portfolio: PortfolioInputs,
    project_map: Dict[str, Project],
    ranking_ids: Sequence[str],
    method: str,
    base_ranking: Sequence[Project],
) -> List[str]:
    current_ids = _ordered_ids(_dependency_closure(list(trial_ids), project_map), ranking_ids)
    while True:
        ordered_projects = [project_map[pid] for pid in current_ids]
        selection_seq = build_selection_sequence(ordered_projects, method, base_ranking, portfolio)
        staged = stage_sequence(selection_seq, portfolio)
        if staged.feasible:
            return current_ids
        if not current_ids:
            return []
        lowest = current_ids[-1]
        current_ids = _ordered_ids(_structural_cleanup([pid for pid in current_ids if pid != lowest], project_map), ranking_ids)




def apply_msa_final_sequence_feasibility_cap(
    portfolio: PortfolioInputs,
    selected: Sequence[Project],
    base_ranking: Sequence[Project],
) -> Tuple[List[Project], List[Project], StageResult, Dict[str, object]]:
    """
    MSA Final-Sequence Feasibility Cap (v13).

    MSA first produces a candidate selection. Before stochastic evaluation, this
    selection is reduced, if necessary, to the highest-ranked subset whose final
    MSA sequence can be deterministically staged.

    Removal rule: remove the lowest-ranked remaining project under the MSA base
    ranking, rebuild the final MSA sequence, and test deterministic staging again.
    """
    project_map = {p.project_id: p for p in base_ranking}
    ranking_ids = [p.project_id for p in base_ranking]
    candidate_ids = _ordered_ids([p.project_id for p in selected], ranking_ids)
    candidate_seq = build_sequence([project_map[pid] for pid in candidate_ids], "MSA", base_ranking, portfolio)
    candidate_stage = stage_sequence(candidate_seq, portfolio)

    current_ids = list(candidate_ids)
    removed_ids: List[str] = []
    sequence = list(candidate_seq)
    stage = candidate_stage

    while current_ids and not stage.feasible:
        lowest = current_ids[-1]
        removed_ids.append(lowest)
        current_ids = _ordered_ids(
            _structural_cleanup([pid for pid in current_ids if pid != lowest], project_map),
            ranking_ids,
        )
        current_projects = [project_map[pid] for pid in current_ids]
        sequence = build_sequence(current_projects, "MSA", base_ranking, portfolio)
        stage = stage_sequence(sequence, portfolio)

    if not current_ids:
        sequence = []
        stage = stage_sequence(sequence, portfolio)

    selected_stage_feasible = [project_map[pid] for pid in current_ids]
    metadata: Dict[str, object] = {
        "msa_candidate_ids": candidate_ids,
        "msa_candidate_sequence_ids": [p.project_id for p in candidate_seq],
        "msa_candidate_stage_feasible": bool(candidate_stage.feasible),
        "msa_candidate_stage_failure_reason": candidate_stage.failure_reason,
        "msa_fsc_applied": bool(removed_ids),
        "msa_fsc_removed_ids": removed_ids,
    }
    return selected_stage_feasible, sequence, stage, metadata

def repair_and_fill(portfolio: PortfolioInputs, projects: Sequence[Project], method: str) -> Tuple[List[Project], List[Project], StageResult]:
    project_map = {p.project_id: p for p in projects}
    base_ranking = build_base_ranking(projects, method)
    ranking_ids = [p.project_id for p in base_ranking]
    selected_ids: List[str] = []

    while True:
        changed = False
        for candidate_id in ranking_ids:
            if candidate_id in selected_ids:
                continue
            trial_ids = selected_ids + [candidate_id]
            stabilized_ids = _stabilize_subset(trial_ids, portfolio, project_map, ranking_ids, method, base_ranking)
            if stabilized_ids != selected_ids and candidate_id in stabilized_ids:
                selected_ids = stabilized_ids
                changed = True
        if not changed:
            break

    repaired = [project_map[pid] for pid in ranking_ids if pid in set(selected_ids)]
    sequence = build_sequence(repaired, method, base_ranking, portfolio)
    staged = stage_sequence(sequence, portfolio)
    return repaired, sequence, staged


# -------------------------
# Profit evaluation
# -------------------------



def _scenario_adjustment(project: Project, completion_period_1_based: int, scenario: Optional[MonteCarloScenario]) -> float:
    cot = project.cost_of_time_profile
    if scenario is None:
        return cot.deterministic_adjustment(completion_period_1_based)
    if cot.profile_type == CostOfTimeType.NONE:
        return 0.0
    if cot.profile_type == CostOfTimeType.LINEAR:
        delta = scenario.linear_cot_deltas.get(project.project_id, _det(cot.linear_delta_per_period))
        return delta * max(0, completion_period_1_based - 1)
    if cot.profile_type == CostOfTimeType.CLIFF:
        if cot.cliff_period is not None and completion_period_1_based > cot.cliff_period:
            return float("-inf")
        return 0.0
    if cot.profile_type == CostOfTimeType.PIECEWISE:
        values = scenario.piecewise_cot_values.get(project.project_id, [_det(v) for v in (cot.piecewise_adjustments or [])])
        idx = completion_period_1_based - 1
        if idx < len(values):
            return values[idx]
        return 0.0
    raise ValueError(f"Unsupported cost of time type: {cot.profile_type}")


def _profit_with_cost_and_synergy(projects: Sequence[Project], stage_result: StageResult, sampled_vectors: Optional[Dict[str, Tuple[int, List[float], List[float], float]]] = None, scenario: Optional[MonteCarloScenario] = None) -> float:
    project_map = {p.project_id: p for p in projects}
    completion = {r.project_id: r.completion_period_1 for r in stage_result.records}
    selected_ids = set(completion)
    profits: Dict[str, float] = {}

    for pid, completion_period in completion.items():
        p = project_map[pid]
        base_profit = sampled_vectors[pid][3] if sampled_vectors is not None else p.deterministic_base_profit()
        adj = _scenario_adjustment(p, completion_period, scenario)
        if adj == float("-inf"):
            profits[pid] = 0.0
        else:
            profits[pid] = base_profit + adj

    for p in projects:
        if p.project_id not in selected_ids:
            continue
        for syn_idx, syn in enumerate(p.synergies):
            if syn.target_project_id != p.project_id:
                continue
            if set(syn.related_project_ids).issubset(selected_ids):
                if scenario is not None and (p.project_id, syn_idx) in scenario.synergy_values:
                    val = scenario.synergy_values[(p.project_id, syn_idx)]
                else:
                    val = _det(syn.value)
                if syn.synergy_type == "Factor":
                    profits[p.project_id] *= val
                elif syn.synergy_type == "Fixed Adjustment":
                    profits[p.project_id] += val
                else:
                    raise ValueError(f"Unknown synergy type: {syn.synergy_type}")
    return sum(profits.values())


# -------------------------
# aOctane improvement
# -------------------------


def generate_mc_scenarios(portfolio: PortfolioInputs, projects: Sequence[Project], mc_seed: int) -> List[MonteCarloScenario]:
    rng = random.Random(mc_seed)
    scenarios: List[MonteCarloScenario] = []
    for _ in range(portfolio.monte_carlo_iterations):
        project_vectors = {p.project_id: _project_sampled_vectors(p, rng, optimistic=False) for p in projects}
        linear_cot_deltas: Dict[str, float] = {}
        piecewise_cot_values: Dict[str, List[float]] = {}
        synergy_values: Dict[Tuple[str, int], float] = {}
        for p in projects:
            cot = p.cost_of_time_profile
            if cot.profile_type == CostOfTimeType.LINEAR:
                linear_cot_deltas[p.project_id] = _sample(cot.linear_delta_per_period, rng, profit_parameter=True)
            elif cot.profile_type == CostOfTimeType.PIECEWISE:
                piecewise_cot_values[p.project_id] = [_sample(v, rng, profit_parameter=True) for v in (cot.piecewise_adjustments or [])]
            for syn_idx, syn in enumerate(p.synergies):
                synergy_values[(p.project_id, syn_idx)] = _sample(syn.value, rng, profit_parameter=True)
        scenarios.append(MonteCarloScenario(project_vectors=project_vectors, linear_cot_deltas=linear_cot_deltas, piecewise_cot_values=piecewise_cot_values, synergy_values=synergy_values))
    return scenarios


def evaluate_stochastic_from_scenarios(
    portfolio: PortfolioInputs,
    selected: Sequence[Project],
    sequence: Sequence[Project],
    scenarios: Sequence[MonteCarloScenario],
    optimistic_prefilter: bool = False,
) -> Tuple[float, float, bool, float, List[float]]:
    """Evaluate one candidate portfolio/sequence against common MC scenarios.

    Iteration 3 Step 1 rule: MSA, Octane and aOctane do not use optimistic
    staging or optimistic prefiltering. The optional optimistic_prefilter branch is
    retained only for a future sCPA/global-configuration path and must remain False
    for all Step 1 ranking-based method calls.
    """
    selected_ids = {p.project_id for p in selected}

    if optimistic_prefilter:
        optimistic_vectors = {p.project_id: _project_sampled_vectors(p, random.Random(0), optimistic=True) for p in selected}
        optimistic_stage = stage_sequence_with_feasibility_details(sequence, portfolio, sampled_vectors=optimistic_vectors)
        if not optimistic_stage.feasible:
            return 0.0, 0.0, False, 0.0, []

    profits: List[float] = []
    budget_feasible = 0
    constraint_feasible = 0
    fully_feasible_count = 0

    for scenario in scenarios:
        sampled = {pid: scenario.project_vectors[pid] for pid in selected_ids}
        staged = stage_sequence_with_feasibility_details(sequence, portfolio, sampled_vectors=sampled)
        if staged.budget_feasible:
            budget_feasible += 1
        if staged.constraint_feasible:
            constraint_feasible += 1
        if staged.feasible:
            fully_feasible_count += 1
            profits.append(_profit_with_cost_and_synergy(selected, staged, sampled_vectors=sampled, scenario=scenario))

    total = len(scenarios)
    budget_rate = budget_feasible / total if total else 0.0
    constraint_rate = constraint_feasible / total if total else 0.0
    admissible = (
        fully_feasible_count > 0
        and budget_rate >= portfolio.budget_confidence_level
        and constraint_rate >= portfolio.constraint_confidence_level
    )
    p85 = _percentile(profits, portfolio.profit_confidence_level) if profits else 0.0
    return budget_rate, constraint_rate, admissible, p85, profits

def improve_aoctane_sequence(selected: Sequence[Project], base_sequence: Sequence[Project], portfolio: PortfolioInputs, scenarios: Optional[Sequence[MonteCarloScenario]] = None) -> Tuple[List[Project], StageResult, float]:
    current = list(base_sequence)
    current_stage = stage_sequence(current, portfolio)
    current_det = _profit_with_cost_and_synergy(selected, current_stage)
    if scenarios is None:
        current_admissible = current_stage.feasible
        current_objective = current_det
    else:
        _, _, current_admissible, current_objective, _ = evaluate_stochastic_from_scenarios(portfolio, selected, current, scenarios)

    while True:
        accepted_any = False
        for i in range(len(current) - 1):
            trial = list(current)
            trial[i], trial[i + 1] = trial[i + 1], trial[i]
            # Iteration 3 Step 1 AOC-SWAP-01:
            # local swap candidates are first made dependency-aware and then
            # deterministic-feasibility screened. Infeasible swaps are rejected
            # without Monte Carlo evaluation.
            trial = _dependency_aware_stable_order(trial)
            if [p.project_id for p in trial] == [p.project_id for p in current]:
                continue
            staged = stage_sequence(trial, portfolio)
            if not staged.feasible:
                continue
            trial_det = _profit_with_cost_and_synergy(selected, staged)
            if scenarios is None:
                trial_admissible = staged.feasible
                trial_objective = trial_det
                improves = trial_objective >= current_objective - 1e-12 and trial_objective > current_objective + 1e-12
            else:
                _, _, trial_admissible, trial_objective, _ = evaluate_stochastic_from_scenarios(portfolio, selected, trial, scenarios)
                improves = (
                    (trial_admissible and not current_admissible)
                    or (
                        trial_admissible == current_admissible
                        and trial_objective >= current_objective - 1e-12
                        and trial_objective > current_objective + 1e-12
                    )
                )
            if improves:
                current = trial
                current_stage = staged
                current_det = trial_det
                current_admissible = trial_admissible
                current_objective = trial_objective
                accepted_any = True
                break
        if not accepted_any:
            break

    return current, current_stage, current_objective

# -------------------------
# Stochastic evaluation
# -------------------------


def evaluate_stochastic(portfolio: PortfolioInputs, selected: Sequence[Project], sequence: Sequence[Project], mc_seed: int) -> Tuple[float, float, bool, float, List[float]]:
    scenarios = generate_mc_scenarios(portfolio, selected, mc_seed)
    return evaluate_stochastic_from_scenarios(portfolio, selected, sequence, scenarios, optimistic_prefilter=False)


def _percentile(values: Sequence[float], q: float) -> float:
    if not values:
        return 0.0
    vals = sorted(values)
    if q <= 0:
        return vals[0]
    if q >= 1:
        return vals[-1]
    idx = max(0, min(len(vals) - 1, math.ceil(q * len(vals)) - 1))
    return vals[idx]


# -------------------------
# Iteration 3 Step 1 comparison metrics
# -------------------------


def _denominator_safe(value: float, eps: float = DENOMINATOR_EPSILON) -> bool:
    return value > eps


def _safe_percent_delta(numerator: float, denominator: float) -> Tuple[Optional[float], bool, Optional[str]]:
    if not _denominator_safe(denominator):
        reason = "baseline_non_positive_or_near_zero"
        return None, False, reason
    return numerator / denominator * 100.0, True, None


def apply_iteration3_world_metrics(methods: Dict[str, MethodOutcome]) -> Dict[str, Dict[str, object]]:
    """Populate per-world winner/waste metrics and return pairwise comparisons.

    Waste is calculated against the best evaluated profit among staged, admissible,
    non-empty Step 1 methods in the same world. Percentages are reported only when
    denominators are positive and denominator-safe.
    """
    comparable = [
        out for out in methods.values()
        if out.selected_ids and out.stage_result.feasible and out.admissible
    ]
    if comparable:
        best_profit = max(out.evaluated_profit for out in comparable)
        best_safe = _denominator_safe(best_profit)
        for out in methods.values():
            out.best_profit_in_world = best_profit
            out.winner_flag = bool(
                out in comparable and abs(out.evaluated_profit - best_profit) <= 1e-9
            )
            if out in comparable:
                out.absolute_waste = max(0.0, best_profit - out.evaluated_profit)
                out.waste_denominator_safe = best_safe
                if best_safe:
                    out.percent_waste = out.absolute_waste / best_profit * 100.0
                    out.denominator_sensitive_reason = None
                else:
                    out.percent_waste = None
                    out.denominator_sensitive_reason = "best_profit_non_positive_or_near_zero"
            else:
                out.absolute_waste = None
                out.percent_waste = None
                out.waste_denominator_safe = False
                out.denominator_sensitive_reason = "method_not_comparable_in_world"
    else:
        for out in methods.values():
            out.best_profit_in_world = None
            out.winner_flag = False
            out.absolute_waste = None
            out.percent_waste = None
            out.waste_denominator_safe = False
            out.denominator_sensitive_reason = "no_admissible_staged_nonempty_method"

    pairs = [("aOctane", "MSA"), ("aOctane", "Octane"), ("Octane", "MSA")]
    pairwise: Dict[str, Dict[str, object]] = {}
    for a, b in pairs:
        key = f"{a}_vs_{b}"
        if a not in methods or b not in methods:
            continue
        out_a, out_b = methods[a], methods[b]
        if not (out_a.selected_ids and out_b.selected_ids and out_a.stage_result.feasible and out_b.stage_result.feasible and out_a.admissible and out_b.admissible):
            pairwise[key] = {
                "method_a": a,
                "method_b": b,
                "delta_profit": None,
                "percent_delta_profit": None,
                "denominator_safe": False,
                "denominator_sensitive_reason": "pair_not_comparable_in_world",
            }
            continue
        delta = out_a.evaluated_profit - out_b.evaluated_profit
        pct, safe, reason = _safe_percent_delta(delta, out_b.evaluated_profit)
        pairwise[key] = {
            "method_a": a,
            "method_b": b,
            "delta_profit": delta,
            "percent_delta_profit": pct,
            "denominator_safe": safe,
            "denominator_sensitive_reason": reason,
            "baseline_profit": out_b.evaluated_profit,
        }
    return pairwise


def _median_or_zero(values: Sequence[float]) -> float:
    return float(median(values)) if values else 0.0


# -------------------------
# End-to-end world run
# -------------------------


def run_world(portfolio: PortfolioInputs, projects: Sequence[Project], world_seed: int = 1) -> ComparativeWorldResult:
    methods: Dict[str, MethodOutcome] = {}
    octane_selected: List[Project] | None = None
    octane_sequence: List[Project] | None = None
    all_scenarios = generate_mc_scenarios(portfolio, projects, world_seed + 424242)
    octane_scenarios: Optional[List[MonteCarloScenario]] = None

    for method in ["MSA", "Octane", "aOctane"]:
        repaired, sequence, stage = repair_and_fill(portfolio, projects, "Octane" if method == "aOctane" else method)
        msa_fsc_metadata: Dict[str, object] = {}
        if method == "MSA":
            base_ranking = build_base_ranking(projects, "MSA")
            repaired, sequence, stage, msa_fsc_metadata = apply_msa_final_sequence_feasibility_cap(
                portfolio, repaired, base_ranking
            )
        deterministic_profit = _profit_with_cost_and_synergy(repaired, stage) if stage.feasible else 0.0

        aoctane_guard_fallback_used = False
        if method == "aOctane":
            assert octane_selected is not None and octane_sequence is not None and octane_scenarios is not None
            repaired = list(octane_selected)
            sequence, stage, _aoctane_objective = improve_aoctane_sequence(repaired, octane_sequence, portfolio, scenarios=octane_scenarios)

            # Hard safeguard: aOctane may never be worse than Octane when evaluated on the same selected set
            # and the same stochastic scenarios. If the local search fails to improve or preserve Octane,
            # fall back to the original Octane sequence.
            _oct_budget, _oct_constraint, _oct_admissible, _oct_p85, _ = evaluate_stochastic_from_scenarios(
                portfolio, repaired, octane_sequence, octane_scenarios, optimistic_prefilter=False
            )
            _ao_budget, _ao_constraint, _ao_admissible, _ao_p85, _ = evaluate_stochastic_from_scenarios(
                portfolio, repaired, sequence, octane_scenarios, optimistic_prefilter=False
            )
            if (_ao_p85 + 1e-12 < _oct_p85) or (_oct_admissible and not _ao_admissible):
                sequence = list(octane_sequence)
                stage = stage_sequence(sequence, portfolio)
                aoctane_guard_fallback_used = True

            deterministic_profit = _profit_with_cost_and_synergy(repaired, stage) if stage.feasible else 0.0
        else:
            if method == "Octane":
                octane_selected = list(repaired)
                octane_sequence = list(sequence)
                octane_ids = {p.project_id for p in repaired}
                octane_scenarios = [
                    MonteCarloScenario(
                        project_vectors={pid: sc.project_vectors[pid] for pid in octane_ids},
                        linear_cot_deltas={pid: sc.linear_cot_deltas[pid] for pid in octane_ids if pid in sc.linear_cot_deltas},
                        piecewise_cot_values={pid: sc.piecewise_cot_values[pid] for pid in octane_ids if pid in sc.piecewise_cot_values},
                        synergy_values={(pid, syn_idx): val for (pid, syn_idx), val in sc.synergy_values.items() if pid in octane_ids},
                    )
                    for sc in all_scenarios
                ]

        if stage.feasible:
            selected_ids = {p.project_id for p in repaired}
            scenarios_for_method = [
                MonteCarloScenario(
                    project_vectors={pid: sc.project_vectors[pid] for pid in selected_ids},
                    linear_cot_deltas={pid: sc.linear_cot_deltas[pid] for pid in selected_ids if pid in sc.linear_cot_deltas},
                    piecewise_cot_values={pid: sc.piecewise_cot_values[pid] for pid in selected_ids if pid in sc.piecewise_cot_values},
                    synergy_values={(pid, syn_idx): val for (pid, syn_idx), val in sc.synergy_values.items() if pid in selected_ids},
                )
                for sc in (octane_scenarios if method == "aOctane" else all_scenarios)
            ]
            budget_rate, constraint_rate, admissible, p85, profits = evaluate_stochastic_from_scenarios(
                portfolio, repaired, sequence, scenarios_for_method, optimistic_prefilter=False
            )
        else:
            budget_rate, constraint_rate, admissible, p85, profits = (0.0, 0.0, False, 0.0, [])

        methods[method] = MethodOutcome(
            method=method,
            selected_ids=[p.project_id for p in repaired],
            repaired_ids=[p.project_id for p in repaired],
            sequence_ids=[p.project_id for p in sequence],
            stage_result=stage,
            deterministic_profit=deterministic_profit,
            budget_feasibility_rate=budget_rate,
            constraint_feasibility_rate=constraint_rate,
            admissible=admissible,
            p85_profit=p85,
            evaluated_profit=p85,
            mc_profits=profits,
            optimistic_prefilter_applied=False,
            stochastic_evaluation_object="final_candidate_portfolio",
            aoctane_guard_fallback_used=aoctane_guard_fallback_used if method == "aOctane" else False,
            msa_candidate_ids=list(msa_fsc_metadata.get("msa_candidate_ids", [])),
            msa_candidate_sequence_ids=list(msa_fsc_metadata.get("msa_candidate_sequence_ids", [])),
            msa_candidate_stage_feasible=msa_fsc_metadata.get("msa_candidate_stage_feasible"),
            msa_candidate_stage_failure_reason=msa_fsc_metadata.get("msa_candidate_stage_failure_reason"),
            msa_fsc_applied=bool(msa_fsc_metadata.get("msa_fsc_applied", False)),
            msa_fsc_removed_ids=list(msa_fsc_metadata.get("msa_fsc_removed_ids", [])),
        )

    # Hard aOctane guardrails.
    if methods["aOctane"].selected_ids != methods["Octane"].selected_ids:
        raise RuntimeError("aOctane selection diverged from Octane selection")

    pairwise_comparisons = apply_iteration3_world_metrics(methods)

    acceptance_reasons: List[str] = []
    non_empty = [m for m in methods.values() if m.selected_ids and m.stage_result.feasible]
    if len(non_empty) < 2:
        acceptance_reasons.append("fewer than two methods produced non-empty staged portfolios")
    compared = [m for m in methods.values() if m.admissible and m.stage_result.feasible]
    if len(compared) < 2:
        acceptance_reasons.append("fewer than two methods admissible and staged")
    profits = {m.method: round(m.p85_profit, 8) for m in compared}
    if len(set(profits.values())) < 2 and len(compared) >= 2:
        seqs = {m.method: tuple(m.sequence_ids) for m in compared}
        if len(set(seqs.values())) < 2:
            acceptance_reasons.append("no meaningful differentiation in profit or sequence")

    return ComparativeWorldResult(
        portfolio_id=portfolio.portfolio_id,
        methods=methods,
        accepted_for_comparative_analysis=(len(acceptance_reasons) == 0),
        acceptance_reasons=acceptance_reasons,
        pairwise_comparisons=pairwise_comparisons,
    )

# -------------------------
# Synthetic 50-project generator for benchmarking
# -------------------------




def generate_synthetic_50_project_world(
    seed: int,
    budget_scale: float = 0.92,
    budget_horizon_periods: int = 11,
    early_capacity_delta: float = 0.0,
    spread_shrink: float = 0.08,
    stochastic_inputs: bool = True,
    duration_spread: float = 0.16,
    budget_spread: float = 0.18,
    constraint_spread: float = 0.20,
    profit_spread: float = 0.18,
    monte_carlo_iterations: int = 120,
    budget_confidence_level: float = 0.80,
    constraint_confidence_level: float = 0.80,
    regime_profile: str = "transition",
    constraint_discrimination: Optional[float] = None,
    time_sensitivity_intensity: Optional[float] = None,
    uncertainty_level: Optional[float] = None,
    dependency_density: Optional[float] = None,
    synergy_density: Optional[float] = None,
    synergy_intensity: Optional[float] = None,
) -> Tuple[PortfolioInputs, List[Project]]:
    """
    Regime-aware synthetic world generator.

    regime_profile presets:
    - "msa_side": high-profit projects use more of the constraint, urgency aligns with profit,
      time sensitivity is mild, dependencies/synergies are light.
    - "transition": mixed structure, moderate time sensitivity, moderate dependencies.
    - "octane_family": cleaner throughput logic, lower dependency density, moderate-to-high
      time sensitivity, and stronger sequencing upside.
    """
    preset = {
        "msa_side": {
            "constraint_discrimination": 1.25,   # stronger penalty against Octane-family for top-profit projects
            "time_sensitivity_intensity": 0.05,
            "uncertainty_level": 0.12,
            "dependency_density": 0.03,
            "synergy_density": 0.01,
            "synergy_intensity": 0.03,
        },
        "transition": {
            "constraint_discrimination": 0.15,
            "time_sensitivity_intensity": 0.55,
            "uncertainty_level": 1.00,
            "dependency_density": 0.22,
            "synergy_density": 0.12,
            "synergy_intensity": 0.55,
        },
        "octane_family": {
            "constraint_discrimination": -0.45,  # negative => high-profit uses LESS constraint
            "time_sensitivity_intensity": 0.80,
            "uncertainty_level": 0.90,
            "dependency_density": 0.14,
            "synergy_density": 0.08,
            "synergy_intensity": 0.45,
        },
    }.get(regime_profile, {
        "constraint_discrimination": 0.15,
        "time_sensitivity_intensity": 0.55,
        "uncertainty_level": 1.00,
        "dependency_density": 0.22,
        "synergy_density": 0.12,
        "synergy_intensity": 0.55,
    })

    constraint_discrimination = preset["constraint_discrimination"] if constraint_discrimination is None else constraint_discrimination
    time_sensitivity_intensity = preset["time_sensitivity_intensity"] if time_sensitivity_intensity is None else time_sensitivity_intensity
    uncertainty_level = preset["uncertainty_level"] if uncertainty_level is None else uncertainty_level
    dependency_density = preset["dependency_density"] if dependency_density is None else dependency_density
    synergy_density = preset["synergy_density"] if synergy_density is None else synergy_density
    synergy_intensity = preset["synergy_intensity"] if synergy_intensity is None else synergy_intensity

    # rescale spreads by uncertainty_level
    duration_spread = max(0.01, duration_spread * uncertainty_level)
    budget_spread = max(0.01, budget_spread * uncertainty_level)
    constraint_spread = max(0.01, constraint_spread * uncertainty_level)
    profit_spread = max(0.01, profit_spread * uncertainty_level)

    rng = random.Random(seed)

    if regime_profile == "msa_side":
        budget_base = [500, 480, 460, 440, 420, 400, 380, 360, 340, 320, 300, 280, 260, 240, 220]
        capacity_base = 32.0
    elif regime_profile == "octane_family":
        budget_base = [350, 335, 320, 300, 285, 270, 255, 240, 220, 205, 190, 175, 160, 145, 130]
        capacity_base = 20.0
    else:
        budget_base = [360, 340, 320, 300, 280, 255, 230, 205, 180, 160, 140, 120, 105, 90, 75]
        capacity_base = 22.0

    budget_profile = [round(v * budget_scale, 3) for v in budget_base[:budget_horizon_periods]]
    horizon_len = max(15, budget_horizon_periods)
    capacity_profile = [max(7.0, capacity_base + (early_capacity_delta if i < 4 else 0.0) - i * 0.45) for i in range(horizon_len)]

    portfolio = PortfolioInputs(
        portfolio_id=f"synthetic_50_{regime_profile}_seed_{seed}",
        budget_restriction_profile=budget_profile,
        constraint_capacity_profile=capacity_profile,
        budget_horizon_rule=HorizonRule.ZERO_BEYOND,
        monte_carlo_iterations=monte_carlo_iterations,
        budget_confidence_level=budget_confidence_level,
        constraint_confidence_level=constraint_confidence_level,
        profit_confidence_level=0.85,
    )

    ids = [f"P{i:02d}" for i in range(1, 51)]
    # latent quality: top half materially stronger
    quality = [rng.random() for _ in ids]
    order = sorted(range(50), key=lambda i: quality[i], reverse=True)
    tier = {order[i]: ("top" if i < 12 else "mid" if i < 32 else "low") for i in range(50)}

    projects: List[Project] = []
    for idx, pid in enumerate(ids):
        t = tier[idx]
        if t == "top":
            base_profit_ml = rng.uniform(175, 320)
            duration_ml = rng.randint(2, 5)
        elif t == "mid":
            base_profit_ml = rng.uniform(95, 210)
            duration_ml = rng.randint(2, 6)
        else:
            base_profit_ml = rng.uniform(45, 135)
            duration_ml = rng.randint(1, 5)

        if regime_profile == "msa_side":
            urgency = (Urgency.HIGH if t == "top" else (Urgency.MEDIUM if t == "mid" and rng.random() < 0.85 else Urgency.NORMAL))
        elif regime_profile == "octane_family":
            urgency = rng.choices([Urgency.HIGH, Urgency.MEDIUM, Urgency.NORMAL], weights=[0.12, 0.24, 0.64])[0]
        else:
            urgency = rng.choices([Urgency.HIGH, Urgency.MEDIUM, Urgency.NORMAL], weights=[0.18, 0.30, 0.52])[0]

        # budget profile
        total_budget = rng.uniform(50, 170) if t != "top" else rng.uniform(95, 220)
        shape = [rng.uniform(0.65, 1.35) for _ in range(duration_ml)]
        ssum = sum(shape)
        budget_profile_proj = [round(total_budget * x / ssum, 3) for x in shape]

        # constraint usage linked or anti-linked with profit through constraint_discrimination
        uses_constraint = rng.random() < (0.88 if regime_profile != "msa_side" else 0.62)
        if uses_constraint:
            base_load = rng.uniform(1.8, 6.6)
            tier_sign = 1.0 if t == "top" else (0.0 if t == "mid" else -1.0)
            # positive discrimination => top projects use more constraint
            discrim_mult = 1.0 + constraint_discrimination * 0.35 * tier_sign
            discrim_mult = max(0.35, discrim_mult)
            load_shape = [
                max(0.0, base_load * discrim_mult * rng.uniform(0.85, 1.15) * (1.0 - spread_shrink * abs(j - (duration_ml - 1) / 2)))
                for j in range(duration_ml)
            ]
        else:
            load_shape = [0.0] * duration_ml
        load_shape = [round(v, 3) for v in load_shape]

        deps: List[str] = []
        if idx > 3 and rng.random() < dependency_density:
            max_dep = 2 if rng.random() < 0.25 else 1
            pool = ids[:idx]
            dep_count = min(max_dep, len(pool))
            deps = sorted(rng.sample(pool, dep_count))

        # cost of time
        cliff_prob = 0.08 + 0.38 * time_sensitivity_intensity
        if t == "top":
            cliff_prob += 0.10 * time_sensitivity_intensity
        if regime_profile == "msa_side":
            cliff_prob *= 0.20
        cliff = None
        if rng.random() < cliff_prob:
            cliff = rng.randint(5, 12 if regime_profile != "octane_family" else 10)
        if cliff is not None:
            cot = CostOfTimeProfile(profile_type=CostOfTimeType.CLIFF, cliff_period=cliff)
        else:
            # more negative in octane_family/transition, very mild in msa_side
            base_delta = rng.uniform(-1.2, -0.1) if regime_profile == "msa_side" else rng.uniform(-10.0, -1.2)
            cot = CostOfTimeProfile(profile_type=CostOfTimeType.LINEAR, linear_delta_per_period=round(base_delta * max(0.35, time_sensitivity_intensity), 3))

        if stochastic_inputs:
            dur_opt = max(1, int(math.floor(duration_ml * (1.0 - duration_spread))))
            dur_pes = max(dur_opt + 1, int(math.ceil(duration_ml * (1.0 + duration_spread))))
            duration_value: int | ThreePoint = ThreePoint(dur_opt, duration_ml, dur_pes)
            profit_value: ScalarOr3P = ThreePoint(
                round(base_profit_ml * (1.0 + profit_spread), 3),
                round(base_profit_ml, 3),
                round(base_profit_ml * (1.0 - profit_spread), 3),
            )
            budget_profile_value: List[ScalarOr3P] = [
                ThreePoint(round(max(0.0, v * (1.0 - budget_spread)), 3), round(v, 3), round(v * (1.0 + budget_spread), 3))
                for v in budget_profile_proj
            ]
            constraint_profile_value: List[ScalarOr3P] = [
                ThreePoint(round(max(0.0, v * (1.0 - constraint_spread)), 3), round(v, 3), round(v * (1.0 + constraint_spread), 3))
                for v in load_shape
            ]
            if cot.profile_type == CostOfTimeType.LINEAR:
                ml = float(cot.linear_delta_per_period)
                cot.linear_delta_per_period = ThreePoint(round(ml * 0.85, 3), round(ml, 3), round(ml * 1.15, 3))
        else:
            duration_value = duration_ml
            profit_value = round(base_profit_ml, 3)
            budget_profile_value = budget_profile_proj
            constraint_profile_value = load_shape

        # POL3-aligned MSA urgency: derive from cost-of-time relative to the
        # project's base profit, overriding any earlier placeholder/random label.
        urgency = derive_urgency_from_cost_of_time(profit_value, cot)

        projects.append(Project(
            project_id=pid,
            base_profit=profit_value,
            duration=duration_value,
            budget_usage_profile=budget_profile_value,
            constraint_usage_profile=constraint_profile_value,
            structural_dependencies=deps,
            urgency_class=urgency,
            cost_of_time_profile=cot,
        ))

    # controlled synergies
    if synergy_density > 0:
        for p in projects:
            if rng.random() < synergy_density:
                candidate_related = [q.project_id for q in projects if q.project_id != p.project_id]
                related = sorted(rng.sample(candidate_related, 1 if rng.random() < 0.8 else 2))
                if rng.random() < 0.65:
                    factor_ml = 1.0 + 0.20 * synergy_intensity + rng.uniform(0.0, 0.12 * synergy_intensity)
                    value = ThreePoint(round(factor_ml + 0.08, 3), round(factor_ml, 3), round(max(0.85, factor_ml - 0.12), 3)) if stochastic_inputs else round(factor_ml, 3)
                    synergy_type = "Factor"
                else:
                    adj_ml = rng.uniform(8.0, 32.0) * max(0.2, synergy_intensity)
                    value = ThreePoint(round(adj_ml * 1.35, 3), round(adj_ml, 3), round(-0.15 * adj_ml, 3)) if stochastic_inputs else round(adj_ml, 3)
                    synergy_type = "Fixed Adjustment"
                p.synergies.append(Synergy(
                    target_project_id=p.project_id,
                    related_project_ids=related,
                    synergy_type=synergy_type,
                    value=value,
                ))
    return portfolio, projects

def run_benchmark_batch(
    world_seeds: Sequence[int],
    generator_kwargs: Optional[Dict[str, object]] = None,
) -> Dict[str, object]:
    generator_kwargs = dict(generator_kwargs or {})
    world_results: List[ComparativeWorldResult] = []
    for seed in world_seeds:
        portfolio, projects = generate_synthetic_50_project_world(seed, **generator_kwargs)
        world_results.append(run_world(portfolio, projects, world_seed=seed * 1000))

    accepted = [w for w in world_results if w.accepted_for_comparative_analysis]
    by_method = {m: [] for m in ["MSA", "Octane", "aOctane"]}
    abs_waste_by_method = {m: [] for m in ["MSA", "Octane", "aOctane"]}
    pct_waste_by_method = {m: [] for m in ["MSA", "Octane", "aOctane"]}
    pct_waste_denominator_sensitive = {m: 0 for m in ["MSA", "Octane", "aOctane"]}
    wins = {m: 0 for m in ["MSA", "Octane", "aOctane", "tie", "none"]}
    pairwise_pct_delta = {k: [] for k in ["aOctane_vs_MSA", "aOctane_vs_Octane", "Octane_vs_MSA"]}
    pairwise_denominator_sensitive = {k: 0 for k in pairwise_pct_delta}

    for world in accepted:
        profits = {m: world.methods[m].evaluated_profit for m in ["MSA", "Octane", "aOctane"]}
        max_profit = max(profits.values())
        winners = [m for m, v in profits.items() if abs(v - max_profit) < 1e-9]
        if len(winners) == 1:
            wins[winners[0]] += 1
        elif len(winners) > 1:
            wins["tie"] += 1
        else:
            wins["none"] += 1
        for m in by_method:
            out = world.methods[m]
            by_method[m].append(out.evaluated_profit)
            if out.absolute_waste is not None:
                abs_waste_by_method[m].append(out.absolute_waste)
            if out.percent_waste is not None:
                pct_waste_by_method[m].append(out.percent_waste)
            elif out.waste_denominator_safe is False:
                pct_waste_denominator_sensitive[m] += 1
        for key, comp in world.pairwise_comparisons.items():
            if key not in pairwise_pct_delta:
                continue
            pct = comp.get("percent_delta_profit")
            if pct is not None:
                pairwise_pct_delta[key].append(float(pct))
            else:
                pairwise_denominator_sensitive[key] += 1

    summary = {
        "engine_version": ENGINE_VERSION,
        "attempted_worlds": len(world_results),
        "accepted_worlds": len(accepted),
        "acceptance_rate": 0.0 if not world_results else len(accepted) / len(world_results),
        "winner_counts": wins,
        "winner_share": {m: (wins[m] / len(accepted) if accepted else 0.0) for m in ["MSA", "Octane", "aOctane"]},
        "mean_p85": {m: (mean(vals) if vals else 0.0) for m, vals in by_method.items()},
        "p85_std": {m: (pstdev(vals) if len(vals) > 1 else 0.0) for m, vals in by_method.items()},
        "median_evaluated_profit": {m: _median_or_zero(vals) for m, vals in by_method.items()},
        "median_absolute_waste": {m: _median_or_zero(vals) for m, vals in abs_waste_by_method.items()},
        "median_denominator_safe_percent_waste": {m: _median_or_zero(vals) for m, vals in pct_waste_by_method.items()},
        "percent_waste_denominator_sensitive_count": pct_waste_denominator_sensitive,
        "pairwise_median_denominator_safe_percent_delta_profit": {k: _median_or_zero(vals) for k, vals in pairwise_pct_delta.items()},
        "pairwise_denominator_sensitive_count": pairwise_denominator_sensitive,
        "mean_aoctane_vs_octane_uplift_pct": 0.0 if not by_method["Octane"] else mean(
            [((a - o) / o * 100.0) if o > DENOMINATOR_EPSILON else 0.0 for a, o in zip(by_method["aOctane"], by_method["Octane"])]
        ),
        "aoctane_vs_octane_invariant_violations": sum(
            1 for w in accepted if w.methods["aOctane"].evaluated_profit + 1e-9 < w.methods["Octane"].evaluated_profit
        ),
        "aoctane_guard_fallback_count": sum(
            1 for w in world_results if w.methods.get("aOctane") and w.methods["aOctane"].aoctane_guard_fallback_used
        ),
        "worlds": [serialize_world_result(w) for w in world_results],
    }
    return summary


def serialize_world_result(world: ComparativeWorldResult) -> Dict[str, object]:
    methods_payload: Dict[str, object] = {}
    for m, out in world.methods.items():
        payload = {
            "selected_count": len(out.selected_ids),
            "selected_ids": out.selected_ids,
            "sequence_ids": out.sequence_ids,
            "deterministic_profit": out.deterministic_profit,
            "p85_profit": out.p85_profit,
            "evaluated_profit": out.evaluated_profit,
            "stochastic_evaluation_object": out.stochastic_evaluation_object,
            "optimistic_prefilter_applied": out.optimistic_prefilter_applied,
            "best_profit_in_world": out.best_profit_in_world,
            "winner_flag": out.winner_flag,
            "absolute_waste": out.absolute_waste,
            "percent_waste": out.percent_waste,
            "waste_denominator_safe": out.waste_denominator_safe,
            "denominator_sensitive_reason": out.denominator_sensitive_reason,
            "aoctane_guard_fallback_used": out.aoctane_guard_fallback_used,
            "budget_feasibility_rate": out.budget_feasibility_rate,
            "constraint_feasibility_rate": out.constraint_feasibility_rate,
            "admissible": out.admissible,
            "stage_feasible": out.stage_result.feasible,
        }
        if m == "MSA":
            payload.update({
                "msa_candidate_count": len(out.msa_candidate_ids),
                "msa_candidate_ids": out.msa_candidate_ids,
                "msa_candidate_sequence_ids": out.msa_candidate_sequence_ids,
                "msa_candidate_stage_feasible": out.msa_candidate_stage_feasible,
                "msa_candidate_stage_failure_reason": out.msa_candidate_stage_failure_reason,
                "msa_fsc_applied": out.msa_fsc_applied,
                "msa_fsc_removed_count": len(out.msa_fsc_removed_ids),
                "msa_fsc_removed_ids": out.msa_fsc_removed_ids,
            })
        methods_payload[m] = payload
    return {
        "engine_version": ENGINE_VERSION,
        "portfolio_id": world.portfolio_id,
        "accepted_for_comparative_analysis": world.accepted_for_comparative_analysis,
        "acceptance_reasons": world.acceptance_reasons,
        "pairwise_comparisons": world.pairwise_comparisons,
        "methods": methods_payload,
    }


if __name__ == "__main__":
    # Small smoke run
    portfolio, projects = generate_synthetic_50_project_world(seed=13, budget_scale=0.8, budget_horizon_periods=12, early_capacity_delta=4, spread_shrink=0.05)
    result = run_world(portfolio, projects, world_seed=13000)
    print(json.dumps(serialize_world_result(result), indent=2))
