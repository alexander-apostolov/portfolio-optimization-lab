#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p ../results/reproduced
for regime in R1_MSA_STRATEGIC_WIN R2_MSA_SEQUENCING_EDGE R3_NEUTRAL_KNOWLEDGE_WORK R5_BOTTLENECKED_KNOWLEDGE_WORK R4_AOCTANE_TRANSITION R7_AOCTANE_SWAP_TRIUMPH; do
  python run_reference_point.py "$regime" --start 1 --end 40 --selection-mc 100 --eval-mc 500 --outdir ../results/reproduced
done
python ../validation/validate_reference_results.py --results-dir ../results/reproduced
