#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, time
from pathlib import Path

from pol_step1_reference_common import reevaluate, aggregate, write_summary_txt, method_admissible
from pol_step1_reference_generators import GENS


def main():
    ap = argparse.ArgumentParser(description='Run one POL Step 1 reference point.')
    ap.add_argument('regime', choices=sorted(GENS))
    ap.add_argument('--start', type=int, default=1)
    ap.add_argument('--end', type=int, default=40)
    ap.add_argument('--selection-mc', type=int, default=100)
    ap.add_argument('--eval-mc', type=int, default=500)
    ap.add_argument('--outdir', default='../results/reproduced')
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    gen = GENS[args.regime]
    worlds = []
    t0 = time.time()
    for seed in range(args.start, args.end + 1):
        w = reevaluate(args.regime, gen, seed, args.selection_mc, args.eval_mc)
        worlds.append(w)
        adm = [m for m in ['MSA', 'Octane', 'aOctane'] if method_admissible(w['methods'][m])]
        print(args.regime, seed, 'accepted', w['accepted_for_comparative_analysis'], 'pattern', '+'.join(adm) or 'none', 'elapsed', round(time.time() - t0, 1), flush=True)

    agg = aggregate(args.regime, worlds, args.selection_mc, args.eval_mc)
    out = outdir / f'step1_{args.regime}_{args.start:03d}_{args.end:03d}_selmc{args.selection_mc}_evalmc{args.eval_mc}.json'
    out.write_text(json.dumps(agg, indent=2, ensure_ascii=False), encoding='utf-8')
    write_summary_txt(agg, out.with_suffix('.txt'))
    print(out)


if __name__ == '__main__':
    main()
