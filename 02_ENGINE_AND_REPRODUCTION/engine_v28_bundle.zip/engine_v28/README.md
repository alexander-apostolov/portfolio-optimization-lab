# POL Step 1 Engine v28 — POL3 Six-Regime MC500-Validated Package

This package contains the POL3 Step 1 View 1 canonical six-regime source and generated MC100/MC500 reference artifacts.

## Canonical regimes

1. R1 — MSA Strategic Win
2. R2 — MSA Sequencing Edge
3. R3 — Neutral / Low-Scarcity Knowledge Work
4. R5 — Bottlenecked Knowledge Work
5. R4 — Octane-Family Selection Win
6. R7 — aOctane Swap Triumph

The ordering is causal rather than numeric-continuous: R5 is placed between R3 and R4 because it is the bottlenecked knowledge-work anchor. Superseded v27 R5/R6 artifacts are archived and are not canonical in v28.

## Validation

Run:

```bash
python validation/iteration3_step1_alignment_tests.py
python validation/urgency_time_erosion_alignment_audit.py
python validation/validate_reference_results.py --results-dir results/MC500 --eval-mc 500
```

For MC100 structural validation:

```bash
python validation/validate_reference_results.py --results-dir results/MC100 --eval-mc 100
```

## Scope

This package completes View 1: Conditional Comparative Performance. View 2 / operational survivability under stronger stochastic feasibility uncertainty is a separate next layer.
