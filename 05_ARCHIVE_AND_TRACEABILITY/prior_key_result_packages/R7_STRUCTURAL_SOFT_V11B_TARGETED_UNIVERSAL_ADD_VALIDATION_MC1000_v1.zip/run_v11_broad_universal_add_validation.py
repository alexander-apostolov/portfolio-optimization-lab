from __future__ import annotations
import json, csv, statistics, zipfile, shutil, importlib.util, math
from pathlib import Path

spec=importlib.util.spec_from_file_location('v8','/mnt/data/run_custom_v8.py')
v8=importlib.util.module_from_spec(spec); spec.loader.exec_module(v8)
eng=v8.v7.eng

SEEDS=list(range(1,11)); METHODS=['MSA','Octane','aOctane','sCPA_lite']; RANKING=['MSA','Octane','aOctane']
SRC=Path('/mnt/data/R7_STRUCTURAL_SOFT_V10_RESIDUAL_UNIVERSAL_ADD_ALLMETHODS_FAST_MC100screen_MC1000_v1')
TEST_ID='R7_STRUCTURAL_SOFT_V11_BROAD_UNIVERSAL_ADD_VALIDATION_MC1000_v1'
OUT=Path('/mnt/data')/TEST_ID; ZIP=Path(str(OUT)+'.zip')
FINAL_MC=1000; MAX_ITERS=5; DENOM_EPS=1e-9; NEAR_ALL_THRESHOLD=34
if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir()

def det(x): return float(x.deterministic() if hasattr(x,'deterministic') else x)
def pmap_world(seed):
    p,ps=v8.world(seed,FINAL_MC); return p,ps,{x.project_id:x for x in ps}
def method_valid(md): return bool(md.get('admissible') and md.get('stage_feasible') and md.get('selected_count',0)>0)
def pct(delta,den): return None if delta is None or den is None or den<=DENOM_EPS else delta/den*100.0

def structural_valid(ids,pmap):
    s=set(ids); return all((pid in pmap) and set(pmap[pid].structural_dependencies).issubset(s) for pid in s)
def dependency_bundle(pid,pmap):
    out=[]; seen=set()
    def visit(x):
        if x in seen or x not in pmap: return
        seen.add(x)
        for pre in pmap[x].structural_dependencies: visit(pre)
        out.append(x)
    visit(pid); return out

def time_pressure(p):
    cot=p.cost_of_time_profile
    if cot.profile_type.value=='Linear': return abs(det(cot.linear_delta_per_period))/max(abs(p.deterministic_base_profit()),1e-9)
    if cot.profile_type.value=='Cliff': return 1.0
    return 0.0

def constraint_total(p):
    d=p.deterministic_duration(); return sum(det(v) for v in eng._normalize_profile(p.constraint_usage_profile,d))
def budget_total(p):
    d=p.deterministic_duration(); return sum(det(v) for v in eng._derive_budget_profile(p,d))

def make_seq(pmap, ids, order):
    ids=list(dict.fromkeys([i for i in ids if i in pmap])); s=set(ids)
    seq=[pmap[i] for i in order if i in pmap and i in s]
    existing={p.project_id for p in seq}
    seq += [pmap[i] for i in ids if i not in existing]
    return eng._dependency_aware_stable_order(seq)

def subset_scenarios(scenarios, ids, n=None):
    ids=set(ids); source=scenarios if n is None else scenarios[:n]
    return [eng.MonteCarloScenario(
        project_vectors={pid:sc.project_vectors[pid] for pid in ids if pid in sc.project_vectors},
        linear_cot_deltas={pid:sc.linear_cot_deltas[pid] for pid in ids if pid in sc.linear_cot_deltas},
        piecewise_cot_values={pid:sc.piecewise_cot_values[pid] for pid in ids if pid in sc.piecewise_cot_values},
        synergy_values={(pid,i):v for (pid,i),v in sc.synergy_values.items() if pid in ids},
    ) for sc in source]

def eval_ids(portfolio, projects, scenarios, ids, seq_ids, n=None):
    pmap={p.project_id:p for p in projects}; ids=list(dict.fromkeys([i for i in ids if i in pmap])); selected=[pmap[i] for i in ids]
    seq=make_seq(pmap,ids,seq_ids); st=eng.stage_sequence(seq,portfolio)
    if not st.feasible:
        return {'selected_ids':ids,'sequence_ids':[p.project_id for p in seq],'selected_count':len(ids),'stage_feasible':False,'stage_failure_reason':getattr(st,'reason',None),'budget_feasibility_rate':0.0,'constraint_feasibility_rate':0.0,'admissible':False,'p85_profit':None,'profits_n':0}
    br,cr,adm,p85,profits=eng.evaluate_stochastic_from_scenarios(portfolio,selected,seq,subset_scenarios(scenarios,ids,n),optimistic_prefilter=False)
    return {'selected_ids':ids,'sequence_ids':[p.project_id for p in seq],'selected_count':len(ids),'stage_feasible':True,'stage_failure_reason':None,'budget_feasibility_rate':br,'constraint_feasibility_rate':cr,'admissible':bool(adm),'p85_profit':p85,'profits_n':len(profits)}

def priority_orders(projects, ids_new):
    pmap={p.project_id:p for p in projects}; allp=[pmap[i] for i in ids_new if i in pmap]
    return [
        ('time_pressure', [p.project_id for p in sorted(allp,key=lambda p:(-time_pressure(p),-p.deterministic_base_profit(),p.project_id))]),
        ('low_constraint', [p.project_id for p in sorted(allp,key=lambda p:(constraint_total(p),-p.deterministic_base_profit(),p.project_id))]),
        ('high_profit', [p.project_id for p in sorted(allp,key=lambda p:(-p.deterministic_base_profit(),constraint_total(p),p.project_id))]),
        ('low_budget', [p.project_id for p in sorted(allp,key=lambda p:(budget_total(p),-p.deterministic_base_profit(),p.project_id))]),
    ]

def insertion_sequence_orders(projects,current_seq,bundle,ids_new):
    pmap={p.project_id:p for p in projects}
    bundle=[x for x in bundle if x in pmap]
    base=[x for x in current_seq if x not in bundle and x in pmap]
    orders=[]; seen=set()
    def add(label,order):
        sid=[p.project_id for p in make_seq(pmap,ids_new,order)]; key=tuple(sid)
        if key not in seen:
            seen.add(key); orders.append((label,sid))
    # Exhaust all insertion positions of the bundle in the current sequence (dependency-aware order deduped afterwards).
    for pos in range(len(base)+1):
        add(f'insert_pos_{pos:02d}', base[:pos]+bundle+base[pos:])
    for label,order in priority_orders(projects,ids_new): add(label,order)
    return orders

def cap_budget(portfolio,t0): return float(portfolio.budget_restriction_profile[t0]) if t0<len(portfolio.budget_restriction_profile) else 0.0
def cap_constraint(portfolio,t0): return float(portfolio.constraint_capacity_profile[t0]) if t0<len(portfolio.constraint_capacity_profile) else float(portfolio.constraint_capacity_profile[-1])
def project_profiles_det(p):
    d=p.deterministic_duration(); return d,[det(x) for x in eng._derive_budget_profile(p,d)],[det(x) for x in eng._normalize_profile(p.constraint_usage_profile,d)]
def project_budget_det(p): return sum(project_profiles_det(p)[1])

def stage_for(seed,md):
    portfolio,projects,pmap=pmap_world(seed); seq=make_seq(pmap,md.get('selected_ids',[]),md.get('sequence_ids',[])); st=eng.stage_sequence(seq,portfolio); return portfolio,projects,pmap,seq,st

def usage_rows(seed,method,md):
    portfolio,projects,pmap,seq,st=stage_for(seed,md); rows=[]
    if not st.feasible or not st.records: return rows
    end=max(r.completion_period_1 for r in st.records)
    for t0 in range(end):
        active=[]; bu=0.0; cu=0.0
        for rec in st.records:
            if rec.start_period_0<=t0<rec.completion_period_1:
                pid=rec.project_id; off=t0-rec.start_period_0; active.append(pid); d,b,c=project_profiles_det(pmap[pid]); bu+=b[off] if off<len(b) else 0.0; cu+=c[off] if off<len(c) else 0.0
        bcap=cap_budget(portfolio,t0); ccap=cap_constraint(portfolio,t0)
        rows.append({'seed':seed,'method':method,'period':t0+1,'active_count':len(active),'active_ids':';'.join(active),'budget_used':bu,'budget_cap':bcap,'budget_util_pct':bu/bcap*100 if bcap>0 else None,'budget_slack':bcap-bu,'budget_ok':bu<=bcap+1e-9,'constraint_used':cu,'constraint_cap':ccap,'constraint_util_pct':cu/ccap*100 if ccap>0 else None,'constraint_slack':ccap-cu,'constraint_ok':cu<=ccap+1e-9})
    return rows

def schedule_rows(seed,method,md):
    portfolio,projects,pmap,seq,st=stage_for(seed,md); rows=[]
    if not st.feasible: return rows
    for rec in st.records: rows.append({'seed':seed,'method':method,'project_id':rec.project_id,'start_period':rec.start_period_0+1,'end_period':rec.completion_period_1,'duration':rec.completion_period_1-rec.start_period_0})
    return rows

def summary_metrics(seed,method,md):
    portfolio,projects,pmap,seq,st=stage_for(seed,md); ids=md.get('selected_ids',[]); u=usage_rows(seed,method,md)
    if st.feasible and st.records:
        start=min(r.start_period_0 for r in st.records)+1; end=max(r.completion_period_1 for r in st.records); dur=end-start+1
    else: start=end=dur=None
    w=[r['active_count'] for r in u]
    return {'seed':seed,'method':method,'admissible':method_valid(md),'stage_feasible':md.get('stage_feasible'),'selected_count':md.get('selected_count'),'p85_profit':md.get('p85_profit'),'budget_feasibility_rate':md.get('budget_feasibility_rate'),'constraint_feasibility_rate':md.get('constraint_feasibility_rate'),'portfolio_start_period':start,'portfolio_end_period':end,'portfolio_duration_periods':dur,'portfolio_budget_det':sum(project_budget_det(pmap[i]) for i in ids if i in pmap),'wip_min':min(w) if w else None,'wip_max':max(w) if w else None,'wip_avg':sum(w)/len(w) if w else None,'max_budget_util_pct':max([r['budget_util_pct'] for r in u],default=None),'max_constraint_util_pct':max([r['constraint_util_pct'] for r in u],default=None),'all_period_budget_ok':all(r['budget_ok'] for r in u) if u else False,'all_period_constraint_ok':all(r['constraint_ok'] for r in u) if u else False,'near_all_selected':md.get('selected_count',0)>=NEAR_ALL_THRESHOLD}

def write_csv(path,rows):
    if not rows: path.write_text('',encoding='utf-8'); return
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields: fields.append(k)
    with open(path,'w',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

def classify_failure(cand,current_p85):
    if not cand.get('stage_feasible'):
        return 'deterministic_stage_infeasible'
    if not cand.get('admissible'):
        br=cand.get('budget_feasibility_rate',0); cr=cand.get('constraint_feasibility_rate',0)
        if br<80 and cr<80: return 'mc_inadmissible_budget_and_constraint'
        if br<80: return 'mc_inadmissible_budget'
        if cr<80: return 'mc_inadmissible_constraint'
        return 'mc_inadmissible_other'
    if cand.get('p85_profit') is None: return 'no_p85'
    if cand['p85_profit'] <= current_p85 + 1e-9: return 'admissible_but_no_p85_improvement'
    return 'admissible_p85_improving'

def broad_expand_method(seed,method_name,start_md,candidate_audit_rows,stop_rows):
    portfolio,projects,pmap=pmap_world(seed); all_ids=[p.project_id for p in projects]
    scenarios=eng.generate_mc_scenarios(portfolio,projects,seed*1000+424242)
    current=eval_ids(portfolio,projects,scenarios,start_md.get('selected_ids',[]),start_md.get('sequence_ids',[]),None)
    hist=[]; initial=current.get('selected_count',0); evals=1
    if not method_valid(current):
        info={'method':method_name,'iterations_accepted':0,'history':hist,'mc1000_evaluations':evals,'stop_reason':'initial_not_admissible_add_only_cannot_validate_more_projects','initial_selected_count':initial,'final_selected_count':current.get('selected_count',0),'universe_project_count':len(all_ids),'near_all_threshold':NEAR_ALL_THRESHOLD,'near_all_selected':current.get('selected_count',0)>=NEAR_ALL_THRESHOLD}
        current['expansion_pass']='broad_universal_single_bundle_add_mc1000'; current['expansion_info']=info
        stop_rows.append({'seed':seed,'method':method_name,'stop_reason':info['stop_reason'],'initial_selected_count':initial,'final_selected_count':current.get('selected_count',0),'accepted_additions':0,'candidate_primary_count':0,'candidate_sequence_count':0,'mc1000_evaluations':evals,'dominant_blocker':'initial configuration not admissible; add-only pass is not the right rescue mechanism'})
        return current
    for it in range(1,MAX_ITERS+1):
        current_ids=set(current['selected_ids']); candidates=[]; tally={}; best_by_reason={}
        primaries=0; seq_count=0
        remaining=sorted([pid for pid in all_ids if pid not in current_ids])
        if not remaining:
            hist.append({'iteration':it,'accepted':False,'reason':'no_remaining_projects','current_p85':current['p85_profit'],'current_selected_count':current['selected_count']}); break
        for pid in remaining:
            bundle=[x for x in dependency_bundle(pid,pmap) if x not in current_ids]
            if not bundle: continue
            ids_new=list(dict.fromkeys(current['selected_ids']+bundle))
            if set(ids_new)==current_ids: continue
            primaries += 1
            if not structural_valid(ids_new,pmap):
                reason='structural_invalid_candidate'
                tally[reason]=tally.get(reason,0)+1
                candidate_audit_rows.append({'seed':seed,'method':method_name,'iteration':it,'primary_project':pid,'add_bundle':';'.join(bundle),'sequence_label':'n/a','selected_count_new':len(ids_new),'reason':reason,'current_p85':current['p85_profit'],'candidate_p85':None,'delta':None,'budget_feasibility_rate':None,'constraint_feasibility_rate':None})
                continue
            for label,seq_ids in insertion_sequence_orders(projects,current['sequence_ids'],bundle,ids_new):
                seq_count += 1
                cand=eval_ids(portfolio,projects,scenarios,ids_new,seq_ids,None); evals += 1
                reason=classify_failure(cand,current['p85_profit']); tally[reason]=tally.get(reason,0)+1
                delta=None if cand.get('p85_profit') is None else cand['p85_profit']-current['p85_profit']
                row={'seed':seed,'method':method_name,'iteration':it,'primary_project':pid,'add_bundle':';'.join(bundle),'sequence_label':label,'selected_count_new':cand.get('selected_count'),'reason':reason,'current_p85':current['p85_profit'],'candidate_p85':cand.get('p85_profit'),'delta':delta,'budget_feasibility_rate':cand.get('budget_feasibility_rate'),'constraint_feasibility_rate':cand.get('constraint_feasibility_rate'),'stage_failure_reason':cand.get('stage_failure_reason')}
                candidate_audit_rows.append(row)
                # record best representative per reason
                score = -1e100 if cand.get('p85_profit') is None else cand.get('p85_profit')
                if reason not in best_by_reason or score > best_by_reason[reason].get('_score',-1e100):
                    best_by_reason[reason]=dict(row, _score=score)
                if reason=='admissible_p85_improving':
                    cand.update({'add_primary':pid,'add_bundle':';'.join(bundle),'sequence_label':label,'delta':delta})
                    candidates.append(cand)
        if candidates:
            best=max(candidates,key=lambda c:(c['p85_profit'], -c['selected_count']))
            hist.append({'iteration':it,'accepted':True,'add_primary':best['add_primary'],'add_bundle':best['add_bundle'],'sequence_label':best['sequence_label'],'old_p85':current['p85_profit'],'new_p85':best['p85_profit'],'delta':best['p85_profit']-current['p85_profit'],'old_selected_count':current['selected_count'],'new_selected_count':best['selected_count'],'candidate_primary_count':primaries,'candidate_sequence_count':seq_count,'failure_tally':tally})
            current=best
            continue
        # No improvement; stop with tallies.
        dom=max(tally.items(), key=lambda kv: kv[1])[0] if tally else 'no_candidates'
        top_examples={k:{kk:vv for kk,vv in v.items() if kk!='_score'} for k,v in best_by_reason.items()}
        hist.append({'iteration':it,'accepted':False,'reason':'no_single_or_dependency_bundle_addition_improved_p85_under_MC1000','current_p85':current['p85_profit'],'current_selected_count':current['selected_count'],'candidate_primary_count':primaries,'candidate_sequence_count':seq_count,'failure_tally':tally,'dominant_blocker':dom,'best_examples_by_reason':top_examples})
        break
    accepted=sum(1 for h in hist if h.get('accepted'))
    last=hist[-1] if hist else {}
    stop=last.get('reason') if last and not last.get('accepted') else ('max_iters_reached' if accepted>=MAX_ITERS else 'completed')
    dom=last.get('dominant_blocker') if last else None
    current['expansion_pass']='broad_universal_single_bundle_add_mc1000'
    current['expansion_info']={'method':method_name,'iterations_accepted':accepted,'history':hist,'mc1000_evaluations':evals,'stop_reason':stop,'dominant_blocker':dom,'initial_selected_count':initial,'final_selected_count':current.get('selected_count',0),'universe_project_count':len(all_ids),'near_all_threshold':NEAR_ALL_THRESHOLD,'near_all_selected':current.get('selected_count',0)>=NEAR_ALL_THRESHOLD,'validation_scope':'iterative add-only; all remaining single projects/dependency bundles; every insertion position plus priority orders; all candidates evaluated with final common MC1000; no trim/replace'}
    stop_rows.append({'seed':seed,'method':method_name,'stop_reason':stop,'dominant_blocker':dom,'initial_selected_count':initial,'final_selected_count':current.get('selected_count',0),'accepted_additions':accepted,'candidate_primary_count':last.get('candidate_primary_count'),'candidate_sequence_count':last.get('candidate_sequence_count'),'mc1000_evaluations':evals,'failure_tally_json':json.dumps(last.get('failure_tally',{}),ensure_ascii=False),'best_examples_by_reason_json':json.dumps(last.get('best_examples_by_reason',{}),ensure_ascii=False)})
    return current

def suspicious_audit(seed_outputs, wm_summary, period_all):
    rows=[]
    # duplicate/near all/aOctane invariant/period violations/duration-vs-selected/wip extreme checks
    for r in seed_outputs:
        seed=r['seed']; methods=r['final_mc1000_methods']
        if method_valid(methods['Octane']) and method_valid(methods['aOctane']) and methods['aOctane']['p85_profit']+1e-9<methods['Octane']['p85_profit']:
            rows.append({'seed':seed,'method':'aOctane','signal':'aOctane_below_Octane','severity':'critical','detail':f"aOctane {methods['aOctane']['p85_profit']} < Octane {methods['Octane']['p85_profit']}"})
        for m,md in methods.items():
            ids=md.get('selected_ids',[]); seq=md.get('sequence_ids',[])
            if len(ids)!=len(set(ids)): rows.append({'seed':seed,'method':m,'signal':'duplicate_selected_ids','severity':'critical','detail':'selected_ids contains duplicates'})
            if len(seq)!=len(set(seq)): rows.append({'seed':seed,'method':m,'signal':'duplicate_sequence_ids','severity':'critical','detail':'sequence_ids contains duplicates'})
            if set(ids)!=set(seq): rows.append({'seed':seed,'method':m,'signal':'sequence_selected_mismatch','severity':'critical','detail':f'selected/sequence sets differ: {set(ids)^set(seq)}'})
            if md.get('selected_count',0)>=NEAR_ALL_THRESHOLD:
                rows.append({'seed':seed,'method':m,'signal':'near_all_selected','severity':'warning','detail':f"{md.get('selected_count')} of 38 selected"})
    for x in wm_summary:
        seed=x['seed']; m=x['method']
        if not x.get('all_period_budget_ok'): rows.append({'seed':seed,'method':m,'signal':'deterministic_budget_period_violation','severity':'critical','detail':'period budget violation in deterministic schedule'})
        if not x.get('all_period_constraint_ok'): rows.append({'seed':seed,'method':m,'signal':'deterministic_constraint_period_violation','severity':'critical','detail':'period constraint violation in deterministic schedule'})
        sc=x.get('selected_count') or 0; dur=x.get('portfolio_duration_periods') or 0; avg=x.get('wip_avg') or 0; mx=x.get('wip_max') or 0
        if method_valid({'admissible':x.get('admissible'),'stage_feasible':x.get('stage_feasible'),'selected_count':sc}) and dur and sc>=20 and dur<=10:
            rows.append({'seed':seed,'method':m,'signal':'short_duration_many_projects','severity':'warning','detail':f'{sc} projects in {dur} periods; avg WIP {avg:.2f}; max WIP {mx}'})
        if mx>=18:
            rows.append({'seed':seed,'method':m,'signal':'very_high_period_WIP','severity':'warning','detail':f'max WIP {mx}'})
        if x.get('max_budget_util_pct') is not None and x['max_budget_util_pct']<25 and x.get('max_constraint_util_pct') and x['max_constraint_util_pct']>95:
            rows.append({'seed':seed,'method':m,'signal':'budget_slack_constraint_binding','severity':'info','detail':f"max budget util {x['max_budget_util_pct']:.1f}%, max constraint util {x['max_constraint_util_pct']:.1f}%"})
    if not rows:
        rows.append({'seed':None,'method':None,'signal':'no_suspicious_signal_detected','severity':'ok','detail':'No critical or warning signals under configured checks.'})
    return rows

seed_outputs=[]; selected_rows=[]; sequence_rows=[]; schedule_all=[]; period_all=[]; wm_summary=[]; candidate_rows=[]; stop_rows=[]
for seed in SEEDS:
    print('seed',seed,flush=True)
    data=json.load(open(SRC/f'seed{seed:03d}.json',encoding='utf-8'))
    methods={m:dict(data['final_mc1000_methods'][m]) for m in METHODS}
    exp={}
    for m in METHODS:
        exp[m]=broad_expand_method(seed,m,methods[m],candidate_rows,stop_rows); info=exp[m]['expansion_info']
        print(' ',m,'init',info['initial_selected_count'],'adds',info['iterations_accepted'],'final',info['final_selected_count'],'valid',method_valid(exp[m]),'p85',exp[m].get('p85_profit'),'stop',info['stop_reason'],flush=True)
    if method_valid(exp['Octane']):
        ao=exp['aOctane']; oc=exp['Octane']
        if (not method_valid(ao)) or (ao.get('p85_profit') is None) or (ao['p85_profit']+1e-9<oc['p85_profit']):
            fb=dict(oc); fb['eval_guard_fallback_to_expanded_octane']=True; fb['expansion_info']=dict(fb.get('expansion_info',{})); fb['expansion_info']['guard_note']='aOctane replaced by expanded Octane after V11 broad universal pass.'; exp['aOctane']=fb
    if 'eval_guard_fallback_to_expanded_octane' not in exp['aOctane']: exp['aOctane']['eval_guard_fallback_to_expanded_octane']=False
    admiss3=[(m,exp[m]['p85_profit']) for m in RANKING if method_valid(exp[m])]; best3=max(admiss3,key=lambda x:x[1]) if admiss3 else (None,None)
    admiss4=[(m,exp[m]['p85_profit']) for m in METHODS if method_valid(exp[m])]; best4=max(admiss4,key=lambda x:x[1]) if admiss4 else (None,None)
    delta=exp['sCPA_lite']['p85_profit']-best3[1] if best3[1] is not None and method_valid(exp['sCPA_lite']) else None
    waste={}
    for m,md in exp.items():
        if method_valid(md) and best4[1] is not None:
            aw=best4[1]-md['p85_profit']; waste[m]={'absolute_waste':aw,'pct_waste':aw/best4[1]*100 if best4[1]>DENOM_EPS else None}
        else: waste[m]=None
    out={'test_id':TEST_ID,'seed':seed,'base_v10_seed_file':str(SRC/f'seed{seed:03d}.json'),'technical_template_id':'AOSWAP_STRONG_s1p18_bc0p20','dependency_rules':data['dependency_rules'],'synergy_rules':data['synergy_rules'],'expansion_note':'V11 starts from V10 and applies a broader iterative add-only validation to every method. Every remaining single project/dependency bundle is tried at every insertion position plus priority orders; all candidates are evaluated with common MC1000. No trim/replace.','final_mc1000_methods':exp,'best3_method':best3[0],'best3_p85':best3[1],'best4_method':best4[0],'best4_p85':best4[1],'scpa_delta_vs_best3':delta,'scpa_uplift_pct_vs_best3_positive_denominator_only':pct(delta,best3[1]),'scpa_beats_best3_abs':bool(delta is not None and delta>0),'waste_vs_best4':waste}
    (OUT/f'seed{seed:03d}.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8'); seed_outputs.append(out)
    for m,md in exp.items():
        for i,pid in enumerate(md.get('selected_ids',[]),1): selected_rows.append({'seed':seed,'method':m,'selected_rank':i,'project_id':pid})
        for i,pid in enumerate(md.get('sequence_ids',[]),1): sequence_rows.append({'seed':seed,'method':m,'sequence_rank':i,'project_id':pid})
        schedule_all.extend(schedule_rows(seed,m,md)); period_all.extend(usage_rows(seed,m,md)); wm_summary.append(summary_metrics(seed,m,md))
    print(' -> best3',best3,'delta',delta,'strict',all(method_valid(exp[m]) for m in METHODS),flush=True)

per_seed=[]
for r in seed_outputs:
    row={'seed':r['seed'],'best3_method':r['best3_method'],'best3_p85':r['best3_p85'],'best4_method':r['best4_method'],'best4_p85':r['best4_p85'],'scpa_delta_vs_best3':r['scpa_delta_vs_best3'],'scpa_uplift_pct_pos_den_only':r['scpa_uplift_pct_vs_best3_positive_denominator_only'],'scpa_beats_best3_abs':r['scpa_beats_best3_abs']}
    for m in METHODS:
        md=r['final_mc1000_methods'][m]; info=md.get('expansion_info',{})
        row[f'{m}_admissible']=method_valid(md); row[f'{m}_p85']=md.get('p85_profit'); row[f'{m}_selected_count']=md.get('selected_count'); row[f'{m}_budget_feas']=md.get('budget_feasibility_rate'); row[f'{m}_constraint_feas']=md.get('constraint_feasibility_rate'); row[f'{m}_adds']=info.get('iterations_accepted'); row[f'{m}_initial_selected_count']=info.get('initial_selected_count'); row[f'{m}_final_selected_count']=info.get('final_selected_count'); row[f'{m}_near_all_selected']=md.get('selected_count',0)>=NEAR_ALL_THRESHOLD; row[f'{m}_expansion_stop_reason']=info.get('stop_reason'); row[f'{m}_dominant_blocker']=info.get('dominant_blocker'); row[f'{m}_expansion_history']=json.dumps(info.get('history',[]),ensure_ascii=False)
        w=r['waste_vs_best4'][m]; row[f'{m}_abs_waste']=None if w is None else w['absolute_waste']; row[f'{m}_pct_waste']=None if w is None else w['pct_waste']
    per_seed.append(row)
write_csv(OUT/'per_seed_summary.csv',per_seed); write_csv(OUT/'selected_projects_by_world_method.csv',selected_rows); write_csv(OUT/'sequence_by_world_method.csv',sequence_rows); write_csv(OUT/'project_schedule_by_world_method_det.csv',schedule_all); write_csv(OUT/'period_budget_constraint_wip_by_world_method_det.csv',period_all); write_csv(OUT/'world_method_summary_schedule_budget_wip.csv',wm_summary); write_csv(OUT/'residual_add_candidate_audit_mc1000.csv',candidate_rows); write_csv(OUT/'stop_reason_by_world_method.csv',stop_rows)
medrows=[]
for m in METHODS:
    rows=[x for x in wm_summary if x['method']==m and x['admissible']]
    def med(k):
        xs=[x[k] for x in rows if x[k] is not None]; return statistics.median(xs) if xs else None
    medrows.append({'method':m,'admissible_worlds':len(rows),'median_selected_count':med('selected_count'),'median_p85_profit':med('p85_profit'),'median_portfolio_start':med('portfolio_start_period'),'median_portfolio_end':med('portfolio_end_period'),'median_portfolio_duration':med('portfolio_duration_periods'),'median_portfolio_budget_det':med('portfolio_budget_det'),'median_wip_min':med('wip_min'),'median_wip_max':med('wip_max'),'median_wip_avg':med('wip_avg'),'median_max_budget_util_pct':med('max_budget_util_pct'),'median_max_constraint_util_pct':med('max_constraint_util_pct'),'near_all_selected_worlds':sum(1 for x in rows if x.get('near_all_selected'))})
write_csv(OUT/'method_level_medians_schedule_budget_wip.csv',medrows)

usable=[r['seed'] for r in seed_outputs if r['best3_method']]; strict=[r['seed'] for r in seed_outputs if all(method_valid(r['final_mc1000_methods'][m]) for m in METHODS)]
deltas=[r['scpa_delta_vs_best3'] for r in seed_outputs if r['scpa_delta_vs_best3'] is not None]; uplifts=[r['scpa_uplift_pct_vs_best3_positive_denominator_only'] for r in seed_outputs if r['scpa_uplift_pct_vs_best3_positive_denominator_only'] is not None]
method_counts={m:sum(method_valid(r['final_mc1000_methods'][m]) for r in seed_outputs) for m in METHODS}
waste_best=[r['waste_vs_best4'][r['best3_method']]['pct_waste'] for r in seed_outputs if r['best3_method'] and r['best4_method']=='sCPA_lite' and r['waste_vs_best4'][r['best3_method']] is not None]
waste_abs=[r['waste_vs_best4'][r['best3_method']]['absolute_waste'] for r in seed_outputs if r['best3_method'] and r['best4_method']=='sCPA_lite' and r['waste_vs_best4'][r['best3_method']] is not None]
add_counts={m:[r['final_mc1000_methods'][m].get('expansion_info',{}).get('iterations_accepted',0) for r in seed_outputs] for m in METHODS}
near_all={m:sum(r['final_mc1000_methods'][m].get('selected_count',0)>=NEAR_ALL_THRESHOLD and method_valid(r['final_mc1000_methods'][m]) for r in seed_outputs) for m in METHODS}
summary={'test_id':TEST_ID,'status':'Broad residual universal add validation applied symmetrically to all methods starting from V10. All remaining single project/dependency-bundle additions are tried across every insertion position plus priority orders; every candidate is evaluated with common MC1000. Add-only; no trim/replace.','world_count':10,'project_universe_count':38,'near_all_threshold':NEAR_ALL_THRESHOLD,'method_admissible_counts':method_counts,'usable_ranking_comparison_worlds':len(usable),'usable_ranking_comparison_seeds':usable,'strict_4way_worlds':len(strict),'strict_4way_seeds':strict,'scpa_beats_best3_abs_worlds':sum(r['scpa_beats_best3_abs'] for r in seed_outputs),'scpa_best4_worlds':sum(r['best4_method']=='sCPA_lite' for r in seed_outputs),'median_scpa_p85':statistics.median([r['final_mc1000_methods']['sCPA_lite']['p85_profit'] for r in seed_outputs]),'median_delta_vs_best3':statistics.median(deltas) if deltas else None,'mean_delta_vs_best3':statistics.mean(deltas) if deltas else None,'min_delta_vs_best3':min(deltas) if deltas else None,'max_delta_vs_best3':max(deltas) if deltas else None,'median_uplift_pct_positive_best3_only':statistics.median(uplifts) if uplifts else None,'positive_denominator_worlds_for_pct':len(uplifts),'median_abs_waste_best_ranking_vs_scpa':statistics.median(waste_abs) if waste_abs else None,'median_pct_waste_best_ranking_vs_scpa':statistics.median(waste_best) if waste_best else None,'method_level_medians':medrows,'method_add_counts':add_counts,'near_all_selected_worlds_by_method':near_all,'aoctane_guard_fallback_count':sum(bool(r['final_mc1000_methods']['aOctane'].get('eval_guard_fallback_to_expanded_octane')) for r in seed_outputs),'aoctane_invariant_violations_after_guard':[r['seed'] for r in seed_outputs if method_valid(r['final_mc1000_methods']['Octane']) and method_valid(r['final_mc1000_methods']['aOctane']) and r['final_mc1000_methods']['aOctane']['p85_profit']+1e-9<r['final_mc1000_methods']['Octane']['p85_profit']]}
# Candidate blocker aggregation
blocker_counts={}
for r in stop_rows:
    key=(r.get('method'),r.get('dominant_blocker') or r.get('stop_reason'))
    blocker_counts[key]=blocker_counts.get(key,0)+1
summary['dominant_blocker_counts_by_method']=[{'method':k[0],'blocker':k[1],'count':v} for k,v in sorted(blocker_counts.items())]

sus=suspicious_audit(seed_outputs,wm_summary,period_all); write_csv(OUT/'suspicious_signal_audit.csv',sus)
summary['critical_suspicious_signals']=sum(1 for r in sus if r.get('severity')=='critical')
summary['warning_suspicious_signals']=sum(1 for r in sus if r.get('severity')=='warning')
(OUT/'summary.json').write_text(json.dumps({'summary':summary,'per_seed':per_seed,'method_level_medians':medrows,'stop_reasons':stop_rows},indent=2,ensure_ascii=False),encoding='utf-8')

report=[TEST_ID,'','V11 broad validation from V10. All methods receive the same iterative residual add-only pass. Every remaining single project/dependency bundle is evaluated across every insertion position plus priority orders, using common MC1000. No trim/replace.','',f'Universe: 38 projects; near-all threshold: >= {NEAR_ALL_THRESHOLD}',f'Method admissible counts: {method_counts}',f'Usable ranking comparison: {len(usable)}/10 seeds {usable}',f'Strict 4-way: {len(strict)}/10 seeds {strict}',f'sCPA beats best ranking: {summary["scpa_beats_best3_abs_worlds"]}/{len(usable)}',f'sCPA best overall: {summary["scpa_best4_worlds"]}/10',f'Median sCPA P85: {summary["median_scpa_p85"]:.6f}',f'Median delta vs best ranking: {summary["median_delta_vs_best3"]:.6f}' if summary['median_delta_vs_best3'] is not None else 'Median delta vs best ranking: n/a','', 'Medians by method:']
for r in medrows: report.append(f"- {r['method']}: admissible {r['admissible_worlds']}/10; selected {r['median_selected_count']}; P85 {r['median_p85_profit']}; duration {r['median_portfolio_duration']}; budget {r['median_portfolio_budget_det']}; avg WIP {r['median_wip_avg']}; max constraint util {r['median_max_constraint_util_pct']}; near-all worlds {r['near_all_selected_worlds']}")
report += ['', 'Stop reason files:', '- stop_reason_by_world_method.csv', '- residual_add_candidate_audit_mc1000.csv', '', 'Suspicious-signal audit:', f"critical={summary['critical_suspicious_signals']}; warning={summary['warning_suspicious_signals']}", 'See suspicious_signal_audit.csv.']
(OUT/'REPORT_BG.txt').write_text('\n'.join(report),encoding='utf-8')
if ZIP.exists(): ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
    z.write('/mnt/data/run_v11_broad_universal_add_validation.py',arcname='run_v11_broad_universal_add_validation.py')
    z.write('/mnt/data/run_custom_v8.py',arcname='run_custom_v8.py'); z.write('/mnt/data/run_v7_variant.py',arcname='run_v7_variant.py'); z.write('/mnt/data/pol_scpa_lite_runner.py',arcname='pol_scpa_lite_runner.py')
    for p in OUT.rglob('*'): z.write(p,arcname=str(p.relative_to(OUT.parent)))
print(json.dumps(summary,indent=2,ensure_ascii=False)); print('ZIP',ZIP)
