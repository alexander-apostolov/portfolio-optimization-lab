from __future__ import annotations
import json,csv,statistics,shutil,zipfile,importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('v8','/mnt/data/run_custom_v8.py')
v8=importlib.util.module_from_spec(spec); spec.loader.exec_module(v8)
eng=v8.v7.eng
SRC=Path('/mnt/data/R7_STRUCTURAL_SOFT_V14C_DETERMINISTIC_BUDGET_TRIM_CAP1p9_MC1000_v1')
TEST_ID='R7_STRUCTURAL_SOFT_V15D_OCTANE_EXPANDED_THEN_STANDARD_AOCTANE_DETLOCAL_MC1000_v1'
OUT=Path('/mnt/data')/TEST_ID; ZIP=Path(str(OUT)+'.zip')
SEEDS=range(1,11); METHODS=['MSA','Octane','aOctane','sCPA_lite']; RANKING=['MSA','Octane','aOctane']; MC=1000; BUD_MULT=20.0; CAP_MULT=1.9; EPS=1e-9; NEAR_ALL=34
if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir()

def write_csv(path,rows):
    if not rows: Path(path).write_text('',encoding='utf-8'); return
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields: fields.append(k)
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

def det(x): return float(x.deterministic() if hasattr(x,'deterministic') else x)
def scale(x,m):
    if hasattr(x,'optimistic') and hasattr(x,'most_likely') and hasattr(x,'pessimistic'):
        return eng.ThreePoint(x.optimistic*m,x.most_likely*m,x.pessimistic*m)
    return x*m

def world(seed):
    p,ps=v8.world(seed,MC); p.monte_carlo_iterations=MC; p.budget_restriction_profile=[float(x)*CAP_MULT for x in p.budget_restriction_profile]
    for pr in ps:
        pr.budget_usage_profile=[scale(x,BUD_MULT) for x in pr.budget_usage_profile]
        if getattr(pr,'total_project_budget',None) is not None: pr.total_project_budget=scale(pr.total_project_budget,BUD_MULT)
    return p,ps,{x.project_id:x for x in ps}

def profiles(p):
    d=p.deterministic_duration(); return d,[det(x) for x in eng._derive_budget_profile(p,d)],[det(x) for x in eng._normalize_profile(p.constraint_usage_profile,d)]
def pb(p): return sum(profiles(p)[1])
def pc(p): return sum(profiles(p)[2])

def structural_prune(ids,pmap):
    ids=[i for i in ids if i in pmap]; s=set(ids); changed=True
    while changed:
        changed=False
        for pid in list(s):
            if not set(pmap[pid].structural_dependencies).issubset(s): s.remove(pid); changed=True
    return [i for i in ids if i in s]

def make_seq(pmap,ids,order):
    ids=structural_prune(list(dict.fromkeys(ids)),pmap); s=set(ids)
    seq=[pmap[i] for i in order if i in pmap and i in s]
    seen={p.project_id for p in seq}; seq += [pmap[i] for i in ids if i not in seen]
    return eng._dependency_aware_stable_order(seq)

def subset_scenarios(scs,ids):
    ids=set(ids)
    return [eng.MonteCarloScenario(project_vectors={pid:sc.project_vectors[pid] for pid in ids if pid in sc.project_vectors},linear_cot_deltas={pid:sc.linear_cot_deltas[pid] for pid in ids if pid in sc.linear_cot_deltas},piecewise_cot_values={pid:sc.piecewise_cot_values[pid] for pid in ids if pid in sc.piecewise_cot_values},synergy_values={(pid,i):v for (pid,i),v in sc.synergy_values.items() if pid in ids}) for sc in scs]

def eval_final(p,ps,scs,ids,seq_ids):
    pmap={x.project_id:x for x in ps}; ids=structural_prune(ids,pmap); seq=make_seq(pmap,ids,seq_ids); st=eng.stage_sequence(seq,p)
    if not st.feasible: return {'selected_ids':ids,'sequence_ids':[x.project_id for x in seq],'selected_count':len(ids),'stage_feasible':False,'budget_feasibility_rate':0,'constraint_feasibility_rate':0,'admissible':False,'p85_profit':None}
    br,cr,adm,p85,_=eng.evaluate_stochastic_from_scenarios(p,[pmap[i] for i in ids],seq,subset_scenarios(scs,ids),optimistic_prefilter=False)
    return {'selected_ids':ids,'sequence_ids':[x.project_id for x in seq],'selected_count':len(ids),'stage_feasible':True,'budget_feasibility_rate':br,'constraint_feasibility_rate':cr,'admissible':bool(adm),'p85_profit':p85}
def valid(md): return bool(md.get('stage_feasible') and md.get('admissible') and md.get('p85_profit') is not None)

def apply_ao(seed,oct_md):
    p,ps,pmap=world(seed); scs=eng.generate_mc_scenarios(p,ps,seed*1000+424242)
    ids=structural_prune(oct_md.get('selected_ids',[]),pmap); base_seq=make_seq(pmap,ids,oct_md.get('sequence_ids',[])); selected=[pmap[i] for i in ids]
    base=eval_final(p,ps,scs,ids,[x.project_id for x in base_seq])
    try:
        seq2,st2,obj=eng.improve_aoctane_sequence(selected,base_seq,p,None)
        trial=eval_final(p,ps,scs,ids,[x.project_id for x in seq2])
    except Exception as e:
        trial=dict(base); trial['aOctane_error']=str(e)
    fallback=False; reason='accepted_standard_det_local_swap'
    if valid(base) and ((not valid(trial)) or trial.get('p85_profit') is None or trial['p85_profit'] < base['p85_profit']-EPS):
        trial=dict(base); fallback=True; reason='guard_fallback_to_expanded_octane_after_mc1000'
    elif (not valid(base)) and valid(trial): reason='standard_det_local_swap_rescued_inadmissible_expanded_octane'
    elif (not valid(base)) and (not valid(trial)): reason='expanded_octane_inadmissible_and_det_local_swap_did_not_rescue'
    trial.update({'aOctane_v15_pipeline':'expanded_octane_then_standard_deterministic_adjacent_local_swap_with_mc1000_guard','guard_fallback_to_expanded_octane':fallback,'aOctane_reason':reason,'base_expanded_octane_admissible':valid(base),'base_expanded_octane_p85':base.get('p85_profit'),'base_expanded_octane_selected_count':base.get('selected_count'),'same_selected_set_as_expanded_octane':set(trial.get('selected_ids',[]))==set(base.get('selected_ids',[])),'same_sequence_as_expanded_octane':trial.get('sequence_ids',[])==base.get('sequence_ids',[]),'sequence_changed_vs_expanded_octane':trial.get('sequence_ids',[])!=base.get('sequence_ids',[]),'delta_vs_expanded_octane_p85':(trial.get('p85_profit')-base.get('p85_profit')) if trial.get('p85_profit') is not None and base.get('p85_profit') is not None else None})
    return trial,base,p,ps

def usage(seed,method,p,ps,md):
    pmap={x.project_id:x for x in ps}; seq=make_seq(pmap,md.get('selected_ids',[]),md.get('sequence_ids',[])); st=eng.stage_sequence(seq,p); rows=[]
    if not st.feasible or not st.records: return rows
    end=max(r.completion_period_1 for r in st.records)
    for t0 in range(end):
        bu=cu=0; active=[]
        for rec in st.records:
            if rec.start_period_0<=t0<rec.completion_period_1:
                active.append(rec.project_id); d,b,c=profiles(pmap[rec.project_id]); off=t0-rec.start_period_0; bu+=b[off] if off<len(b) else 0; cu+=c[off] if off<len(c) else 0
        bcap=p.budget_restriction_profile[t0] if t0<len(p.budget_restriction_profile) else 0; ccap=p.constraint_capacity_profile[t0] if t0<len(p.constraint_capacity_profile) else p.constraint_capacity_profile[-1]
        rows.append({'seed':seed,'method':method,'period':t0+1,'active_count':len(active),'active_ids':';'.join(active),'budget_used':bu,'budget_cap':bcap,'budget_util_pct':bu/bcap*100 if bcap else None,'budget_ok':bu<=bcap+1e-9,'constraint_used':cu,'constraint_cap':ccap,'constraint_util_pct':cu/ccap*100 if ccap else None,'constraint_ok':cu<=ccap+1e-9})
    return rows

def metrics(seed,method,p,ps,md):
    pmap={x.project_id:x for x in ps}; u=usage(seed,method,p,ps,md); st=eng.stage_sequence(make_seq(pmap,md.get('selected_ids',[]),md.get('sequence_ids',[])),p)
    if st.feasible and st.records:
        start=min(r.start_period_0 for r in st.records)+1; end=max(r.completion_period_1 for r in st.records); dur=end-start+1
    else: start=end=dur=None
    ids=md.get('selected_ids',[]); bud=sum(pb(pmap[i]) for i in ids if i in pmap); con=sum(pc(pmap[i]) for i in ids if i in pmap); p85=md.get('p85_profit'); w=[r['active_count'] for r in u]
    horizon=sum(p.budget_restriction_profile[:22]); active=sum(p.budget_restriction_profile[:end]) if end else None
    return {'seed':seed,'method':method,'admissible':valid(md),'stage_feasible':md.get('stage_feasible'),'selected_count':md.get('selected_count'),'p85_profit':p85,'budget_feasibility_rate':md.get('budget_feasibility_rate'),'constraint_feasibility_rate':md.get('constraint_feasibility_rate'),'portfolio_start_period':start,'portfolio_end_period':end,'portfolio_duration_periods':dur,'portfolio_budget_det':bud,'roi_pct_used_budget':p85/bud*100 if p85 is not None and bud>0 else None,'active_budget_envelope':active,'roi_pct_active_budget_envelope':p85/active*100 if p85 is not None and active else None,'full_22p_budget_envelope':horizon,'roi_pct_full_22p_budget_envelope':p85/horizon*100 if p85 is not None and horizon else None,'total_constraint_det':con,'p85_per_constraint_unit':p85/con if p85 is not None and con>0 else None,'wip_min':min(w) if w else None,'wip_max':max(w) if w else None,'wip_avg':sum(w)/len(w) if w else None,'avg_budget_util_pct':sum([r['budget_util_pct'] for r in u])/len(u) if u else None,'max_budget_util_pct':max([r['budget_util_pct'] for r in u],default=None),'avg_constraint_util_pct':sum([r['constraint_util_pct'] for r in u])/len(u) if u else None,'max_constraint_util_pct':max([r['constraint_util_pct'] for r in u],default=None),'all_period_budget_ok':all(r['budget_ok'] for r in u) if u else False,'all_period_constraint_ok':all(r['constraint_ok'] for r in u) if u else False,'near_all_selected':md.get('selected_count',0)>=NEAR_ALL}

outputs=[]; per=[]; wm=[]; period=[]; ao_rows=[]; selrows=[]; seqrows=[]
for seed in SEEDS:
    print('seed',seed,flush=True)
    p,ps,pmap=world(seed); scs=eng.generate_mc_scenarios(p,ps,seed*1000+424242); src=json.load(open(SRC/f'seed{seed:03d}.json',encoding='utf-8'))
    methods={}
    for m in ['MSA','Octane','sCPA_lite']:
        md=src['final_mc1000_methods'][m]; methods[m]=eval_final(p,ps,scs,md.get('selected_ids',[]),md.get('sequence_ids',[]))
    ao,base_oct,_,_=apply_ao(seed,methods['Octane']); methods['aOctane']=ao
    adm3=[(m,methods[m]['p85_profit']) for m in RANKING if valid(methods[m])]; best3=max(adm3,key=lambda x:x[1]) if adm3 else (None,None)
    adm4=[(m,methods[m]['p85_profit']) for m in METHODS if valid(methods[m])]; best4=max(adm4,key=lambda x:x[1]) if adm4 else (None,None)
    delta=methods['sCPA_lite']['p85_profit']-best3[1] if valid(methods['sCPA_lite']) and best3[1] is not None else None
    out={'test_id':TEST_ID,'seed':seed,'budget_calibration':{'project_budget_multiplier':BUD_MULT,'period_budget_cap_multiplier':CAP_MULT},'pipeline':'V14C expanded/trimmed Octane first; then standard deterministic adjacent local-swap aOctane on same selected set; final common MC1000; guard fallback to expanded Octane.','final_mc1000_methods':methods,'best3_method':best3[0],'best3_p85':best3[1],'best4_method':best4[0],'best4_p85':best4[1],'scpa_delta_vs_best3':delta,'scpa_uplift_pct_vs_best3_positive_denominator_only':delta/best3[1]*100 if delta is not None and best3[1] and best3[1]>EPS else None,'scpa_beats_best3_abs':bool(delta is not None and delta>0)}
    (OUT/f'seed{seed:03d}.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8'); outputs.append(out)
    row={'seed':seed,'best3_method':best3[0],'best3_p85':best3[1],'best4_method':best4[0],'best4_p85':best4[1],'scpa_delta_vs_best3':delta,'scpa_beats_best3_abs':out['scpa_beats_best3_abs']}
    for m,md in methods.items():
        sm=metrics(seed,m,p,ps,md); wm.append(sm); period.extend(usage(seed,m,p,ps,md)); row[f'{m}_admissible']=valid(md); row[f'{m}_p85']=md.get('p85_profit'); row[f'{m}_selected_count']=md.get('selected_count'); row[f'{m}_avg_budget_util_pct']=sm.get('avg_budget_util_pct'); row[f'{m}_roi_pct_used_budget']=sm.get('roi_pct_used_budget')
        for idx,pid in enumerate(md.get('selected_ids',[]),1): selrows.append({'seed':seed,'method':m,'rank':idx,'project_id':pid})
        for idx,pid in enumerate(md.get('sequence_ids',[]),1): seqrows.append({'seed':seed,'method':m,'sequence_pos':idx,'project_id':pid})
    ao_rows.append({'seed':seed,'octane_admissible':valid(methods['Octane']),'aoctane_admissible':valid(ao),'same_selected_set':ao.get('same_selected_set_as_expanded_octane'),'same_sequence':ao.get('same_sequence_as_expanded_octane'),'sequence_changed':ao.get('sequence_changed_vs_expanded_octane'),'guard_fallback_to_expanded_octane':ao.get('guard_fallback_to_expanded_octane'),'aoctane_reason':ao.get('aOctane_reason'),'octane_p85':methods['Octane'].get('p85_profit'),'aoctane_p85':ao.get('p85_profit'),'delta_vs_expanded_octane_p85':ao.get('delta_vs_expanded_octane_p85'),'octane_selected_count':methods['Octane'].get('selected_count'),'aoctane_selected_count':ao.get('selected_count')})
    per.append(row)
write_csv(OUT/'per_seed_summary.csv',per); write_csv(OUT/'world_method_summary_schedule_budget_wip_roi_utilization.csv',wm); write_csv(OUT/'period_budget_constraint_wip_by_world_method_det.csv',period); write_csv(OUT/'selected_projects_by_world_method.csv',selrows); write_csv(OUT/'sequence_by_world_method.csv',seqrows); write_csv(OUT/'octane_to_standard_aoctane_audit.csv',ao_rows)
medrows=[]
for m in METHODS:
    rows=[x for x in wm if x['method']==m and x['admissible']]
    def med(k):
        vals=[x[k] for x in rows if x.get(k) is not None]; return statistics.median(vals) if vals else None
    medrows.append({'method':m,'admissible_worlds':len(rows),'median_selected_count':med('selected_count'),'median_p85_profit':med('p85_profit'),'median_roi_pct_used_budget':med('roi_pct_used_budget'),'median_roi_pct_active_budget_envelope':med('roi_pct_active_budget_envelope'),'median_roi_pct_full_22p_budget_envelope':med('roi_pct_full_22p_budget_envelope'),'median_duration':med('portfolio_duration_periods'),'median_portfolio_budget_det':med('portfolio_budget_det'),'median_avg_budget_util_pct':med('avg_budget_util_pct'),'median_max_budget_util_pct':med('max_budget_util_pct'),'median_avg_constraint_util_pct':med('avg_constraint_util_pct'),'median_max_constraint_util_pct':med('max_constraint_util_pct'),'median_p85_per_constraint_unit':med('p85_per_constraint_unit'),'median_wip_avg':med('wip_avg'),'median_wip_max':med('wip_max'),'near_all_selected_worlds':sum(1 for x in rows if x.get('near_all_selected'))})
write_csv(OUT/'method_level_medians.csv',medrows)
usable=[r['seed'] for r in outputs if r['best3_method']]; strict=[r['seed'] for r in outputs if all(valid(r['final_mc1000_methods'][m]) for m in METHODS)]
summary={'test_id':TEST_ID,'status':'V15D diagnostic: Octane is first kept as V14C expanded/trimmed Octane; then aOctane is standard deterministic adjacent local-swap/resequence on the same selected set, with final common MC1000 guard. This keeps aOctane as Octane-plus, not sCPA-like broad search.','method_admissible_counts':{m:sum(valid(r['final_mc1000_methods'][m]) for r in outputs) for m in METHODS},'usable_ranking_comparison_worlds':len(usable),'usable_ranking_comparison_seeds':usable,'strict_4way_worlds':len(strict),'strict_4way_seeds':strict,'scpa_beats_best3_abs_worlds':sum(r['scpa_beats_best3_abs'] for r in outputs),'scpa_best4_worlds':sum(r['best4_method']=='sCPA_lite' for r in outputs),'aOctane_diagnostic':{'same_selected_set_worlds':sum(1 for r in ao_rows if r['same_selected_set']),'same_sequence_worlds':sum(1 for r in ao_rows if r['same_sequence']),'positive_p85_improvement_vs_expanded_octane_worlds':sum(1 for r in ao_rows if r['delta_vs_expanded_octane_p85'] is not None and r['delta_vs_expanded_octane_p85']>EPS),'guard_fallback_worlds':sum(1 for r in ao_rows if r['guard_fallback_to_expanded_octane']),'rescue_worlds':sum(1 for r in ao_rows if r['aoctane_reason']=='standard_det_local_swap_rescued_inadmissible_expanded_octane')},'method_level_medians':medrows}
(OUT/'summary.json').write_text(json.dumps({'summary':summary,'per_seed':per,'method_level_medians':medrows,'aOctane_audit':ao_rows},indent=2,ensure_ascii=False),encoding='utf-8')
sus=[]
for x in wm:
    sig=[]
    if x['selected_count'] and x['selected_count']>=NEAR_ALL: sig.append('near_all_selected')
    if x['portfolio_duration_periods'] and x['selected_count'] and x['selected_count']>=24 and x['portfolio_duration_periods']<=8: sig.append('many_projects_short_duration')
    if x['stage_feasible'] and not x['all_period_budget_ok']: sig.append('period_budget_violation')
    if x['stage_feasible'] and not x['all_period_constraint_ok']: sig.append('period_constraint_violation')
    if sig: sus.append({'seed':x['seed'],'method':x['method'],'signals':';'.join(sig),'selected_count':x['selected_count'],'duration':x['portfolio_duration_periods']})
write_csv(OUT/'suspicious_signal_audit.csv',sus)
report=[TEST_ID,'',summary['status'],'',f"Method admissible counts: {summary['method_admissible_counts']}",f"Usable ranking: {len(usable)}/10; strict 4-way: {len(strict)}/10; sCPA beats best ranking: {summary['scpa_beats_best3_abs_worlds']}/{len(usable)}; sCPA best overall: {summary['scpa_best4_worlds']}/10",f"aOctane diagnostic: {summary['aOctane_diagnostic']}",'','Method medians over admissible worlds:']
for r in medrows: report.append(f"- {r['method']}: adm {r['admissible_worlds']}/10; selected {r['median_selected_count']}; P85 {r['median_p85_profit']}; ROI used budget {r['median_roi_pct_used_budget']}%; ROI full 22p {r['median_roi_pct_full_22p_budget_envelope']}%; avg budget util {r['median_avg_budget_util_pct']}%; avg constraint util {r['median_avg_constraint_util_pct']}%; P85/constraint {r['median_p85_per_constraint_unit']}")
report.append('\naOctane seed audit:')
for r in ao_rows: report.append(f"- seed {r['seed']}: Octane adm={r['octane_admissible']} P85={r['octane_p85']}; aOctane adm={r['aoctane_admissible']} P85={r['aoctane_p85']}; delta={r['delta_vs_expanded_octane_p85']}; same_seq={r['same_sequence']}; fallback={r['guard_fallback_to_expanded_octane']}; reason={r['aoctane_reason']}")
(OUT/'REPORT_BG.txt').write_text('\n'.join(report),encoding='utf-8')
if ZIP.exists(): ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
    for fp in OUT.rglob('*'):
        if fp.is_file(): z.write(fp,arcname=fp.relative_to(OUT))
    z.write('/mnt/data/run_v15d_octane_expanded_then_deterministic_standard_aoctane.py',arcname='reproduction_scripts/run_v15d_octane_expanded_then_deterministic_standard_aoctane.py')
print('WROTE',ZIP)
