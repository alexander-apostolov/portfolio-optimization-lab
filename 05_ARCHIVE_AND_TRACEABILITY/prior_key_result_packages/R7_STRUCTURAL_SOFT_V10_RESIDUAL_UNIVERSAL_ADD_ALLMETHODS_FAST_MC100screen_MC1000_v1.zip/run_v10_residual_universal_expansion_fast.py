from __future__ import annotations
import json, csv, statistics, zipfile, shutil, importlib.util
from pathlib import Path

spec=importlib.util.spec_from_file_location('v8','/mnt/data/run_custom_v8.py')
v8=importlib.util.module_from_spec(spec); spec.loader.exec_module(v8)
eng=v8.v7.eng

SEEDS=list(range(1,11)); METHODS=['MSA','Octane','aOctane','sCPA_lite']; RANKING=['MSA','Octane','aOctane']
SRC=Path('/mnt/data/R7_STRUCTURAL_SOFT_V9_3_EONLY_ITERATIVE_ADD_COMBINED_10world_MC1000_v1')
TEST_ID='R7_STRUCTURAL_SOFT_V10_RESIDUAL_UNIVERSAL_ADD_ALLMETHODS_FAST_MC100screen_MC1000_v1'
OUT=Path('/mnt/data')/TEST_ID; ZIP=Path(str(OUT)+'.zip')
FINAL_MC=1000; SCREEN_MC=100; TOP_FINAL=1; MAX_ITERS=6; DENOM_EPS=1e-9; NEAR_ALL_THRESHOLD=34
if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir()

def det(x): return float(x.deterministic() if hasattr(x,'deterministic') else x)
def pmap_world(seed):
    p,ps=v8.world(seed,FINAL_MC); return p,ps,{x.project_id:x for x in ps}
def method_valid(md): return bool(md.get('admissible') and md.get('stage_feasible') and md.get('selected_count',0)>0)
def pct(delta,den): return None if delta is None or den is None or den<=DENOM_EPS else delta/den*100.0
def structural_valid(ids,pmap):
    s=set(ids); return all((pid in pmap) and set(pmap[pid].structural_dependencies).issubset(s) for pid in s)
def dependency_bundle(pid,pmap):
    out=[]; seen=set()
    def visit(x):
        if x in seen or x not in pmap: return
        seen.add(x)
        for pre in pmap[x].structural_dependencies: visit(pre)
        out.append(x)
    visit(pid); return out
def time_pressure(p):
    cot=p.cost_of_time_profile
    if cot.profile_type.value=='Linear': return abs(det(cot.linear_delta_per_period))/max(abs(p.deterministic_base_profit()),1e-9)
    if cot.profile_type.value=='Cliff': return 1.0
    return 0.0
def constraint_total(p):
    d=p.deterministic_duration(); return sum(det(v) for v in eng._normalize_profile(p.constraint_usage_profile,d))
def budget_total(p):
    d=p.deterministic_duration(); return sum(det(v) for v in eng._derive_budget_profile(p,d))
def make_seq(pmap, ids, order):
    ids=list(dict.fromkeys([i for i in ids if i in pmap])); s=set(ids)
    seq=[pmap[i] for i in order if i in pmap and i in s]
    existing={p.project_id for p in seq}
    seq += [pmap[i] for i in ids if i not in existing]
    return eng._dependency_aware_stable_order(seq)
def subset_scenarios(scenarios, ids, n=None):
    ids=set(ids); source=scenarios if n is None else scenarios[:n]
    return [eng.MonteCarloScenario(
        project_vectors={pid:sc.project_vectors[pid] for pid in ids if pid in sc.project_vectors},
        linear_cot_deltas={pid:sc.linear_cot_deltas[pid] for pid in ids if pid in sc.linear_cot_deltas},
        piecewise_cot_values={pid:sc.piecewise_cot_values[pid] for pid in ids if pid in sc.piecewise_cot_values},
        synergy_values={(pid,i):v for (pid,i),v in sc.synergy_values.items() if pid in ids},
    ) for sc in source]
def eval_ids(portfolio, projects, scenarios, ids, seq_ids, n=None):
    pmap={p.project_id:p for p in projects}; ids=list(dict.fromkeys([i for i in ids if i in pmap])); selected=[pmap[i] for i in ids]
    seq=make_seq(pmap,ids,seq_ids); st=eng.stage_sequence(seq,portfolio)
    if not st.feasible:
        return {'selected_ids':ids,'sequence_ids':[p.project_id for p in seq],'selected_count':len(ids),'stage_feasible':False,'stage_failure_reason':getattr(st,'reason',None),'budget_feasibility_rate':0.0,'constraint_feasibility_rate':0.0,'admissible':False,'p85_profit':None,'profits_n':0}
    br,cr,adm,p85,profits=eng.evaluate_stochastic_from_scenarios(portfolio,selected,seq,subset_scenarios(scenarios,ids,n),optimistic_prefilter=False)
    return {'selected_ids':ids,'sequence_ids':[p.project_id for p in seq],'selected_count':len(ids),'stage_feasible':True,'stage_failure_reason':None,'budget_feasibility_rate':br,'constraint_feasibility_rate':cr,'admissible':bool(adm),'p85_profit':p85,'profits_n':len(profits)}
def sequence_orders(projects,current_seq,bundle,ids_new):
    pmap={p.project_id:p for p in projects}; base=[x for x in current_seq if x not in bundle]; allp=[pmap[i] for i in ids_new if i in pmap]
    orders=[]; seen=set()
    def add(label,order):
        sid=[p.project_id for p in make_seq(pmap,ids_new,order)]; key=tuple(sid)
        if key not in seen: seen.add(key); orders.append((label,sid))
    add('append',base+bundle)
    add('time_pressure',[p.project_id for p in sorted(allp,key=lambda p:(-time_pressure(p),-p.deterministic_base_profit(),p.project_id))])
    add('low_constraint',[p.project_id for p in sorted(allp,key=lambda p:(constraint_total(p),-p.deterministic_base_profit(),p.project_id))])
    return orders
def group_priority(pid):
    if pid.startswith('E'): return 0
    if pid.startswith('B'): return 1
    if pid.startswith('F'): return 2
    if pid.startswith('U'): return 3
    return 4

def expand_method(seed,method_name,start_md):
    portfolio,projects,pmap=pmap_world(seed); all_ids=[p.project_id for p in projects]
    scenarios=eng.generate_mc_scenarios(portfolio,projects,seed*1000+424242)
    current=eval_ids(portfolio,projects,scenarios,start_md.get('selected_ids',[]),start_md.get('sequence_ids',[]),None)
    hist=[]; screen_evals=0; final_evals=1; initial=current.get('selected_count',0)
    if not method_valid(current):
        current['expansion_pass']='residual_universal_marginal_add'; current['expansion_info']={'method':method_name,'iterations_accepted':0,'history':hist,'screen_evaluations':0,'final_evaluations':final_evals,'stop_reason':'initial_not_admissible_for_add_only_pass','initial_selected_count':initial,'final_selected_count':current.get('selected_count',0),'universe_project_count':len(all_ids),'near_all_selected':current.get('selected_count',0)>=NEAR_ALL_THRESHOLD}
        return current
    for it in range(1,MAX_ITERS+1):
        screened=[]; current_ids=set(current['selected_ids'])
        remaining=sorted([pid for pid in all_ids if pid not in current_ids], key=lambda pid:(group_priority(pid), pid))
        if not remaining:
            hist.append({'iteration':it,'accepted':False,'reason':'no_remaining_projects','current_p85':current['p85_profit'],'current_selected_count':current['selected_count']}); break
        for pid in remaining:
            bundle=[x for x in dependency_bundle(pid,pmap) if x not in current_ids]
            if not bundle: continue
            ids_new=list(dict.fromkeys(current['selected_ids']+bundle))
            if set(ids_new)==current_ids or not structural_valid(ids_new,pmap): continue
            for label,seq_ids in sequence_orders(projects,current['sequence_ids'],bundle,ids_new):
                st=eng.stage_sequence(make_seq(pmap,ids_new,seq_ids),portfolio)
                if not st.feasible: continue
                cand=eval_ids(portfolio,projects,scenarios,ids_new,seq_ids,SCREEN_MC); screen_evals+=1
                cand.update({'add_primary':pid,'add_bundle':';'.join(bundle),'sequence_label':label,'screen_p85_profit':cand.get('p85_profit'),'screen_admissible':cand.get('admissible')})
                if method_valid(cand) and cand['p85_profit'] is not None and cand['p85_profit']>current['p85_profit']-250:
                    screened.append(cand)
        screened=sorted(screened,key=lambda c:(c['p85_profit'],c['selected_count']),reverse=True)[:TOP_FINAL]
        best=None; finals=[]
        for sc in screened:
            cand=eval_ids(portfolio,projects,scenarios,sc['selected_ids'],sc['sequence_ids'],None); final_evals+=1
            cand.update({'add_primary':sc['add_primary'],'add_bundle':sc['add_bundle'],'sequence_label':sc['sequence_label'],'screen_p85_profit':sc['screen_p85_profit']})
            finals.append({'add_primary':cand['add_primary'],'add_bundle':cand['add_bundle'],'sequence_label':cand['sequence_label'],'screen_p85_profit':cand['screen_p85_profit'],'final_p85_profit':cand['p85_profit'],'final_admissible':method_valid(cand),'selected_count':cand['selected_count']})
            if method_valid(cand) and cand['p85_profit'] is not None and cand['p85_profit']>current['p85_profit']+1e-9:
                best=cand
        if best is None:
            hist.append({'iteration':it,'accepted':False,'reason':'no_top_screened_candidate_passed_final_MC1000_improvement','current_p85':current['p85_profit'],'current_selected_count':current['selected_count'],'screened_final_candidates':len(screened),'final_candidates':finals}); break
        hist.append({'iteration':it,'accepted':True,'add_primary':best['add_primary'],'add_bundle':best['add_bundle'],'sequence_label':best['sequence_label'],'screen_p85_profit':best['screen_p85_profit'],'old_p85':current['p85_profit'],'new_p85':best['p85_profit'],'delta':best['p85_profit']-current['p85_profit'],'old_selected_count':current['selected_count'],'new_selected_count':best['selected_count']})
        current=best
    accepted=sum(1 for h in hist if h.get('accepted'))
    stop=hist[-1].get('reason') if hist and not hist[-1].get('accepted') else ('max_iters_reached' if accepted>=MAX_ITERS else 'completed')
    current['expansion_pass']='residual_universal_marginal_add'; current['expansion_info']={'method':method_name,'iterations_accepted':accepted,'history':hist,'screen_evaluations':screen_evals,'final_evaluations':final_evals,'stop_reason':stop,'initial_selected_count':initial,'final_selected_count':current.get('selected_count',0),'universe_project_count':len(all_ids),'near_all_threshold':NEAR_ALL_THRESHOLD,'near_all_selected':current.get('selected_count',0)>=NEAR_ALL_THRESHOLD}
    return current
# reporting helpers
def cap_budget(portfolio,t0): return float(portfolio.budget_restriction_profile[t0]) if t0<len(portfolio.budget_restriction_profile) else 0.0
def cap_constraint(portfolio,t0): return float(portfolio.constraint_capacity_profile[t0]) if t0<len(portfolio.constraint_capacity_profile) else float(portfolio.constraint_capacity_profile[-1])
def project_profiles_det(p):
    d=p.deterministic_duration(); return d,[det(x) for x in eng._derive_budget_profile(p,d)],[det(x) for x in eng._normalize_profile(p.constraint_usage_profile,d)]
def project_budget_det(p): return sum(project_profiles_det(p)[1])
def stage_for(seed,md):
    portfolio,projects,pmap=pmap_world(seed); seq=make_seq(pmap,md.get('selected_ids',[]),md.get('sequence_ids',[])); st=eng.stage_sequence(seq,portfolio); return portfolio,projects,pmap,seq,st
def usage_rows(seed,method,md):
    portfolio,projects,pmap,seq,st=stage_for(seed,md); rows=[]
    if not st.feasible or not st.records: return rows
    end=max(r.completion_period_1 for r in st.records)
    for t0 in range(end):
        active=[]; bu=0.0; cu=0.0
        for rec in st.records:
            if rec.start_period_0<=t0<rec.completion_period_1:
                pid=rec.project_id; off=t0-rec.start_period_0; active.append(pid); d,b,c=project_profiles_det(pmap[pid]); bu+=b[off] if off<len(b) else 0.0; cu+=c[off] if off<len(c) else 0.0
        bcap=cap_budget(portfolio,t0); ccap=cap_constraint(portfolio,t0)
        rows.append({'seed':seed,'method':method,'period':t0+1,'active_count':len(active),'active_ids':';'.join(active),'budget_used':bu,'budget_cap':bcap,'budget_util_pct':bu/bcap*100 if bcap>0 else None,'budget_slack':bcap-bu,'budget_ok':bu<=bcap+1e-9,'constraint_used':cu,'constraint_cap':ccap,'constraint_util_pct':cu/ccap*100 if ccap>0 else None,'constraint_slack':ccap-cu,'constraint_ok':cu<=ccap+1e-9})
    return rows
def schedule_rows(seed,method,md):
    portfolio,projects,pmap,seq,st=stage_for(seed,md); rows=[]
    if not st.feasible: return rows
    for rec in st.records: rows.append({'seed':seed,'method':method,'project_id':rec.project_id,'start_period':rec.start_period_0+1,'end_period':rec.completion_period_1,'duration':rec.completion_period_1-rec.start_period_0})
    return rows
def summary_metrics(seed,method,md):
    portfolio,projects,pmap,seq,st=stage_for(seed,md); ids=md.get('selected_ids',[]); u=usage_rows(seed,method,md)
    if st.feasible and st.records:
        start=min(r.start_period_0 for r in st.records)+1; end=max(r.completion_period_1 for r in st.records); dur=end-start+1
    else: start=end=dur=None
    w=[r['active_count'] for r in u]
    return {'seed':seed,'method':method,'admissible':method_valid(md),'stage_feasible':md.get('stage_feasible'),'selected_count':md.get('selected_count'),'p85_profit':md.get('p85_profit'),'budget_feasibility_rate':md.get('budget_feasibility_rate'),'constraint_feasibility_rate':md.get('constraint_feasibility_rate'),'portfolio_start_period':start,'portfolio_end_period':end,'portfolio_duration_periods':dur,'portfolio_budget_det':sum(project_budget_det(pmap[i]) for i in ids if i in pmap),'wip_min':min(w) if w else None,'wip_max':max(w) if w else None,'wip_avg':sum(w)/len(w) if w else None,'max_budget_util_pct':max([r['budget_util_pct'] for r in u],default=None),'max_constraint_util_pct':max([r['constraint_util_pct'] for r in u],default=None),'all_period_budget_ok':all(r['budget_ok'] for r in u) if u else False,'all_period_constraint_ok':all(r['constraint_ok'] for r in u) if u else False,'near_all_selected':md.get('selected_count',0)>=NEAR_ALL_THRESHOLD}
def write_csv(path,rows):
    if not rows: path.write_text('',encoding='utf-8'); return
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields: fields.append(k)
    with open(path,'w',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

seed_outputs=[]; selected_rows=[]; sequence_rows=[]; schedule_all=[]; period_all=[]; wm_summary=[]
for seed in SEEDS:
    print('seed',seed,flush=True)
    data=json.load(open(SRC/f'seed{seed:03d}.json',encoding='utf-8'))
    methods={m:dict(data['final_mc1000_methods'][m]) for m in METHODS}
    exp={}
    for m in METHODS:
        exp[m]=expand_method(seed,m,methods[m]); info=exp[m]['expansion_info']
        print(' ',m,'init',info['initial_selected_count'],'adds',info['iterations_accepted'],'final',info['final_selected_count'],'valid',method_valid(exp[m]),'p85',exp[m].get('p85_profit'),flush=True)
    if method_valid(exp['Octane']):
        ao=exp['aOctane']; oc=exp['Octane']
        if (not method_valid(ao)) or (ao.get('p85_profit') is None) or (ao['p85_profit']+1e-9<oc['p85_profit']):
            fb=dict(oc); fb['eval_guard_fallback_to_expanded_octane']=True; fb['expansion_info']=dict(fb.get('expansion_info',{})); fb['expansion_info']['guard_note']='aOctane replaced by expanded Octane after universal pass.'; exp['aOctane']=fb
    if 'eval_guard_fallback_to_expanded_octane' not in exp['aOctane']: exp['aOctane']['eval_guard_fallback_to_expanded_octane']=False
    admiss3=[(m,exp[m]['p85_profit']) for m in RANKING if method_valid(exp[m])]; best3=max(admiss3,key=lambda x:x[1]) if admiss3 else (None,None)
    admiss4=[(m,exp[m]['p85_profit']) for m in METHODS if method_valid(exp[m])]; best4=max(admiss4,key=lambda x:x[1]) if admiss4 else (None,None)
    delta=exp['sCPA_lite']['p85_profit']-best3[1] if best3[1] is not None and method_valid(exp['sCPA_lite']) else None
    waste={}
    for m,md in exp.items():
        if method_valid(md) and best4[1] is not None:
            aw=best4[1]-md['p85_profit']; waste[m]={'absolute_waste':aw,'pct_waste':aw/best4[1]*100 if best4[1]>DENOM_EPS else None}
        else: waste[m]=None
    out={'test_id':TEST_ID,'seed':seed,'base_v9_3_seed_file':str(SRC/f'seed{seed:03d}.json'),'technical_template_id':'AOSWAP_STRONG_s1p18_bc0p20','dependency_rules':data['dependency_rules'],'synergy_rules':data['synergy_rules'],'expansion_note':'V10 starts from V9.3 and applies the same residual bounded marginal add pass to every method. Add-only; no trim/replace. Acceptance requires final common MC1000 admissibility and P85 improvement.','final_mc1000_methods':exp,'best3_method':best3[0],'best3_p85':best3[1],'best4_method':best4[0],'best4_p85':best4[1],'scpa_delta_vs_best3':delta,'scpa_uplift_pct_vs_best3_positive_denominator_only':pct(delta,best3[1]),'scpa_beats_best3_abs':bool(delta is not None and delta>0),'waste_vs_best4':waste}
    (OUT/f'seed{seed:03d}.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8'); seed_outputs.append(out)
    for m,md in exp.items():
        for i,pid in enumerate(md.get('selected_ids',[]),1): selected_rows.append({'seed':seed,'method':m,'selected_rank':i,'project_id':pid})
        for i,pid in enumerate(md.get('sequence_ids',[]),1): sequence_rows.append({'seed':seed,'method':m,'sequence_rank':i,'project_id':pid})
        schedule_all.extend(schedule_rows(seed,m,md)); period_all.extend(usage_rows(seed,m,md)); wm_summary.append(summary_metrics(seed,m,md))
    print(' -> best3',best3,'delta',delta,'strict',all(method_valid(exp[m]) for m in METHODS),flush=True)

per_seed=[]
for r in seed_outputs:
    row={'seed':r['seed'],'best3_method':r['best3_method'],'best3_p85':r['best3_p85'],'best4_method':r['best4_method'],'best4_p85':r['best4_p85'],'scpa_delta_vs_best3':r['scpa_delta_vs_best3'],'scpa_uplift_pct_pos_den_only':r['scpa_uplift_pct_vs_best3_positive_denominator_only'],'scpa_beats_best3_abs':r['scpa_beats_best3_abs']}
    for m in METHODS:
        md=r['final_mc1000_methods'][m]; info=md.get('expansion_info',{})
        row[f'{m}_admissible']=method_valid(md); row[f'{m}_p85']=md.get('p85_profit'); row[f'{m}_selected_count']=md.get('selected_count'); row[f'{m}_budget_feas']=md.get('budget_feasibility_rate'); row[f'{m}_constraint_feas']=md.get('constraint_feasibility_rate'); row[f'{m}_adds']=info.get('iterations_accepted'); row[f'{m}_initial_selected_count']=info.get('initial_selected_count'); row[f'{m}_final_selected_count']=info.get('final_selected_count'); row[f'{m}_near_all_selected']=md.get('selected_count',0)>=NEAR_ALL_THRESHOLD; row[f'{m}_expansion_stop_reason']=info.get('stop_reason'); row[f'{m}_expansion_history']=json.dumps(info.get('history',[]),ensure_ascii=False)
        w=r['waste_vs_best4'][m]; row[f'{m}_abs_waste']=None if w is None else w['absolute_waste']; row[f'{m}_pct_waste']=None if w is None else w['pct_waste']
    per_seed.append(row)
write_csv(OUT/'per_seed_summary.csv',per_seed); write_csv(OUT/'selected_projects_by_world_method.csv',selected_rows); write_csv(OUT/'sequence_by_world_method.csv',sequence_rows); write_csv(OUT/'project_schedule_by_world_method_det.csv',schedule_all); write_csv(OUT/'period_budget_constraint_wip_by_world_method_det.csv',period_all); write_csv(OUT/'world_method_summary_schedule_budget_wip.csv',wm_summary)
medrows=[]
for m in METHODS:
    rows=[x for x in wm_summary if x['method']==m and x['admissible']]
    def med(k):
        xs=[x[k] for x in rows if x[k] is not None]; return statistics.median(xs) if xs else None
    medrows.append({'method':m,'admissible_worlds':len(rows),'median_selected_count':med('selected_count'),'median_p85_profit':med('p85_profit'),'median_portfolio_start':med('portfolio_start_period'),'median_portfolio_end':med('portfolio_end_period'),'median_portfolio_duration':med('portfolio_duration_periods'),'median_portfolio_budget_det':med('portfolio_budget_det'),'median_wip_min':med('wip_min'),'median_wip_max':med('wip_max'),'median_wip_avg':med('wip_avg'),'median_max_budget_util_pct':med('max_budget_util_pct'),'median_max_constraint_util_pct':med('max_constraint_util_pct'),'near_all_selected_worlds':sum(1 for x in rows if x.get('near_all_selected'))})
write_csv(OUT/'method_level_medians_schedule_budget_wip.csv',medrows)
usable=[r['seed'] for r in seed_outputs if r['best3_method']]; strict=[r['seed'] for r in seed_outputs if all(method_valid(r['final_mc1000_methods'][m]) for m in METHODS)]
deltas=[r['scpa_delta_vs_best3'] for r in seed_outputs if r['scpa_delta_vs_best3'] is not None]; uplifts=[r['scpa_uplift_pct_vs_best3_positive_denominator_only'] for r in seed_outputs if r['scpa_uplift_pct_vs_best3_positive_denominator_only'] is not None]
method_counts={m:sum(method_valid(r['final_mc1000_methods'][m]) for r in seed_outputs) for m in METHODS}
waste_best=[r['waste_vs_best4'][r['best3_method']]['pct_waste'] for r in seed_outputs if r['best3_method'] and r['best4_method']=='sCPA_lite' and r['waste_vs_best4'][r['best3_method']] is not None]
waste_abs=[r['waste_vs_best4'][r['best3_method']]['absolute_waste'] for r in seed_outputs if r['best3_method'] and r['best4_method']=='sCPA_lite' and r['waste_vs_best4'][r['best3_method']] is not None]
add_counts={m:[r['final_mc1000_methods'][m].get('expansion_info',{}).get('iterations_accepted',0) for r in seed_outputs] for m in METHODS}
near_all={m:sum(r['final_mc1000_methods'][m].get('selected_count',0)>=NEAR_ALL_THRESHOLD and method_valid(r['final_mc1000_methods'][m]) for r in seed_outputs) for m in METHODS}
summary={'test_id':TEST_ID,'status':'Residual universal add expansion applied symmetrically to all methods starting from V9.3. Fast bounded version: TOP_FINAL=1, three sequence orders, add-only.','world_count':10,'project_universe_count':38,'near_all_threshold':NEAR_ALL_THRESHOLD,'method_admissible_counts':method_counts,'usable_ranking_comparison_worlds':len(usable),'usable_ranking_comparison_seeds':usable,'strict_4way_worlds':len(strict),'strict_4way_seeds':strict,'scpa_beats_best3_abs_worlds':sum(r['scpa_beats_best3_abs'] for r in seed_outputs),'scpa_best4_worlds':sum(r['best4_method']=='sCPA_lite' for r in seed_outputs),'median_scpa_p85':statistics.median([r['final_mc1000_methods']['sCPA_lite']['p85_profit'] for r in seed_outputs]),'median_delta_vs_best3':statistics.median(deltas) if deltas else None,'mean_delta_vs_best3':statistics.mean(deltas) if deltas else None,'min_delta_vs_best3':min(deltas) if deltas else None,'max_delta_vs_best3':max(deltas) if deltas else None,'median_uplift_pct_positive_best3_only':statistics.median(uplifts) if uplifts else None,'positive_denominator_worlds_for_pct':len(uplifts),'median_abs_waste_best_ranking_vs_scpa':statistics.median(waste_abs) if waste_abs else None,'median_pct_waste_best_ranking_vs_scpa':statistics.median(waste_best) if waste_best else None,'method_level_medians':medrows,'method_add_counts':add_counts,'near_all_selected_worlds_by_method':near_all,'aoctane_guard_fallback_count':sum(bool(r['final_mc1000_methods']['aOctane'].get('eval_guard_fallback_to_expanded_octane')) for r in seed_outputs),'aoctane_invariant_violations_after_guard':[r['seed'] for r in seed_outputs if method_valid(r['final_mc1000_methods']['Octane']) and method_valid(r['final_mc1000_methods']['aOctane']) and r['final_mc1000_methods']['aOctane']['p85_profit']+1e-9<r['final_mc1000_methods']['Octane']['p85_profit']]}
(OUT/'summary.json').write_text(json.dumps({'summary':summary,'per_seed':per_seed,'method_level_medians':medrows},indent=2,ensure_ascii=False),encoding='utf-8')
report=[TEST_ID,'','Residual universal marginal add expansion applied to all methods from V9.3.',f'Project universe: 38; near-all threshold: >= {NEAR_ALL_THRESHOLD}',f'Method admissible counts: {method_counts}',f'Usable ranking comparison: {len(usable)}/10 seeds {usable}',f'Strict 4-way: {len(strict)}/10 seeds {strict}',f'sCPA beats best ranking: {summary["scpa_beats_best3_abs_worlds"]}/{len(usable)}',f'sCPA best overall: {summary["scpa_best4_worlds"]}/10',f'Median sCPA P85: {summary["median_scpa_p85"]:.6f}',f'Median delta vs best ranking: {summary["median_delta_vs_best3"]:.6f}' if summary['median_delta_vs_best3'] is not None else 'Median delta vs best ranking: n/a','', 'Medians by method:']
for r in medrows: report.append(f"- {r['method']}: admissible {r['admissible_worlds']}/10; selected {r['median_selected_count']}; P85 {r['median_p85_profit']}; duration {r['median_portfolio_duration']}; budget {r['median_portfolio_budget_det']}; avg WIP {r['median_wip_avg']}; near-all worlds {r['near_all_selected_worlds']}")
report += ['','Trace files included for all methods: selected projects, sequence, project schedules, period utilization, WIP, P85, feasibility.','Limit: fast bounded add-only pass; does not trim/replace inadmissible configurations.']
(OUT/'REPORT_BG.txt').write_text('\n'.join(report),encoding='utf-8')
if ZIP.exists(): ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
    z.write('/mnt/data/run_v10_residual_universal_expansion_fast.py',arcname='run_v10_residual_universal_expansion_fast.py')
    z.write('/mnt/data/run_custom_v8.py',arcname='run_custom_v8.py'); z.write('/mnt/data/run_v7_variant.py',arcname='run_v7_variant.py'); z.write('/mnt/data/pol_scpa_lite_runner.py',arcname='pol_scpa_lite_runner.py')
    for p in OUT.rglob('*'): z.write(p,arcname=str(p.relative_to(OUT.parent)))
print(json.dumps(summary,indent=2,ensure_ascii=False)); print('ZIP',ZIP)
