from __future__ import annotations
import json, csv, statistics, zipfile, shutil, importlib.util, math
from pathlib import Path

# Source modules from validated V8/V11B line, but DO NOT import run_v11b because it executes top-level.
spec=importlib.util.spec_from_file_location('v8','/mnt/data/run_custom_v8.py')
v8=importlib.util.module_from_spec(spec); spec.loader.exec_module(v8)
eng=v8.v7.eng

SEEDS=list(range(1,11)); METHODS=['MSA','Octane','aOctane','sCPA_lite']; RANKING=['MSA','Octane','aOctane']
SRC=Path('/mnt/data/R7_STRUCTURAL_SOFT_V11B_TARGETED_UNIVERSAL_ADD_VALIDATION_MC1000_v1')
TEST_ID='R7_STRUCTURAL_SOFT_V12_BUDGET_CALIBRATION_x20_capsx9_REEVAL_V11B_MC1000_v1'
OUT=Path('/mnt/data')/TEST_ID; ZIP=Path(str(OUT)+'.zip')
PROJECT_BUDGET_MULT=20.0
PERIOD_BUDGET_CAP_MULT=9.0
FINAL_MC=1000; DENOM_EPS=1e-9; NEAR_ALL_THRESHOLD=34
if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir()

def scale_value(x,m):
    # Preserve ThreePoint if present; floats otherwise.
    if hasattr(x,'optimistic') and hasattr(x,'most_likely') and hasattr(x,'pessimistic'):
        return eng.ThreePoint(x.optimistic*m, x.most_likely*m, x.pessimistic*m)
    return x*m

def world_scaled(seed:int, mc:int):
    p,ps=v8.world(seed,mc)
    p.portfolio_id += f'_budgetcal_projectbudgets_x{PROJECT_BUDGET_MULT:g}_caps_x{PERIOD_BUDGET_CAP_MULT:g}'
    p.monte_carlo_iterations=mc
    p.budget_restriction_profile=[float(x)*PERIOD_BUDGET_CAP_MULT for x in p.budget_restriction_profile]
    for pr in ps:
        pr.budget_usage_profile=[scale_value(x,PROJECT_BUDGET_MULT) for x in pr.budget_usage_profile]
        if getattr(pr,'total_project_budget',None) is not None:
            pr.total_project_budget=scale_value(pr.total_project_budget,PROJECT_BUDGET_MULT)
    return p,ps

def det(x): return float(x.deterministic() if hasattr(x,'deterministic') else x)
def method_valid(md): return bool(md.get('admissible') and md.get('stage_feasible') and md.get('selected_count',0)>0)
def pct(delta,den): return None if delta is None or den is None or den<=DENOM_EPS else delta/den*100.0

def make_seq(pmap, ids, order):
    ids=list(dict.fromkeys([i for i in ids if i in pmap])); s=set(ids)
    seq=[pmap[i] for i in order if i in pmap and i in s]
    seen={p.project_id for p in seq}
    seq += [pmap[i] for i in ids if i not in seen]
    return eng._dependency_aware_stable_order(seq)

def subset_scenarios(scenarios, ids):
    ids=set(ids)
    return [eng.MonteCarloScenario(
        project_vectors={pid:sc.project_vectors[pid] for pid in ids if pid in sc.project_vectors},
        linear_cot_deltas={pid:sc.linear_cot_deltas[pid] for pid in ids if pid in sc.linear_cot_deltas},
        piecewise_cot_values={pid:sc.piecewise_cot_values[pid] for pid in ids if pid in sc.piecewise_cot_values},
        synergy_values={(pid,i):v for (pid,i),v in sc.synergy_values.items() if pid in ids},
    ) for sc in scenarios]

def eval_ids(portfolio, projects, scenarios, ids, seq_ids):
    pmap={p.project_id:p for p in projects}; ids=list(dict.fromkeys([i for i in ids if i in pmap]))
    selected=[pmap[i] for i in ids]; seq=make_seq(pmap,ids,seq_ids)
    st=eng.stage_sequence(seq,portfolio)
    if not st.feasible:
        return {'selected_ids':ids,'sequence_ids':[p.project_id for p in seq],'selected_count':len(ids),'stage_feasible':False,'stage_failure_reason':getattr(st,'reason',None),'budget_feasibility_rate':0.0,'constraint_feasibility_rate':0.0,'admissible':False,'p85_profit':None,'profits_n':0}
    br,cr,adm,p85,profits=eng.evaluate_stochastic_from_scenarios(portfolio,selected,seq,subset_scenarios(scenarios,ids),optimistic_prefilter=False)
    return {'selected_ids':ids,'sequence_ids':[p.project_id for p in seq],'selected_count':len(ids),'stage_feasible':True,'stage_failure_reason':None,'budget_feasibility_rate':br,'constraint_feasibility_rate':cr,'admissible':bool(adm),'p85_profit':p85,'profits_n':len(profits)}

def cap_budget(portfolio,t0): return float(portfolio.budget_restriction_profile[t0]) if t0<len(portfolio.budget_restriction_profile) else 0.0
def cap_constraint(portfolio,t0): return float(portfolio.constraint_capacity_profile[t0]) if t0<len(portfolio.constraint_capacity_profile) else float(portfolio.constraint_capacity_profile[-1])
def project_profiles_det(pr):
    d=pr.deterministic_duration()
    return d,[det(x) for x in eng._derive_budget_profile(pr,d)],[det(x) for x in eng._normalize_profile(pr.constraint_usage_profile,d)]
def project_budget_det(pr): return sum(project_profiles_det(pr)[1])

def stage_for(seed,md):
    portfolio,projects=world_scaled(seed,FINAL_MC); pmap={p.project_id:p for p in projects}
    seq=make_seq(pmap,md.get('selected_ids',[]),md.get('sequence_ids',[])); st=eng.stage_sequence(seq,portfolio)
    return portfolio,projects,pmap,seq,st

def usage_rows(seed,method,md):
    portfolio,projects,pmap,seq,st=stage_for(seed,md); rows=[]
    if not st.feasible or not st.records: return rows
    end=max(r.completion_period_1 for r in st.records)
    for t0 in range(end):
        active=[]; bu=0.0; cu=0.0
        for rec in st.records:
            if rec.start_period_0<=t0<rec.completion_period_1:
                pid=rec.project_id; off=t0-rec.start_period_0; active.append(pid)
                d,b,c=project_profiles_det(pmap[pid]); bu += b[off] if off<len(b) else 0.0; cu += c[off] if off<len(c) else 0.0
        bcap=cap_budget(portfolio,t0); ccap=cap_constraint(portfolio,t0)
        rows.append({'seed':seed,'method':method,'period':t0+1,'active_count':len(active),'active_ids':';'.join(active),'budget_used':bu,'budget_cap':bcap,'budget_util_pct':bu/bcap*100 if bcap>0 else None,'budget_slack':bcap-bu,'budget_ok':bu<=bcap+1e-9,'constraint_used':cu,'constraint_cap':ccap,'constraint_util_pct':cu/ccap*100 if ccap>0 else None,'constraint_slack':ccap-cu,'constraint_ok':cu<=ccap+1e-9})
    return rows

def schedule_rows(seed,method,md):
    portfolio,projects,pmap,seq,st=stage_for(seed,md); rows=[]
    if not st.feasible: return rows
    for rec in st.records:
        rows.append({'seed':seed,'method':method,'project_id':rec.project_id,'start_period':rec.start_period_0+1,'end_period':rec.completion_period_1,'duration':rec.completion_period_1-rec.start_period_0})
    return rows

def summary_metrics(seed,method,md):
    portfolio,projects,pmap,seq,st=stage_for(seed,md); ids=md.get('selected_ids',[]); u=usage_rows(seed,method,md)
    if st.feasible and st.records:
        start=min(r.start_period_0 for r in st.records)+1; end=max(r.completion_period_1 for r in st.records); dur=end-start+1
    else: start=end=dur=None
    w=[r['active_count'] for r in u]
    p85=md.get('p85_profit')
    budget_det=sum(project_budget_det(pmap[i]) for i in ids if i in pmap)
    roi_det = (p85/budget_det*100.0) if p85 is not None and budget_det and budget_det>0 else None
    return {'seed':seed,'method':method,'admissible':method_valid(md),'stage_feasible':md.get('stage_feasible'),'selected_count':md.get('selected_count'),'p85_profit':p85,'budget_feasibility_rate':md.get('budget_feasibility_rate'),'constraint_feasibility_rate':md.get('constraint_feasibility_rate'),'portfolio_start_period':start,'portfolio_end_period':end,'portfolio_duration_periods':dur,'portfolio_budget_det':budget_det,'roi_pct_det_budget':roi_det,'wip_min':min(w) if w else None,'wip_max':max(w) if w else None,'wip_avg':sum(w)/len(w) if w else None,'max_budget_util_pct':max([r['budget_util_pct'] for r in u],default=None),'max_constraint_util_pct':max([r['constraint_util_pct'] for r in u],default=None),'all_period_budget_ok':all(r['budget_ok'] for r in u) if u else False,'all_period_constraint_ok':all(r['constraint_ok'] for r in u) if u else False,'near_all_selected':md.get('selected_count',0)>=NEAR_ALL_THRESHOLD}

def write_csv(path,rows):
    if not rows:
        path.write_text('',encoding='utf-8'); return
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields: fields.append(k)
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

def suspicious_audit(seed_outputs, wm_summary):
    rows=[]
    for r in seed_outputs:
        seed=r['seed']; methods=r['final_mc1000_methods']
        if method_valid(methods['Octane']) and method_valid(methods['aOctane']) and methods['aOctane']['p85_profit']+1e-9<methods['Octane']['p85_profit']:
            rows.append({'seed':seed,'method':'aOctane','signal':'aOctane_below_Octane','severity':'critical','detail':f"aOctane {methods['aOctane']['p85_profit']} < Octane {methods['Octane']['p85_profit']}"})
        for m,md in methods.items():
            ids=md.get('selected_ids',[]); seq=md.get('sequence_ids',[])
            if len(ids)!=len(set(ids)): rows.append({'seed':seed,'method':m,'signal':'duplicate_selected_ids','severity':'critical','detail':'selected_ids contains duplicates'})
            if len(seq)!=len(set(seq)): rows.append({'seed':seed,'method':m,'signal':'duplicate_sequence_ids','severity':'critical','detail':'sequence_ids contains duplicates'})
            if set(ids)!=set(seq): rows.append({'seed':seed,'method':m,'signal':'sequence_selected_mismatch','severity':'critical','detail':f'selected/sequence sets differ: {set(ids)^set(seq)}'})
            if md.get('selected_count',0)>=NEAR_ALL_THRESHOLD:
                rows.append({'seed':seed,'method':m,'signal':'near_all_selected','severity':'warning','detail':f"{md.get('selected_count')} of 38 selected"})
    for x in wm_summary:
        if not x.get('all_period_budget_ok'): rows.append({'seed':x['seed'],'method':x['method'],'signal':'deterministic_budget_period_violation','severity':'critical','detail':'period budget violation'})
        if not x.get('all_period_constraint_ok'): rows.append({'seed':x['seed'],'method':x['method'],'signal':'deterministic_constraint_period_violation','severity':'critical','detail':'period constraint violation'})
        sc=x.get('selected_count') or 0; dur=x.get('portfolio_duration_periods') or 0; mx=x.get('wip_max') or 0
        if x.get('admissible') and dur and sc>=20 and dur<=10:
            rows.append({'seed':x['seed'],'method':x['method'],'signal':'short_duration_many_projects','severity':'warning','detail':f'{sc} projects in {dur} periods'})
        if mx>=18:
            rows.append({'seed':x['seed'],'method':x['method'],'signal':'very_high_period_WIP','severity':'warning','detail':f'max WIP {mx}'})
        if x.get('roi_pct_det_budget') is not None and x['roi_pct_det_budget']>35 and x.get('admissible'):
            rows.append({'seed':x['seed'],'method':x['method'],'signal':'roi_above_35pct','severity':'info','detail':f"ROI {x['roi_pct_det_budget']:.2f}%"})
    if not rows:
        rows.append({'seed':None,'method':None,'signal':'no_suspicious_signal_detected','severity':'ok','detail':'No critical or warning signals under configured checks.'})
    return rows

seed_outputs=[]; selected_rows=[]; sequence_rows=[]; schedule_all=[]; period_all=[]; wm_summary=[]
for seed in SEEDS:
    src=json.load(open(SRC/f'seed{seed:03d}.json',encoding='utf-8'))
    portfolio,projects=world_scaled(seed,FINAL_MC); scs=eng.generate_mc_scenarios(portfolio,projects,seed*1000+424242)
    methods={}
    for m in METHODS:
        old=src['final_mc1000_methods'][m]
        md=eval_ids(portfolio,projects,scs,old.get('selected_ids',[]),old.get('sequence_ids',[]))
        # carry expansion metadata for traceability
        for k in ['expansion_info','expansion_pass','eval_guard_fallback_to_expanded_octane']:
            if k in old: md[k]=old[k]
        methods[m]=md
    # aOctane invariant guard after scaled re-eval
    if method_valid(methods['Octane']):
        oc=methods['Octane']; ao=methods['aOctane']
        if (not method_valid(ao)) or (ao.get('p85_profit') is None) or ao['p85_profit']+1e-9 < oc['p85_profit']:
            fb=dict(oc); fb['eval_guard_fallback_to_scaled_octane']=True; methods['aOctane']=fb
    if 'eval_guard_fallback_to_scaled_octane' not in methods['aOctane']:
        methods['aOctane']['eval_guard_fallback_to_scaled_octane']=False
    admiss3=[(m,methods[m]['p85_profit']) for m in RANKING if method_valid(methods[m])]
    best3=max(admiss3,key=lambda x:x[1]) if admiss3 else (None,None)
    admiss4=[(m,methods[m]['p85_profit']) for m in METHODS if method_valid(methods[m])]
    best4=max(admiss4,key=lambda x:x[1]) if admiss4 else (None,None)
    delta=methods['sCPA_lite']['p85_profit']-best3[1] if best3[1] is not None and method_valid(methods['sCPA_lite']) else None
    waste={}
    for m,md in methods.items():
        if method_valid(md) and best4[1] is not None:
            aw=best4[1]-md['p85_profit']; waste[m]={'absolute_waste':aw,'pct_waste':aw/best4[1]*100 if best4[1]>DENOM_EPS else None}
        else: waste[m]=None
    out={'test_id':TEST_ID,'seed':seed,'source_v11b_seed_file':str(SRC/f'seed{seed:03d}.json'),'calibration':{'project_budget_usage_multiplier':PROJECT_BUDGET_MULT,'period_budget_cap_multiplier':PERIOD_BUDGET_CAP_MULT,'profit_multiplier':1.0,'duration_multiplier':1.0,'constraint_capacity_multiplier':1.0,'constraint_usage_multiplier':1.0,'calibration_mode':'simultaneous rescale and MC1000 re-evaluation of final V11B selections/sequences'},'final_mc1000_methods':methods,'best3_method':best3[0],'best3_p85':best3[1],'best4_method':best4[0],'best4_p85':best4[1],'scpa_delta_vs_best3':delta,'scpa_uplift_pct_vs_best3_positive_denominator_only':pct(delta,best3[1]),'scpa_beats_best3_abs':bool(delta is not None and delta>0),'waste_vs_best4':waste}
    (OUT/f'seed{seed:03d}.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8'); seed_outputs.append(out)
    for m,md in methods.items():
        for i,pid in enumerate(md.get('selected_ids',[]),1): selected_rows.append({'seed':seed,'method':m,'selected_rank':i,'project_id':pid})
        for i,pid in enumerate(md.get('sequence_ids',[]),1): sequence_rows.append({'seed':seed,'method':m,'sequence_rank':i,'project_id':pid})
        schedule_all.extend(schedule_rows(seed,m,md)); period_all.extend(usage_rows(seed,m,md)); wm_summary.append(summary_metrics(seed,m,md))

write_csv(OUT/'selected_projects_by_world_method.csv',selected_rows); write_csv(OUT/'sequence_by_world_method.csv',sequence_rows); write_csv(OUT/'project_schedule_by_world_method_det.csv',schedule_all); write_csv(OUT/'period_budget_constraint_wip_by_world_method_det.csv',period_all); write_csv(OUT/'world_method_summary_schedule_budget_wip_roi.csv',wm_summary)
per_seed=[]
for r in seed_outputs:
    row={'seed':r['seed'],'best3_method':r['best3_method'],'best3_p85':r['best3_p85'],'best4_method':r['best4_method'],'best4_p85':r['best4_p85'],'scpa_delta_vs_best3':r['scpa_delta_vs_best3'],'scpa_uplift_pct_pos_den_only':r['scpa_uplift_pct_vs_best3_positive_denominator_only'],'scpa_beats_best3_abs':r['scpa_beats_best3_abs']}
    for m in METHODS:
        md=r['final_mc1000_methods'][m]
        sm=next(x for x in wm_summary if x['seed']==r['seed'] and x['method']==m)
        row[f'{m}_admissible']=method_valid(md); row[f'{m}_p85']=md.get('p85_profit'); row[f'{m}_selected_count']=md.get('selected_count'); row[f'{m}_budget_feas']=md.get('budget_feasibility_rate'); row[f'{m}_constraint_feas']=md.get('constraint_feasibility_rate'); row[f'{m}_det_budget']=sm.get('portfolio_budget_det'); row[f'{m}_roi_pct_det_budget']=sm.get('roi_pct_det_budget'); row[f'{m}_max_budget_util_pct']=sm.get('max_budget_util_pct'); row[f'{m}_max_constraint_util_pct']=sm.get('max_constraint_util_pct')
        w=r['waste_vs_best4'][m]; row[f'{m}_abs_waste']=None if w is None else w['absolute_waste']; row[f'{m}_pct_waste']=None if w is None else w['pct_waste']
    per_seed.append(row)
write_csv(OUT/'per_seed_summary.csv',per_seed)
medrows=[]
for m in METHODS:
    rows=[x for x in wm_summary if x['method']==m and x['admissible']]
    def med(k):
        xs=[x[k] for x in rows if x.get(k) is not None]; return statistics.median(xs) if xs else None
    medrows.append({'method':m,'admissible_worlds':len(rows),'median_selected_count':med('selected_count'),'median_p85_profit':med('p85_profit'),'median_portfolio_duration':med('portfolio_duration_periods'),'median_portfolio_budget_det':med('portfolio_budget_det'),'median_roi_pct_det_budget':med('roi_pct_det_budget'),'median_wip_avg':med('wip_avg'),'median_wip_max':med('wip_max'),'median_max_budget_util_pct':med('max_budget_util_pct'),'median_max_constraint_util_pct':med('max_constraint_util_pct'),'near_all_selected_worlds':sum(1 for x in rows if x.get('near_all_selected'))})
write_csv(OUT/'method_level_medians_schedule_budget_wip_roi.csv',medrows)

usable=[r['seed'] for r in seed_outputs if r['best3_method']]; strict=[r['seed'] for r in seed_outputs if all(method_valid(r['final_mc1000_methods'][m]) for m in METHODS)]
deltas=[r['scpa_delta_vs_best3'] for r in seed_outputs if r['scpa_delta_vs_best3'] is not None]; uplifts=[r['scpa_uplift_pct_vs_best3_positive_denominator_only'] for r in seed_outputs if r['scpa_uplift_pct_vs_best3_positive_denominator_only'] is not None]
method_counts={m:sum(method_valid(r['final_mc1000_methods'][m]) for r in seed_outputs) for m in METHODS}
waste_best=[r['waste_vs_best4'][r['best3_method']]['pct_waste'] for r in seed_outputs if r['best3_method'] and r['best4_method']=='sCPA_lite' and r['waste_vs_best4'][r['best3_method']] is not None]
summary={'test_id':TEST_ID,'status':'V12 simultaneous budget calibration: project budget profiles x20 and period budget caps x9; profits, durations, constraint usage/capacity unchanged. Final V11B selections/sequences were re-evaluated with common MC1000 under the calibrated budget scale.','world_count':10,'project_universe_count':38,'project_budget_usage_multiplier':PROJECT_BUDGET_MULT,'period_budget_cap_multiplier':PERIOD_BUDGET_CAP_MULT,'method_admissible_counts':method_counts,'usable_ranking_comparison_worlds':len(usable),'usable_ranking_comparison_seeds':usable,'strict_4way_worlds':len(strict),'strict_4way_seeds':strict,'scpa_beats_best3_abs_worlds':sum(r['scpa_beats_best3_abs'] for r in seed_outputs),'scpa_best4_worlds':sum(r['best4_method']=='sCPA_lite' for r in seed_outputs),'median_scpa_p85':statistics.median([r['final_mc1000_methods']['sCPA_lite']['p85_profit'] for r in seed_outputs]),'median_delta_vs_best3':statistics.median(deltas) if deltas else None,'median_uplift_pct_positive_best3_only':statistics.median(uplifts) if uplifts else None,'positive_denominator_worlds_for_pct':len(uplifts),'median_pct_waste_best_ranking_vs_scpa':statistics.median(waste_best) if waste_best else None,'method_level_medians':medrows,'aoctane_invariant_violations_after_guard':[r['seed'] for r in seed_outputs if method_valid(r['final_mc1000_methods']['Octane']) and method_valid(r['final_mc1000_methods']['aOctane']) and r['final_mc1000_methods']['aOctane']['p85_profit']+1e-9<r['final_mc1000_methods']['Octane']['p85_profit']]}
sus=suspicious_audit(seed_outputs,wm_summary); write_csv(OUT/'suspicious_signal_audit.csv',sus)
summary['critical_suspicious_signals']=sum(1 for r in sus if r.get('severity')=='critical')
summary['warning_suspicious_signals']=sum(1 for r in sus if r.get('severity')=='warning')
summary['info_suspicious_signals']=sum(1 for r in sus if r.get('severity')=='info')
(OUT/'summary.json').write_text(json.dumps({'summary':summary,'per_seed':per_seed,'method_level_medians':medrows},indent=2,ensure_ascii=False),encoding='utf-8')
report=[TEST_ID,'','V12 simultaneous calibration: project budget profiles x20 + period budget caps x9. Profit, duration, and constraint model unchanged. Final V11B selections/sequences re-evaluated with common MC1000 under calibrated budget scale.','',f'Method admissible counts: {method_counts}',f'Usable ranking comparison: {len(usable)}/10 seeds {usable}',f'Strict 4-way: {len(strict)}/10 seeds {strict}',f'sCPA beats best ranking: {summary["scpa_beats_best3_abs_worlds"]}/{len(usable)}',f'sCPA best overall: {summary["scpa_best4_worlds"]}/10',f'Median sCPA P85: {summary["median_scpa_p85"]:.6f}',f'Median delta vs best ranking: {summary["median_delta_vs_best3"]:.6f}' if summary['median_delta_vs_best3'] is not None else 'Median delta: n/a','', 'Medians by method:']
for r in medrows:
    report.append(f"- {r['method']}: adm {r['admissible_worlds']}/10; selected {r['median_selected_count']}; P85 {r['median_p85_profit']}; budget {r['median_portfolio_budget_det']}; ROI {r['median_roi_pct_det_budget']}%; max budget util {r['median_max_budget_util_pct']}%; max constraint util {r['median_max_constraint_util_pct']}%")
report += ['', f"Suspicious-signal audit: critical={summary['critical_suspicious_signals']}; warning={summary['warning_suspicious_signals']}; info={summary['info_suspicious_signals']}."]
(OUT/'REPORT_BG.txt').write_text('\n'.join(report),encoding='utf-8')
if ZIP.exists(): ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
    z.write('/mnt/data/run_v12_budget_calibration_eval.py',arcname='run_v12_budget_calibration_eval.py')
    z.write('/mnt/data/run_custom_v8.py',arcname='run_custom_v8.py'); z.write('/mnt/data/run_v7_variant.py',arcname='run_v7_variant.py'); z.write('/mnt/data/pol_scpa_lite_runner.py',arcname='pol_scpa_lite_runner.py')
    for p in OUT.rglob('*'): z.write(p,arcname=str(p.relative_to(OUT.parent)))
print(json.dumps(summary,indent=2,ensure_ascii=False)); print('ZIP',ZIP)
