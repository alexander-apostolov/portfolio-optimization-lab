from __future__ import annotations
import json,csv,statistics,shutil,zipfile,importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('v8','/mnt/data/run_custom_v8.py')
v8=importlib.util.module_from_spec(spec); spec.loader.exec_module(v8)
eng=v8.v7.eng
SEEDS=range(1,11); METHODS=['MSA','Octane','aOctane','sCPA_lite']; RANKING=['MSA','Octane','aOctane']
SRC=Path('/mnt/data/R7_STRUCTURAL_SOFT_V11B_TARGETED_UNIVERSAL_ADD_VALIDATION_MC1000_v1')
TEST_ID='R7_STRUCTURAL_SOFT_V14B_DETERMINISTIC_BUDGET_TRIM_CAP2_MC1000_v1'
OUT=Path('/mnt/data')/TEST_ID; ZIP=Path(str(OUT)+'.zip')
PROJECT_BUDGET_MULT=20.0; CAP_MULT=2.0; MC=1000; NEAR_ALL=34; EPS=1e-9
if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir()

def write_csv(path,rows):
    if not rows: Path(path).write_text('',encoding='utf-8'); return
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields: fields.append(k)
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

def det(x): return float(x.deterministic() if hasattr(x,'deterministic') else x)
def scale(x,m):
    if hasattr(x,'optimistic') and hasattr(x,'most_likely') and hasattr(x,'pessimistic'):
        return eng.ThreePoint(x.optimistic*m,x.most_likely*m,x.pessimistic*m)
    return x*m

def world(seed):
    p,ps=v8.world(seed,MC); p.monte_carlo_iterations=MC
    p.budget_restriction_profile=[float(x)*CAP_MULT for x in p.budget_restriction_profile]
    for pr in ps:
        pr.budget_usage_profile=[scale(x,PROJECT_BUDGET_MULT) for x in pr.budget_usage_profile]
        if getattr(pr,'total_project_budget',None) is not None: pr.total_project_budget=scale(pr.total_project_budget,PROJECT_BUDGET_MULT)
    return p,ps,{x.project_id:x for x in ps}

def profiles(p):
    d=p.deterministic_duration(); return d,[det(x) for x in eng._derive_budget_profile(p,d)],[det(x) for x in eng._normalize_profile(p.constraint_usage_profile,d)]
def pb(p): return sum(profiles(p)[1])
def pc(p): return sum(profiles(p)[2])
def tp(p):
    cot=p.cost_of_time_profile; typ=getattr(cot.profile_type,'value',str(cot.profile_type))
    if typ=='Linear': return abs(det(cot.linear_delta_per_period))/max(abs(p.deterministic_base_profit()),1e-9)
    if typ=='Cliff': return 1.0
    return 0.0

def structural_prune(ids,pmap):
    ids=[i for i in ids if i in pmap]; s=set(ids); changed=True
    while changed:
        changed=False
        for pid in list(s):
            if not set(pmap[pid].structural_dependencies).issubset(s): s.remove(pid); changed=True
    return [i for i in ids if i in s]

def make_seq(pmap,ids,order):
    ids=structural_prune(list(dict.fromkeys(ids)),pmap); s=set(ids)
    seq=[pmap[i] for i in order if i in pmap and i in s]
    seen={p.project_id for p in seq}; seq += [pmap[i] for i in ids if i not in seen]
    return eng._dependency_aware_stable_order(seq)

def subset_scenarios(scs,ids):
    ids=set(ids)
    return [eng.MonteCarloScenario(project_vectors={pid:sc.project_vectors[pid] for pid in ids if pid in sc.project_vectors},linear_cot_deltas={pid:sc.linear_cot_deltas[pid] for pid in ids if pid in sc.linear_cot_deltas},piecewise_cot_values={pid:sc.piecewise_cot_values[pid] for pid in ids if pid in sc.piecewise_cot_values},synergy_values={(pid,i):v for (pid,i),v in sc.synergy_values.items() if pid in ids}) for sc in scs]

def eval_final(p,ps,scs,ids,seq_ids):
    pmap={x.project_id:x for x in ps}; ids=structural_prune(ids,pmap); seq=make_seq(pmap,ids,seq_ids); st=eng.stage_sequence(seq,p)
    if not st.feasible: return {'selected_ids':ids,'sequence_ids':[x.project_id for x in seq],'selected_count':len(ids),'stage_feasible':False,'stage_failure_reason':getattr(st,'reason',None),'budget_feasibility_rate':0,'constraint_feasibility_rate':0,'admissible':False,'p85_profit':None}
    br,cr,adm,p85,profits=eng.evaluate_stochastic_from_scenarios(p,[pmap[i] for i in ids],seq,subset_scenarios(scs,ids),optimistic_prefilter=False)
    return {'selected_ids':ids,'sequence_ids':[x.project_id for x in seq],'selected_count':len(ids),'stage_feasible':True,'stage_failure_reason':None,'budget_feasibility_rate':br,'constraint_feasibility_rate':cr,'admissible':bool(adm),'p85_profit':p85}

def valid(md): return bool(md.get('stage_feasible') and md.get('admissible') and md.get('p85_profit') is not None)

def removal_candidate(ids,pmap):
    # one deterministic rule: remove low value per budget/constraint, low time pressure, protect U if high time pressure
    arr=[pmap[i] for i in ids if i in pmap]
    if not arr: return None
    return sorted(arr,key=lambda p:(p.deterministic_base_profit()/max(pb(p),1e-9),p.deterministic_base_profit()/max(pc(p),1e-9),tp(p),p.project_id))[0].project_id

def deterministic_trim(seed,method,start):
    p,ps,pmap=world(seed); ids=list(start.get('selected_ids',[])); seq=list(start.get('sequence_ids',[])); hist=[]
    # trim until deterministic stage feasible under cap x2
    for it in range(25):
        st=eng.stage_sequence(make_seq(pmap,ids,seq),p)
        if st.feasible: break
        pid=removal_candidate(ids,pmap)
        if pid is None: break
        old=len(ids); ids=structural_prune([x for x in ids if x!=pid],pmap); seq=[x for x in seq if x in set(ids)]
        hist.append({'phase':'deterministic_trim','removed':pid,'old_count':old,'new_count':len(ids),'stage_reason':getattr(st,'reason',None)})
    scs=eng.generate_mc_scenarios(p,ps,seed*1000+424242)
    md=eval_final(p,ps,scs,ids,seq)
    # if MC not admissible, remove up to 6 more one-by-one and re-evaluate only once at end? Do deterministic low-value removals.
    extra=[]
    tries=0
    while not valid(md) and md.get('stage_feasible') and tries<6 and len(ids)>1:
        tries+=1; pid=removal_candidate(ids,pmap); old=len(ids); ids=structural_prune([x for x in ids if x!=pid],pmap); seq=[x for x in seq if x in set(ids)]; extra.append({'phase':'mc_safety_trim','removed':pid,'old_count':old,'new_count':len(ids),'prev_budget_feas':md.get('budget_feasibility_rate'),'prev_constraint_feas':md.get('constraint_feasibility_rate')}); md=eval_final(p,ps,scs,ids,seq)
    hist.extend(extra)
    md['budget_trim_info']={'method':method,'initial_selected_count':len(start.get('selected_ids',[])),'final_selected_count':md['selected_count'],'history':hist,'trim_steps':len(hist),'mode':'deterministic stage trim plus up to six MC safety trims; final common MC1000'}
    return md,p,ps

def usage(seed,method,p,ps,md):
    pmap={x.project_id:x for x in ps}; seq=make_seq(pmap,md.get('selected_ids',[]),md.get('sequence_ids',[])); st=eng.stage_sequence(seq,p); rows=[]
    if not st.feasible or not st.records: return rows
    end=max(r.completion_period_1 for r in st.records)
    for t0 in range(end):
        bu=cu=0; active=[]
        for rec in st.records:
            if rec.start_period_0<=t0<rec.completion_period_1:
                active.append(rec.project_id); d,b,c=profiles(pmap[rec.project_id]); off=t0-rec.start_period_0; bu+=b[off] if off<len(b) else 0; cu+=c[off] if off<len(c) else 0
        bcap=p.budget_restriction_profile[t0] if t0<len(p.budget_restriction_profile) else 0; ccap=p.constraint_capacity_profile[t0] if t0<len(p.constraint_capacity_profile) else p.constraint_capacity_profile[-1]
        rows.append({'seed':seed,'method':method,'period':t0+1,'active_count':len(active),'active_ids':';'.join(active),'budget_used':bu,'budget_cap':bcap,'budget_util_pct':bu/bcap*100 if bcap else None,'budget_ok':bu<=bcap+1e-9,'constraint_used':cu,'constraint_cap':ccap,'constraint_util_pct':cu/ccap*100 if ccap else None,'constraint_ok':cu<=ccap+1e-9})
    return rows

def metrics(seed,method,p,ps,md):
    pmap={x.project_id:x for x in ps}; u=usage(seed,method,p,ps,md); seq=make_seq(pmap,md.get('selected_ids',[]),md.get('sequence_ids',[])); st=eng.stage_sequence(seq,p)
    if st.feasible and st.records:
        start=min(r.start_period_0 for r in st.records)+1; end=max(r.completion_period_1 for r in st.records); dur=end-start+1
    else: start=end=dur=None
    w=[r['active_count'] for r in u]; ids=md.get('selected_ids',[]); bud=sum(pb(pmap[i]) for i in ids if i in pmap); con=sum(pc(pmap[i]) for i in ids if i in pmap)
    return {'seed':seed,'method':method,'admissible':valid(md),'stage_feasible':md.get('stage_feasible'),'selected_count':md.get('selected_count'),'p85_profit':md.get('p85_profit'),'budget_feasibility_rate':md.get('budget_feasibility_rate'),'constraint_feasibility_rate':md.get('constraint_feasibility_rate'),'portfolio_duration_periods':dur,'portfolio_budget_det':bud,'roi_pct_det_budget':md.get('p85_profit')/bud*100 if md.get('p85_profit') is not None and bud>0 else None,'total_constraint_det':con,'p85_per_constraint_unit':md.get('p85_profit')/con if md.get('p85_profit') is not None and con>0 else None,'wip_min':min(w) if w else None,'wip_max':max(w) if w else None,'wip_avg':sum(w)/len(w) if w else None,'avg_budget_util_pct':sum([r['budget_util_pct'] for r in u])/len(u) if u else None,'max_budget_util_pct':max([r['budget_util_pct'] for r in u],default=None),'avg_constraint_util_pct':sum([r['constraint_util_pct'] for r in u])/len(u) if u else None,'max_constraint_util_pct':max([r['constraint_util_pct'] for r in u],default=None),'all_period_budget_ok':all(r['budget_ok'] for r in u) if u else False,'all_period_constraint_ok':all(r['constraint_ok'] for r in u) if u else False,'near_all_selected':md.get('selected_count',0)>=NEAR_ALL}

outputs=[]; wm=[]; per=[]; period=[]; trace=[]
for seed in SEEDS:
    print('seed',seed,flush=True); src=json.load(open(SRC/f'seed{seed:03d}.json',encoding='utf-8'))
    methods={}; worlds={}
    for m in METHODS:
        md,p,ps=deterministic_trim(seed,m,src['final_mc1000_methods'][m]); methods[m]=md; worlds[m]=(p,ps)
    if valid(methods['Octane']) and ((not valid(methods['aOctane'])) or methods['aOctane']['p85_profit']+1e-9<methods['Octane']['p85_profit']):
        fb=dict(methods['Octane']); fb['guard_fallback_to_octane_after_budget_trim']=True; methods['aOctane']=fb
    methods['aOctane'].setdefault('guard_fallback_to_octane_after_budget_trim',False)
    adm3=[(m,methods[m]['p85_profit']) for m in RANKING if valid(methods[m])]; best3=max(adm3,key=lambda x:x[1]) if adm3 else (None,None)
    adm4=[(m,methods[m]['p85_profit']) for m in METHODS if valid(methods[m])]; best4=max(adm4,key=lambda x:x[1]) if adm4 else (None,None)
    delta=methods['sCPA_lite']['p85_profit']-best3[1] if valid(methods['sCPA_lite']) and best3[1] is not None else None
    out={'test_id':TEST_ID,'seed':seed,'cap_multiplier':CAP_MULT,'final_mc1000_methods':methods,'best3_method':best3[0],'best3_p85':best3[1],'best4_method':best4[0],'best4_p85':best4[1],'scpa_delta_vs_best3':delta,'scpa_uplift_pct_vs_best3_positive_denominator_only':delta/best3[1]*100 if delta is not None and best3[1]>EPS else None,'scpa_beats_best3_abs':bool(delta is not None and delta>0)}
    (OUT/f'seed{seed:03d}.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8'); outputs.append(out)
    row={'seed':seed,'best3_method':best3[0],'best3_p85':best3[1],'best4_method':best4[0],'best4_p85':best4[1],'scpa_delta_vs_best3':delta,'scpa_beats_best3_abs':out['scpa_beats_best3_abs']}
    for m,md in methods.items():
        p,ps=worlds[m]; sm=metrics(seed,m,p,ps,md); wm.append(sm); period.extend(usage(seed,m,p,ps,md)); trace.append({'seed':seed,'method':m,'admissible':valid(md),'history_json':json.dumps(md.get('budget_trim_info',{}).get('history',[]),ensure_ascii=False),'trim_steps':md.get('budget_trim_info',{}).get('trim_steps'),'initial_selected_count':md.get('budget_trim_info',{}).get('initial_selected_count'),'final_selected_count':md.get('selected_count')})
        row[f'{m}_admissible']=valid(md); row[f'{m}_p85']=md.get('p85_profit'); row[f'{m}_selected_count']=md.get('selected_count'); row[f'{m}_avg_budget_util_pct']=sm.get('avg_budget_util_pct'); row[f'{m}_roi_pct']=sm.get('roi_pct_det_budget')
    per.append(row)
write_csv(OUT/'per_seed_summary.csv',per); write_csv(OUT/'world_method_summary_schedule_budget_wip_roi_utilization.csv',wm); write_csv(OUT/'period_budget_constraint_wip_by_world_method_det.csv',period); write_csv(OUT/'repair_trace_by_world_method.csv',trace)
medrows=[]
for m in METHODS:
    rows=[x for x in wm if x['method']==m and x['admissible']]
    def med(k):
        vals=[x[k] for x in rows if x.get(k) is not None]; return statistics.median(vals) if vals else None
    medrows.append({'method':m,'admissible_worlds':len(rows),'median_selected_count':med('selected_count'),'median_p85_profit':med('p85_profit'),'median_roi_pct_det_budget':med('roi_pct_det_budget'),'median_portfolio_duration':med('portfolio_duration_periods'),'median_portfolio_budget_det':med('portfolio_budget_det'),'median_avg_budget_util_pct':med('avg_budget_util_pct'),'median_max_budget_util_pct':med('max_budget_util_pct'),'median_avg_constraint_util_pct':med('avg_constraint_util_pct'),'median_max_constraint_util_pct':med('max_constraint_util_pct'),'median_p85_per_constraint_unit':med('p85_per_constraint_unit'),'median_wip_avg':med('wip_avg'),'median_wip_max':med('wip_max'),'near_all_selected_worlds':sum(1 for x in rows if x.get('near_all_selected'))})
write_csv(OUT/'method_level_medians.csv',medrows)
usable=[r['seed'] for r in outputs if r['best3_method']]; strict=[r['seed'] for r in outputs if all(valid(r['final_mc1000_methods'][m]) for m in METHODS)]
summary={'test_id':TEST_ID,'status':'V14B deterministic budget trim screen at cap x2.0. This is a budget-pressure diagnostic/repair screen, not final clean rerun. It trims old V11B configurations to fit much tighter budget pressure and final-evaluates with MC1000.','method_admissible_counts':{m:sum(valid(r['final_mc1000_methods'][m]) for r in outputs) for m in METHODS},'usable_ranking_comparison_worlds':len(usable),'usable_ranking_comparison_seeds':usable,'strict_4way_worlds':len(strict),'strict_4way_seeds':strict,'scpa_beats_best3_abs_worlds':sum(r['scpa_beats_best3_abs'] for r in outputs),'scpa_best4_worlds':sum(r['best4_method']=='sCPA_lite' for r in outputs),'method_level_medians':medrows}
(OUT/'summary.json').write_text(json.dumps({'summary':summary,'per_seed':per,'method_level_medians':medrows},indent=2,ensure_ascii=False),encoding='utf-8')
report=[TEST_ID,'',summary['status'],'',f"Method admissible counts: {summary['method_admissible_counts']}",f"Usable ranking: {len(usable)}/10; strict 4-way: {len(strict)}/10; sCPA beats best ranking: {summary['scpa_beats_best3_abs_worlds']}/{len(usable)}; sCPA best overall: {summary['scpa_best4_worlds']}/10",'', 'Method medians:']
for r in medrows: report.append(f"- {r['method']}: adm {r['admissible_worlds']}/10; selected {r['median_selected_count']}; P85 {r['median_p85_profit']}; ROI {r['median_roi_pct_det_budget']}%; avg budget util {r['median_avg_budget_util_pct']}%; max budget util {r['median_max_budget_util_pct']}%; avg constraint util {r['median_avg_constraint_util_pct']}%; max constraint util {r['median_max_constraint_util_pct']}%")
(OUT/'REPORT_BG.txt').write_text('\n'.join(report),encoding='utf-8')
if ZIP.exists(): ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
    for fp in OUT.rglob('*'):
        if fp.is_file(): z.write(fp,arcname=fp.relative_to(OUT))
    z.write('/mnt/data/run_v14b_deterministic_trim_eval.py',arcname='reproduction_scripts/run_v14b_deterministic_trim_eval.py')
print('WROTE',ZIP)
